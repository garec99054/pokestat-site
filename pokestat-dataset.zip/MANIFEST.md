# Pokestat dataset manifest

Every CSV, MD and JSON artifact this site publishes, as one download.

Built at: 2026-09-08T06:31:52Z
- TCGplayer daily: 2026-09-08
- Cardmarket (EU): 2026-09-08
- Monthly panel: 2026-09-01

87 files.

## REPORT.md
- size: 1458 bytes

## backtest_results.csv
- size: 714942 bytes
- rows: 5436
- header: `requested_date,snapshot_date,forward_date,card_id,name,flag,market,predicted_market,studentized,market_fwd,forward_return`

## backtest_summary.md
- size: 6059 bytes

## etb_agevalue_ageing_slope.csv
- size: 1114 bytes
- rows: 6
- header: `channel,n_products,spearman_rho,spearman_p,slope_pp_per_year,slope_t,significant,median_annualised_pct,verdict`

## etb_agevalue_bands.csv
- size: 4282 bytes
- rows: 11
- header: `channel,age_band,n_products,age_min_years,age_max_years,median_price,median_ci_lo,median_ci_hi,geo_mean_price,p25_price,p75_price,min_price,max_price,n_sets,eras,reported,cohort_confound`

## etb_agevalue_collinearity.csv
- size: 612 bytes
- rows: 5
- header: `claim,quantity,value,verdict`

## etb_agevalue_cross_section.csv
- size: 16827 bytes
- rows: 103
- header: `product_id,name,set_id,set_name,era,month,release_month,age_months,age_years,age_band,channel,market,low,high,n_months,delisted`

## etb_agevalue_evidence.csv
- size: 4331 bytes
- rows: 15
- header: `direction,claim,quantity,value,n,caveat`

## etb_agevalue_gradient.csv
- size: 1911 bytes
- rows: 4
- header: `slice,n_products,age_min_years,age_max_years,spearman_rho,spearman_p,rho_ci_lo,rho_ci_hi,log_slope_per_year,slope_t,pct_per_year,significant,cohort_r2,cohort_confound`

## etb_agevalue_illustrative.csv
- size: 2665 bytes
- rows: 6
- header: `scenario,assumption,horizon_years,start_price,end_price,multiple,is_measured,beyond_archive,warning`

## etb_agevalue_inversions.csv
- size: 667 bytes
- rows: 3
- header: `channel,from_band,to_band,xs_implied_pct,n_crossers,realised_median_pct,realised_ci_lo_pct,realised_ci_hi_pct,contradicted,note`

## etb_agevalue_reconciliation.csv
- size: 659 bytes
- rows: 2
- header: `channel,n_products,span_years,xs_log_slope_per_year,xs_implied_pct,realised_median_pct,share_of_realised_log,excess_pct_points,reading`

## etb_agevalue_scarcity.csv
- size: 4370 bytes
- rows: 24
- header: `block,scope,metric,value,n,robust,note`

## etb_agevalue_shape.csv
- size: 1350 bytes
- rows: 2
- header: `channel,n_bands,monotonic,n_inversions,n_inversions_beyond_noise,worst_inversion,worst_inversion_pct,band_rank_rho,top_band,top_step_share_of_range,top_step_beyond_noise,median_ratio_top_to_bottom,shape,noise_note,cohort_confound`

## etb_agevalue_summary.json
- size: 3151 bytes

## etb_agevalue_survivorship.csv
- size: 593 bytes
- rows: 11
- header: `channel,age_band,n_catalogue,n_never_priced,n_delisted,n_currently_priced,pct_currently_priced,n_missing,missing_share_of_band`

## etb_agevalue_thinness.csv
- size: 881 bytes
- rows: 11
- header: `channel,age_band,n_products,share_market_below_low,n_single_listing,mean_stale_share,mean_months_observed,median_ask_spread_ratio`

## etb_agevalue_within_bands.csv
- size: 1184 bytes
- rows: 11
- header: `channel,entry_band,n_products,median_annualised_pct,ci_lo_pct,ci_hi_pct,share_negative,median_span_years,reported`

## etb_agevalue_within_paths.csv
- size: 18856 bytes
- rows: 98
- header: `product_id,name,channel,first_month,last_month,n_months,span_years,entry_age_years,exit_age_years,entry_band,log_change,total_pct,annualised_pct,full_window`

## etb_corrections.csv
- size: 6852 bytes
- rows: 14
- header: `corrected_on,artifact,quantity,superseded,current,direction,unit,cause,fixed_in,superseded_source`

## etb_forward.md
- size: 19345 bytes

## etb_forward_features.csv
- size: 5308 bytes
- rows: 56
- header: `horizon,feature,n_folds,mean_ic,se,t,n_eff,is_evidence`

## etb_forward_folds.csv
- size: 16429 bytes
- rows: 420
- header: `horizon,model,test_month,ic`

## etb_forward_panel.csv
- size: 1728991 bytes
- rows: 2408
- header: `product_id,name,set_id,set_name,series,era,date,month,fwd_end,horizon,market,mom_1m,mom_3m,mom_6m,vol_6m,months_since_release,log_price,log_set_size,rel_spread,market_pos,mid_skew,d_rel_spread_3m,d_market_pos_3m,chase_ret_3m,box_vs_chase,chase_missing,in_print_proxy,is_pokemon_center,is_retailer_exclusive,is_swsh,is_sv,is_me,y_abs,y_rel,y_mid,y_gap,z_mom_1m,z_mom_3m,z_mom_6m,z_vol_6m,z_months_since_release,z_log_price,z_log_set_size,z_rel_spread,z_market_pos,z_mid_skew,z_d_rel_spread_3m,z_d_market_pos_3m,z_chase_ret_3m,z_box_vs_chase`

## etb_forward_portfolio.csv
- size: 5347 bytes
- rows: 32
- header: `horizon,model,n_folds,top_annual_pct,bottom_annual_pct,basket_annual_pct,edge_annual_pp,cost_drag_annual_pp,net_edge_annual_pp,edge_t,n_eff,is_evidence`

## etb_forward_summary.csv
- size: 10096 bytes
- rows: 68
- header: `horizon,scorer,kind,n_folds,mean_ic,ic_std,autocorr_n_eff,structural_bound,n_eff,se,t,clears_zero,thin,is_evidence`

## etb_hold_by_age.csv
- size: 1185 bytes
- rows: 10
- header: `bucket,months,n_pairs,n_products,net_mult_median,net_cagr_median_pct,prob_nominal_loss,prob_below_hurdle,reported`

## etb_hold_concentration.csv
- size: 1360 bytes
- rows: 5
- header: `months,n_products,single_box_mult_p10,single_box_mult_median,single_box_mult_p90,basket_mult_median,single_box_p10_pct,single_box_median_pct,single_box_p90_pct,single_box_iqr_pp,basket_median_pct,share_single_below_basket,share_single_negative,annualised_meaningful`

## etb_hold_distribution.csv
- size: 1428 bytes
- rows: 5
- header: `months,n_pairs,n_products,n_independent_windows,gross_mult_median,net_mult_p05,net_mult_p25,net_mult_median,net_mult_p75,net_mult_p95,net_cagr_median_pct,net_cagr_equal_weight_median_pct,prob_nominal_loss,prob_below_hurdle,worst_net_mult,annualised_meaningful,reported`

## etb_hold_horizons.csv
- size: 1421 bytes
- rows: 7
- header: `months,gross_cagr_pct,gross_mult,net_mult,net_cagr_pct,drag_pp,friction_usd,friction_pct_of_outlay,hurdle_mult,beats_hurdle,breakeven_gross_cagr_pct,observable_in_archive`

## etb_hold_sensitivity.csv
- size: 1716 bytes
- rows: 26
- header: `knob,value,net_cagr_pct,net_mult,beats_hurdle`

## etb_hold_stress.csv
- size: 591 bytes
- rows: 7
- header: `months,terminal_drawdown_to_hurdle_pct,terminal_drawdown_to_nominal_pct,flat_market_net_mult,flat_market_net_cagr_pct`

## etb_hold_summary.md
- size: 22655 bytes

## etb_lifecycle_deceleration.csv
- size: 2131 bytes
- rows: 15
- header: `from_segment,to_segment,slope_change_per_year,se,t,ci_lo,ci_hi,significant,multiple_per_year`

## etb_lifecycle_era_overlap.csv
- size: 139 bytes
- rows: 6
- header: `era,n_products,n_obs,age_min,age_max`

## etb_lifecycle_era_profile.csv
- size: 1053 bytes
- rows: 12
- header: `era,n_products,n_obs,age_lo,age_hi,knot_months,gamma_per_year,se,t,significant`

## etb_lifecycle_identification.csv
- size: 484 bytes
- rows: 3
- header: `quantity,test,value,identified,note`

## etb_lifecycle_knot_sensitivity.csv
- size: 1884 bytes
- rows: 23
- header: `knot_set,knot_months,gamma_per_year,se,t`

## etb_lifecycle_launch_anchors.csv
- size: 12259 bytes
- rows: 108
- header: `product_id,name,release_month,release_day,anchor_month,anchor_age,anchor_lag_days,first_month,first_age,in_cohort,reason`

## etb_lifecycle_launch_channel.csv
- size: 618 bytes
- rows: 2
- header: `channel,n_products,trough_k,trough_relative,trough_ci_lo,trough_ci_hi,relative_at_6m,relative_at_12m,relative_at_12m_ci_lo,relative_at_12m_ci_hi,months_to_recover_launch,n_recovered_by_12m,product_min_at_12m,product_max_at_12m`

## etb_lifecycle_launch_curve.csv
- size: 7669 bytes
- rows: 52
- header: `basis,k,n_products,geo_mean_relative,ci_lo,ci_hi,median_relative,p25,p75,share_below_launch`

## etb_lifecycle_naive_curve.csv
- size: 1766 bytes
- rows: 11
- header: `band,age_lo,age_hi,n_obs,n_products,median_price,geo_mean_price,log_price_mean,se,ci_lo_price,ci_hi_price,top_era,top_era_share,n_eras`

## etb_lifecycle_pre_order_premium.csv
- size: 6465 bytes
- rows: 61
- header: `product_id,name,is_pokemon_center,month,months_before_anchor,age_months,pre_order_price,anchor_price,premium`

## etb_lifecycle_restriction_fan.csv
- size: 1117 bytes
- rows: 3
- header: `restriction,assumption,avg_age_slope_per_year,avg_age_pct_per_year,implied_calendar_trend_per_year,implied_cohort_trend_per_year,max_fitted_value_change,age_multiple_at_12m,age_multiple_at_24m,age_multiple_at_36m,age_multiple_at_60m,age_multiple_at_120m`

## etb_lifecycle_shock_events.csv
- size: 2978 bytes
- rows: 30
- header: `cohort,k,n_events,mean_idio,se,cumulative_idio,share_negative,n_products`

## etb_lifecycle_slope_changes.csv
- size: 725 bytes
- rows: 5
- header: `knot_months,gamma_per_year,se,t,ci_lo,ci_hi,significant,n_crossing_products,interpretation`

## etb_lifecycle_stability.csv
- size: 1209 bytes
- rows: 6
- header: `subsample,n_products,n_obs,knots,first_break_knot,first_break_per_year,first_break_t,deceleration_segments,deceleration_per_year,deceleration_t,deceleration_significant,curvature_p`

## etb_lifecycle_summary.json
- size: 2152 bytes

## etb_panel.csv
- size: 462802 bytes
- rows: 2756
- header: `product_id,name,set_id,set_name,series,month,market,low,high,release_month,release_day,months_since_release,is_pokemon_center,is_retailer_exclusive,variant_label,n_months,full_history,late_start,delisted`

## etb_products.csv
- size: 35826 bytes
- rows: 108
- header: `product_id,name,set_id,set_name,series,first_month,last_month,n_months,gap_months,gap_flagged,release_month,age_at_first_month,age_at_last_month,first_price,last_price,total_return_pct,cagr_pct,annual_pct,se_monthly,t,ci_lo_pct,ci_hi_pct,trend_reported,significant_positive,max_drawdown_pct,is_pokemon_center,is_retailer_exclusive,variant_label,full_history,late_start,delisted`

## etb_recent_benchmarks.csv
- size: 3135 bytes
- rows: 15
- header: `window,from_month,to_month,series_name,n_products,etb_annual_pct,benchmark_annual_pct,diff_pp,ci_lo_pp,ci_hi_pp,t,significant,n_returns,interval_reliable,verdict`

## etb_recent_breadth.csv
- size: 1309 bytes
- rows: 5
- header: `window,from_month,to_month,months,n_products,n_up,share_up,sign_p,geo_mean,median,p10,p25,p75,p90,min,max,annualised_geo_pct`

## etb_recent_concentration.csv
- size: 183 bytes
- rows: 3
- header: `top_share,n_products,contribution_share,evenness`

## etb_recent_drivers_age_band.csv
- size: 946 bytes
- rows: 6
- header: `grouping,group,n_products,share_of_products,geo_mean,ci_lo,ci_hi,median,n_up,share_up,contribution_share`

## etb_recent_drivers_channel.csv
- size: 423 bytes
- rows: 2
- header: `grouping,group,n_products,share_of_products,geo_mean,ci_lo,ci_hi,median,n_up,share_up,contribution_share`

## etb_recent_drivers_price_tier.csv
- size: 688 bytes
- rows: 4
- header: `grouping,group,n_products,share_of_products,geo_mean,ci_lo,ci_hi,median,n_up,share_up,contribution_share`

## etb_recent_fixed_cohort.csv
- size: 625 bytes
- rows: 2
- header: `window,from_month,to_month,months,n_products,n_up,share_up,sign_p,geo_mean,median,p10,p25,p75,p90,min,max,annualised_geo_pct,cohort`

## etb_recent_monthly.csv
- size: 4063 bytes
- rows: 30
- header: `month,n_matched,move_pct,ci_lo_pct,ci_hi_pct,t,n_up,share_up,sign_p,thin`

## etb_recent_summary.md
- size: 15434 bytes

## etb_recent_trailing.csv
- size: 883 bytes
- rows: 5
- header: `window,from_month,to_month,n_returns,mean_monthly_pct,annual_pct,ci_lo_pct,ci_hi_pct,t,lags,total_return_pct,interval_reliable`

## etb_summary.md
- size: 76658 bytes

## fair_value.csv
- size: 126992 bytes
- rows: 491
- header: `card_id,name,set_id,rarity,market,fair_value,fair_lo,fair_hi,residual_pct,residual_log,studentized,cooks_d,high_leverage,residual_rank,residual_pctile,verdict,verdict_studentized,hier_fair,hier_lo,hier_hi,hier_tail_prob,hier_verdict,verdict_agree,verdict_cross,n_snapshots_present,rank_series,chronic_flag,chronic_count,chronic_window,trailing_1m_pct,trailing_3m_pct,combined_signal`

## fair_value_summary.md
- size: 16028 bytes

## forward_outlook.csv
- size: 107306 bytes
- rows: 478
- header: `card_id,name,set_name,market_price,predicted_relative_return,pred_lo90,pred_hi90,percentile,direction_flag,direction_flag_percentile,signal_strength,top3_drivers,cardmarket_eur_avg30,cardmarket_eur_trend,cardmarket_eur_usd_div_z`

## forward_outlook_history.csv
- size: 173077 bytes
- rows: 1384
- header: `outlook_date,card_id,market_price,predicted_relative_return,pred_lo90,pred_hi90,source_commit`

## forward_validation.md
- size: 44592 bytes

## freshness.json
- size: 570 bytes

## headline.json
- size: 2111 bytes

## hier_results.csv
- size: 50606 bytes
- rows: 491
- header: `card_id,name,set_id,market,predicted_median,pi90_low,pi90_high,tail_prob,flag`

## hier_summary.md
- size: 6879 bytes

## hit_rates.json
- size: 295946 bytes

## market_gap.csv
- size: 1159043 bytes
- rows: 7836
- header: `card_id,name,set_id,set_name,number,rarity,variant,eu_eur,eu_usd,us_usd,ratio,gap_pct,gap_usd,obs_dates,flags`

## market_gap_summary.json
- size: 1139 bytes

## model_comparison.csv
- size: 3189 bytes
- rows: 8
- header: `model,features,cv_r2_mean,cv_r2_std,loocv_r2`

## model_comparison.md
- size: 6953 bytes

## model_results.csv
- size: 9737 bytes
- rows: 135
- header: `card_id,name,market,predicted_market,residual_log,studentized,cooks_d,flag,high_leverage`

## momentum_results.csv
- size: 22198 bytes
- rows: 190
- header: `strategy,side,window,skip,rebalance_date,n_names,top_mean_hold,bottom_mean_hold,spread,turnover`

## momentum_strata.csv
- size: 23849 bytes
- rows: 120
- header: `dimension,stratum,n_cards,strategy,window,skip,rebalances,mean_names,mean_leg_names,n_eff,autocorr,mean_spread,hit_rate,t_eff,mono_corr,mean_turnover,verdict,thin_reasons`

## momentum_summary.md
- size: 32164 bytes

## price_agreement.json
- size: 795 bytes

## scorecard.json
- size: 952 bytes

## scorecard.md
- size: 701 bytes

## sealed_summary.md
- size: 25797 bytes

## sparklines.json
- size: 128738 bytes

## variant_premium_daily.csv
- size: 1505174 bytes
- rows: 12361
- header: `card_id,product_id,name,set_id,set_name,number,rarity,pairing,premium_price,base_price,ratio,gap_usd,flags`

## variant_premium_daily_summary.json
- size: 24343 bytes

## variant_premium_summary.md
- size: 11953 bytes
