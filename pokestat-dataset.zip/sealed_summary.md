# Sealed Product Study

Standalone analysis of the sealed side of the catalogue: what is tracked, how
sealed prices relate to the chase singles a box contains, and how a box's price
compares to the expected value of its hits.

Window **2024-03 .. 2026-10** | **71 sets** | **206 sealed
products** | **46 sets usable** for the lead/lag study |
**29 sets** with a computable box EV.

Everything below is computed live from `sealed_index`, `price_history`,
`pull_rates` and `cards`. Nothing is hardcoded.

## 1. What sealed data exists

`sealed_index` holds **71 sets x 32 months**
(2024-03 .. 2026-10), built from
**206 distinct sealed products** in `price_history`
(entity_kind = 'sealed'). By product kind the per-set series break down as
54 booster_box, 17 elite_trainer_box; by era, SWSH 15, SM 14, SV 14, XY 12, ME 7, other 6, BW 3.

Depth is uneven and that matters more than the headline row count. The median
set contributes **32 monthly observations**;
**41** sets span the full window, while newer sets
(Mega Evolution) and delisted older products contribute a handful of months
each. **5** sets have interior holes in their series
(months where the product carried no market price).

Two structural limitations to state up front, before any of them is used for
anything:

- The median set has **1.0
  priced sealed products per month**. A set's "sealed price" is usually ONE
  product's series, not a cross-sectional average -- there is no within-set
  diversification to average away a single mispriced listing.
- **6** sets change `product_kind` mid-series (a
  booster box in some months, an elite trainer box in others, whichever was
  priced). The month-over-month change across such a boundary is a product
  swap, not a price move, so the return machinery below refuses to form a
  return across it -- exactly as it refuses to span a gap.

**46 of 71 sets** clear the gates for the
sealed-vs-singles study below (>= 12 overlapping months AND >=
5 chase singles priced in every month of the overlap).
Of the rest: 15 with fewer than 12 overlapping months; 10 with fewer than 5 chase singles priced in every month of the overlap.

| set | name | era | kind | kind switches | months | first | last | gaps | products/mo | chase basket | overlap | pull rates | usable |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| pgo | Pokémon GO | other | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 2.0 | 10 | 32 | no | yes |
| sm10 | Unbroken Bonds | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 19 | 32 | yes | yes |
| sm11 | Unified Minds | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 21 | 32 | yes | yes |
| sm12 | Cosmic Eclipse | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 35 | 32 | yes | yes |
| sm2 | Guardians Rising | SM | booster_box | 1 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 24 | 32 | yes | yes |
| sm3 | Burning Shadows | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 22 | 32 | yes | yes |
| sm35 | Shining Legends | SM | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 5 | 32 | yes | yes |
| sm4 | Crimson Invasion | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 13 | 32 | yes | yes |
| sm5 | Ultra Prism | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 15 | 32 | yes | yes |
| sm6 | Forbidden Light | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 14 | 32 | yes | yes |
| sm7 | Celestial Storm | SM | booster_box | 2 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 15 | 32 | yes | yes |
| sm75 | Dragon Majesty | SM | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 7 | 32 | yes | yes |
| sm8 | Lost Thunder | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 22 | 32 | yes | yes |
| sm9 | Team Up | SM | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 15 | 32 | yes | yes |
| sv1 | Scarlet & Violet | SV | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 16 | 32 | yes | yes |
| sv2 | Paldea Evolved | SV | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 23 | 32 | no | yes |
| sv3 | Obsidian Flames | SV | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 9 | 32 | yes | yes |
| sv3pt5 | 151 | SV | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 2.0 | 9 | 32 | yes | yes |
| sv4 | Paradox Rift | SV | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 22 | 32 | yes | yes |
| sv4pt5 | Paldean Fates | SV | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 2.0 | 14 | 32 | yes | yes |
| swsh1 | Sword & Shield | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 14 | 32 | no | yes |
| swsh10 | Astral Radiance | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 27 | 32 | yes | yes |
| swsh11 | Lost Origin | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 21 | 32 | yes | yes |
| swsh12 | Silver Tempest | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 20 | 32 | yes | yes |
| swsh2 | Rebel Clash | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 17 | 32 | no | yes |
| swsh3 | Darkness Ablaze | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 12 | 32 | no | yes |
| swsh35 | Champion's Path | SWSH | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 7 | 32 | no | yes |
| swsh4 | Vivid Voltage | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 18 | 32 | no | yes |
| swsh5 | Battle Styles | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 20 | 32 | no | yes |
| swsh6 | Chilling Reign | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 35 | 32 | no | yes |
| swsh7 | Evolving Skies | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 34 | 32 | yes | yes |
| swsh8 | Fusion Strike | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 20 | 32 | no | yes |
| swsh9 | Brilliant Stars | SWSH | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 14 | 32 | yes | yes |
| xy12 | Evolutions | XY | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 5 | 32 | no | yes |
| sv5 | Temporal Forces | SV | booster_box | 0 | 31 | 2024-04 | 2026-10 | 0 | 1.0 | 16 | 31 | yes | yes |
| sv6 | Twilight Masquerade | SV | booster_box | 0 | 29 | 2024-06 | 2026-10 | 0 | 1.0 | 17 | 29 | yes | yes |
| sv6pt5 | Shrouded Fable | SV | elite_trainer_box | 0 | 26 | 2024-09 | 2026-10 | 0 | 2.0 | 10 | 26 | yes | yes |
| sv7 | Stellar Crown | SV | booster_box | 0 | 25 | 2024-10 | 2026-10 | 0 | 1.0 | 9 | 25 | yes | yes |
| sv8 | Surging Sparks | SV | booster_box | 0 | 23 | 2024-12 | 2026-10 | 0 | 2.0 | 17 | 23 | yes | yes |
| sv8pt5 | Prismatic Evolutions | SV | elite_trainer_box | 0 | 21 | 2025-02 | 2026-10 | 0 | 2.0 | 37 | 21 | yes | yes |
| sv9 | Journey Together | SV | booster_box | 0 | 19 | 2025-04 | 2026-10 | 0 | 2.0 | 9 | 19 | yes | yes |
| xy7 | Ancient Origins | XY | booster_box | 1 | 18 | 2024-03 | 2025-10 | 2 | 1.0 | 5 | 18 | no | yes |
| sv10 | Destined Rivals | SV | booster_box | 0 | 17 | 2025-06 | 2026-10 | 0 | 2.0 | 17 | 17 | yes | yes |
| rsv10pt5 | White Flare | other | elite_trainer_box | 0 | 15 | 2025-08 | 2026-10 | 0 | 2.0 | 7 | 15 | no | yes |
| zsv10pt5 | Black Bolt | other | elite_trainer_box | 0 | 15 | 2025-08 | 2026-10 | 0 | 2.0 | 7 | 15 | no | yes |
| me1 | Mega Evolution | ME | booster_box | 0 | 13 | 2025-10 | 2026-10 | 0 | 2.0 | 12 | 13 | yes | yes |
| cel25 | Celebrations | other | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 2.0 | 0 | 0 | no | no |
| sm115 | Hidden Fates | SM | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 1 | 32 | yes | no |
| swsh12pt5 | Crown Zenith | SWSH | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 2.0 | 1 | 32 | yes | no |
| swsh45 | Shining Fates | SWSH | elite_trainer_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 1 | 32 | no | no |
| xy11 | Steam Siege | XY | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 2 | 32 | no | no |
| xy6 | Roaring Skies | XY | booster_box | 0 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 2 | 32 | no | no |
| xy8 | BREAKthrough | XY | booster_box | 2 | 32 | 2024-03 | 2026-10 | 0 | 1.0 | 2 | 32 | no | no |
| g1 | Generations | other | elite_trainer_box | 0 | 31 | 2024-03 | 2026-09 | 0 | 1.0 | 0 | 0 | no | no |
| xy1 | XY | XY | booster_box | 0 | 30 | 2024-04 | 2026-10 | 1 | 1.0 | 0 | 0 | no | no |
| xy10 | Fates Collide | XY | booster_box | 2 | 30 | 2024-03 | 2026-10 | 2 | 1.0 | 1 | 30 | no | no |
| xy9 | BREAKpoint | XY | booster_box | 4 | 30 | 2024-05 | 2026-10 | 0 | 1.0 | 1 | 30 | no | no |
| xy5 | Primal Clash | XY | booster_box | 0 | 28 | 2024-03 | 2026-10 | 4 | 1.0 | 4 | 28 | no | no |
| xy3 | Furious Fists | XY | booster_box | 0 | 27 | 2024-04 | 2026-10 | 4 | 1.0 | 2 | 27 | no | no |
| me2 | Phantasmal Flames | ME | booster_box | 0 | 11 | 2025-12 | 2026-10 | 0 | 1.0 | 6 | 11 | yes | no |
| me2pt5 | Ascended Heroes | ME | elite_trainer_box | 0 | 9 | 2026-02 | 2026-10 | 0 | 2.0 | 15 | 9 | yes | no |
| me3 | Perfect Order | ME | booster_box | 0 | 7 | 2026-04 | 2026-10 | 0 | 1.0 | 7 | 7 | no | no |
| bw11 | Legendary Treasures | BW | booster_box | 0 | 6 | 2024-06 | 2024-11 | 0 | 1.0 | 2 | 6 | no | no |
| me4 | Chaos Rising | ME | booster_box | 0 | 5 | 2026-06 | 2026-10 | 0 | 1.0 | 7 | 5 | yes | no |
| xy2 | Flashfire | XY | booster_box | 0 | 5 | 2024-03 | 2024-07 | 0 | 1.0 | 3 | 5 | no | no |
| xy4 | Phantom Forces | XY | booster_box | 0 | 5 | 2024-08 | 2024-12 | 0 | 1.0 | 3 | 5 | no | no |
| bw4 | Next Destinies | BW | booster_box | 0 | 4 | 2024-03 | 2024-06 | 0 | 1.0 | 4 | 4 | no | no |
| bw9 | Plasma Freeze | BW | booster_box | 0 | 3 | 2024-03 | 2024-05 | 0 | 1.0 | 6 | 3 | no | no |
| me5 | Pitch Black | ME | booster_box | 0 | 3 | 2026-08 | 2026-10 | 0 | 1.0 | 7 | 3 | yes | no |
| gym1 | Gym Heroes | other | booster_box | 0 | 1 | 2026-08 | 2026-08 | 0 | 1.0 | 0 | 0 | no | no |
| me55 | 30th Celebration | ME | elite_trainer_box | 0 | 1 | 2026-10 | 2026-10 | 0 | 2.0 | 12 | 1 | yes | no |

## 2. Sealed vs singles: lead, lag, or track?

A booster box is the raw input whose expected value is literally the singles
distribution, so the two prices ought to be linked. This section measures the
link directly.

**Construction.** For each of the **46 usable sets** the singles side is a
CONSTANT-BASKET median: only cards priced in every month of that set's
sealed/singles overlap window enter, so the index moves because prices moved and
not because the basket grew (median basket
**16 cards**; tiers: Special Illustration Rare, Hyper Rare, Mega Hyper Rare, Rare Secret, Rare Rainbow, Futuristic Rare). The sealed side is the
`sealed_index` mean price for the same month. The paired panel spans
**1340 (set, month)** rows over **32 months**.

**Sign convention.** `rho(k) = corr(sealed_return[t], singles_return[t + k])`.
So **k < 0 means the singles move came EARLIER** (singles lead) and **k > 0
means it came LATER** (sealed leads). k = 0 is contemporaneous.

**Two error bars, and why.** Every set rides the same market tide, so a t-stat
over 1340 pooled observations would be badly overconfident. Each
cell therefore carries both:

- **t (month)** -- CONSERVATIVE. One calendar month counts as one observation
  (all sets move together), and that month count is deflated for the lag-1
  autocorrelation of the monthly mean sealed return using the same `effective_n`
  the forward model uses. Overlapping H-month returns are autocorrelated by
  construction and are made to pay for it here.
- **t (set)** -- PERMISSIVE. Fisher-z average of the per-set correlations with a
  standard error across SETS, i.e. it pretends sets are independent draws. They
  are not.

The truth is bracketed by the two. **A direction is claimed only when both clear
|t| >= 2.** Cells thinner than 8 sets or
100 pairs report no estimate at all; per-set correlations need
8 observations to enter the permissive average.

**Neither side leads. The data cannot even establish that they reliably co-move.** Not one of the 4 profiles has a lag clearing both error bars, so no direction is claimed. What the numbers do show descriptively: the cross-correlation peaks at lag 0 in 4 of 4 profiles; the contemporaneous correlation runs 0.139-0.291 across the profiles, and the +1/-1 shoulders differ by only -0.044 to 0.047 in rho -- a symmetric hump centred on zero, which is the shape of two prices moving together, not of one price moving first. Under the permissive set-clustered bar alone the reading would be `tracks` -- so even the optimistic reading is *tracking*, never *leading*.

The size of the contemporaneous correlation is itself the interesting part. A booster box is a claim on the singles inside it, so the naive expectation is near-lockstep monthly co-movement. What is actually there is a weak positive association that the conservative bar cannot separate from the common market tide. Whatever prices a sealed box in this window, it is largely not the month-to-month value of its chase singles.

### 1-month log returns, raw

| lag k | reading | rho | pairs | sets | months | sealed autocorr | n_eff months | t (month) | t (set) | clears both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -3 | singles lead by 3m | -0.084 | 1145 | 46 | 28 | 0.383 | 12.5 | -0.27 | -2.60 | no |
| -2 | singles lead by 2m | 0.029 | 1192 | 46 | 29 | 0.366 | 13.5 | 0.10 | 1.43 | no |
| -1 | singles lead by 1m | 0.119 | 1239 | 46 | 30 | 0.382 | 13.4 | 0.40 | 4.03 | no |
| +0 | contemporaneous | 0.215 | 1288 | 46 | 31 | 0.377 | 14.0 | 0.76 | 5.80 | no |
| +1 | sealed leads by 1m | 0.166 | 1239 | 46 | 30 | 0.347 | 14.5 | 0.60 | 5.47 | no |
| +2 | sealed leads by 2m | 0.053 | 1192 | 46 | 29 | 0.317 | 15.0 | 0.19 | 2.04 | no |
| +3 | sealed leads by 3m | -0.075 | 1145 | 46 | 28 | 0.288 | 15.5 | -0.28 | -1.37 | no |

**1m returns, raw: `insufficient`** -- no lag clears both error bars. Largest correlation sits at lag +0 (rho 0.215); under the permissive (set-clustered) bar alone the reading would be `tracks`.

### 1-month log returns, market-tide-neutralized

| lag k | reading | rho | pairs | sets | months | sealed autocorr | n_eff months | t (month) | t (set) | clears both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -3 | singles lead by 3m | -0.044 | 1145 | 46 | 28 | 0.013 | 27.3 | -0.22 | -2.71 | no |
| -2 | singles lead by 2m | 0.086 | 1192 | 46 | 29 | -0.089 | 29.0 | 0.45 | 2.49 | no |
| -1 | singles lead by 1m | 0.125 | 1239 | 46 | 30 | -0.101 | 30.0 | 0.66 | 3.39 | no |
| +0 | contemporaneous | 0.139 | 1288 | 46 | 31 | -0.044 | 31.0 | 0.75 | 4.19 | no |
| +1 | sealed leads by 1m | 0.104 | 1239 | 46 | 30 | -0.050 | 30.0 | 0.55 | 3.76 | no |
| +2 | sealed leads by 2m | 0.017 | 1192 | 46 | 29 | -0.100 | 29.0 | 0.09 | -0.05 | no |
| +3 | sealed leads by 3m | -0.064 | 1145 | 46 | 28 | -0.117 | 28.0 | -0.33 | -1.82 | no |

**1m returns, market-tide-neutralized: `insufficient`** -- no lag clears both error bars. Largest correlation sits at lag +0 (rho 0.139); under the permissive (set-clustered) bar alone the reading would be `tracks`.

### 3-month log returns, raw

| lag k | reading | rho | pairs | sets | months | sealed autocorr | n_eff months | t (month) | t (set) | clears both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -3 | singles lead by 3m | -0.015 | 1045 | 46 | 26 | 0.817 | 2.6 | -0.01 | -0.82 | no |
| -2 | singles lead by 2m | 0.083 | 1093 | 46 | 27 | 0.811 | 2.8 | 0.08 | 1.39 | no |
| -1 | singles lead by 1m | 0.211 | 1141 | 46 | 28 | 0.815 | 2.8 | 0.20 | 4.84 | no |
| +0 | contemporaneous | 0.291 | 1190 | 46 | 29 | 0.808 | 3.1 | 0.32 | 6.97 | no |
| +1 | sealed leads by 1m | 0.236 | 1141 | 46 | 28 | 0.791 | 3.3 | 0.27 | 5.31 | no |
| +2 | sealed leads by 2m | 0.088 | 1093 | 46 | 27 | 0.789 | 3.2 | 0.10 | 2.35 | no |
| +3 | sealed leads by 3m | -0.083 | 1045 | 46 | 26 | 0.785 | 3.1 | -0.09 | -2.25 | no |

**3m returns, raw: `insufficient`** -- no lag clears both error bars. Largest correlation sits at lag +0 (rho 0.291); under the permissive (set-clustered) bar alone the reading would be `tracks`. NOTE: overlapping 3m returns leave a median of only **3.1 effective months** here, so the conservative bar has almost no power at this horizon -- its failure to reject is absence of evidence, not evidence of absence.

### 3-month log returns, market-tide-neutralized

| lag k | reading | rho | pairs | sets | months | sealed autocorr | n_eff months | t (month) | t (set) | clears both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -3 | singles lead by 3m | 0.022 | 1045 | 46 | 26 | 0.094 | 21.5 | 0.10 | -0.71 | no |
| -2 | singles lead by 2m | 0.125 | 1093 | 46 | 27 | 0.085 | 22.8 | 0.57 | 1.95 | no |
| -1 | singles lead by 1m | 0.186 | 1141 | 46 | 28 | 0.043 | 25.7 | 0.92 | 3.61 | no |
| +0 | contemporaneous | 0.218 | 1190 | 46 | 29 | -0.022 | 29.0 | 1.16 | 4.54 | no |
| +1 | sealed leads by 1m | 0.142 | 1141 | 46 | 28 | -0.024 | 28.0 | 0.73 | 2.92 | no |
| +2 | sealed leads by 2m | 0.035 | 1093 | 46 | 27 | -0.022 | 27.0 | 0.18 | 0.70 | no |
| +3 | sealed leads by 3m | -0.068 | 1045 | 46 | 26 | -0.031 | 26.0 | -0.33 | -2.30 | no |

**3m returns, market-tide-neutralized: `insufficient`** -- no lag clears both error bars. Largest correlation sits at lag +0 (rho 0.218); under the permissive (set-clustered) bar alone the reading would be `tracks`.

**Price LEVELS, for context only.** median per-set level correlation **0.663** across 46 sets, 71.7% of them positive. This is not evidence of a
pricing link: both series trend hard over this window, so correlated levels are
mostly shared trend. The return-based profiles above are the actual test, and
they are what the verdict rests on.

**Robustness.** widening the singles basket from the chase tiers to the full modeled universe gives `insufficient` at 1m raw (peak lag +0, rho 0.254) -- the same reading, so the headline does not hinge on the basket choice.

## 3. Expected value vs box price

**What is computed.** For each set with both `pull_rates` and a booster-box
`sealed_index` series, and for each month:

    EV per pack  = SUM over pull-rate tiers of  mean(tier's priced card prices) / packs_per_hit
    EV per box   = EV per pack x 36
    EV / price   = EV per box / booster-box market price

Both sides are read at the SAME month, from `price_history` only -- no
present-day price is projected backwards. **29 sets** and
**779 set-months** qualify. Elite-trainer-box sets are excluded because an
ETB's pack count varies by set and is not comparable to a
36-pack box.

**What this number ignores.** This estimates the tracked hit tiers, not total box value.
Missing cards are priced at the mean of the priced cards in their tier, so incomplete
coverage does not establish a lower bound:

- Only the tiers `pull_rates` covers contribute. Commons, uncommons, ordinary rares, reverse holos and energy carry real bulk value that is counted as zero here.
- Within a tier every card is assumed equally likely, and the tier's expected value is the MEAN market price of its priced cards. Real pack collation is not uniform.
- Prices are TCGplayer raw near-mint market prices. Condition, centering, and any grading upside or downside are ignored.
- Seller fees, shipping, and sales tax are ignored on both sides.
- A box is assumed to hold 36 packs (see PACKS_PER_BOX). The ratio is exactly linear in that count.
- `packs_per_hit` is a point estimate from a finite opening study (sample_size packs); its own sampling error is not propagated.
- Guaranteed-hit collation inside a box (a box is not 36 independent packs) is ignored; only the average rate is used.
- Sealed product has option value -- it can be held, opened later, or graded as sealed. None of that is priced here.

Read it as *"what fraction of the box price is explained by the tracked hit
tiers"*, not as *"how overpriced boxes are"*. A ratio of 25% does not mean a box
is 4x too expensive; it means the tiers `pull_rates` covers account for a quarter
of the price and everything in the caveat list accounts for the rest.

### Latest month per set

| set | era | month | EV/pack | EV/box | box price | EV / price | tier coverage |
| --- | --- | --- | --- | --- | --- | --- | --- |
| sv5 | SV | 2026-10 | $3.44 | $123.99 | $308.30 | 40.2% | 100.0% |
| sv6 | SV | 2026-10 | $2.73 | $98.41 | $272.11 | 36.2% | 100.0% |
| sv7 | SV | 2026-10 | $2.55 | $91.93 | $277.89 | 33.1% | 100.0% |
| sv4 | SV | 2026-10 | $2.51 | $90.27 | $282.20 | 32.0% | 100.0% |
| me5 | ME | 2026-10 | $1.63 | $58.83 | $186.06 | 31.6% | 100.0% |
| sv8 | SV | 2026-10 | $2.07 | $74.47 | $250.62 | 29.7% | 100.0% |
| sv1 | SV | 2026-10 | $2.36 | $84.92 | $298.00 | 28.5% | 100.0% |
| me2 | ME | 2026-10 | $2.99 | $107.63 | $390.47 | 27.6% | 100.0% |
| me1 | ME | 2026-10 | $2.15 | $77.43 | $296.16 | 26.1% | 100.0% |
| me4 | ME | 2026-10 | $1.37 | $49.48 | $191.35 | 25.9% | 100.0% |
| sv10 | SV | 2026-10 | $2.46 | $88.41 | $352.32 | 25.1% | 100.0% |
| sv3 | SV | 2026-10 | $2.47 | $88.76 | $374.38 | 23.7% | 100.0% |
| sv9 | SV | 2026-10 | $1.49 | $53.65 | $227.55 | 23.6% | 100.0% |
| swsh9 | SWSH | 2026-10 | $2.04 | $73.35 | $572.69 | 12.8% | 100.0% |
| swsh7 | SWSH | 2026-10 | $6.27 | $225.69 | $1945.76 | 11.6% | 100.0% |
| swsh10 | SWSH | 2026-10 | $1.28 | $46.18 | $411.39 | 11.2% | 100.0% |
| swsh11 | SWSH | 2026-10 | $2.22 | $80.01 | $730.93 | 10.9% | 100.0% |
| swsh12 | SWSH | 2026-10 | $1.58 | $56.81 | $523.28 | 10.9% | 100.0% |
| sm5 | SM | 2026-10 | $4.23 | $152.45 | $1450.00 | 10.5% | 91.7% |
| sm8 | SM | 2026-10 | $3.53 | $127.06 | $1568.33 | 8.1% | 100.0% |
| sm10 | SM | 2026-10 | $5.13 | $184.69 | $2560.51 | 7.2% | 97.8% |
| sm11 | SM | 2026-10 | $6.28 | $226.17 | $3240.30 | 7.0% | 97.8% |
| sm3 | SM | 2026-10 | $2.29 | $82.50 | $1243.10 | 6.6% | 100.0% |
| sm9 | SM | 2026-10 | $20.38 | $733.53 | $11725.00 | 6.3% | 100.0% |
| sm12 | SM | 2026-10 | $6.81 | $245.04 | $4216.67 | 5.8% | 97.6% |
| sm4 | SM | 2026-10 | $1.01 | $36.19 | $677.89 | 5.3% | 100.0% |
| sm6 | SM | 2026-10 | $2.05 | $73.70 | $1647.98 | 4.5% | 96.4% |
| sm7 | SM | 2026-10 | $3.02 | $108.66 | $2485.83 | 4.4% | 97.0% |
| sm2 | SM | 2026-10 | $1.17 | $42.15 | $1881.33 | 2.2% | 97.5% |

### By era (latest month)

| era | sets | median EV/price | min | max |
| --- | --- | --- | --- | --- |
| SV | 9 | 29.7% | 23.6% | 40.2% |
| ME | 4 | 26.9% | 25.9% | 31.6% |
| SWSH | 5 | 11.2% | 10.9% | 12.8% |
| SM | 11 | 6.3% | 2.2% | 10.5% |

The spread across eras is large and systematic: **SV** boxes sit at a median ratio of 29.7% while **SM** boxes sit at 6.3%. The natural reading is that an out-of-print box is priced as a scarce collectible in its own right, not as a claim on the singles inside it -- but this study measures the ratio, it does not test that explanation.

### Median EV/price ratio over time

The "all sets" column's basket GROWS as new sets are released, so part of any
move in it is composition, not price. The "constant basket" column holds only
the sets priced in every month of the panel and is the line to read when the
question is whether the relationship itself moved.

| month | all sets | n (all) | constant basket | n (fixed) |
| --- | --- | --- | --- | --- |
| 2024-03 | 11.7% | 18 | 11.9% | 17 |
| 2024-04 | 10.8% | 20 | 11.0% | 17 |
| 2024-05 | 11.7% | 20 | 12.3% | 17 |
| 2024-06 | 14.0% | 21 | 14.0% | 17 |
| 2024-07 | 14.2% | 21 | 14.2% | 17 |
| 2024-08 | 13.9% | 21 | 13.9% | 17 |
| 2024-09 | 12.8% | 21 | 12.8% | 17 |
| 2024-10 | 13.8% | 22 | 12.6% | 17 |
| 2024-11 | 14.7% | 21 | 11.3% | 17 |
| 2024-12 | 15.3% | 22 | 11.2% | 17 |
| 2025-01 | 14.9% | 22 | 12.0% | 17 |
| 2025-02 | 14.1% | 22 | 11.1% | 17 |
| 2025-03 | 13.7% | 23 | 11.9% | 17 |
| 2025-04 | 12.8% | 24 | 11.8% | 17 |
| 2025-05 | 12.4% | 24 | 12.2% | 17 |
| 2025-06 | 10.7% | 25 | 9.7% | 17 |
| 2025-07 | 10.2% | 25 | 9.1% | 17 |
| 2025-08 | 9.2% | 25 | 8.8% | 17 |
| 2025-09 | 8.6% | 25 | 7.3% | 17 |
| 2025-10 | 9.3% | 26 | 7.4% | 17 |
| 2025-11 | 9.2% | 26 | 7.4% | 17 |
| 2025-12 | 8.6% | 27 | 7.5% | 17 |
| 2026-01 | 8.8% | 27 | 7.7% | 17 |
| 2026-02 | 8.7% | 27 | 6.6% | 17 |
| 2026-03 | 8.8% | 27 | 6.7% | 17 |
| 2026-04 | 9.7% | 27 | 7.2% | 17 |
| 2026-05 | 11.1% | 27 | 7.3% | 17 |
| 2026-06 | 10.7% | 28 | 8.9% | 17 |
| 2026-07 | 11.1% | 28 | 9.4% | 17 |
| 2026-08 | 11.3% | 29 | 9.9% | 17 |
| 2026-09 | 11.4% | 29 | 10.3% | 17 |
| 2026-10 | 11.6% | 29 | 10.5% | 17 |

Across all available sets the median ratio moved from
**11.7%** (2024-03,
18 sets) to **11.6%**
(2026-10, 29 sets), peaking at
**15.3%** in 2024-12 and bottoming at
**8.6%** in 2025-09. On a fixed basket,
the constant-basket line (17 sets present in all 32 months) runs from **11.9%** to **10.5%**, peaking at **14.2%**. A rising ratio means singles outran box prices over that
stretch; a falling ratio means box prices outran singles.

No claim is made here that the ratio predicts anything -- testing that would
need its own walk-forward study with its own selection discipline.

## 4. What this study deliberately does not do

- **Sealed is NOT wired into the forward-model training panel.** It is a
  set-level cross-section with its own leakage questions (a sealed price is
  shared by every card in the set, so a naive card-level merge manufactures
  cross-sectional dependence). The panel's existing `sealed_trend_3m` feature is
  unchanged by this study.
- **No predictive claim.** Nothing here is scored out-of-sample against future
  returns. The lead/lag profiles are contemporaneous descriptions of a
  co-movement structure, not a trading signal.
- **78.9% of sets have a median of one priced sealed
  product per month.** A single delisting, relisting, or one thin-volume seller
  moves that set's entire "sealed price" for the month, and there is no
  within-set averaging to damp it.
- **Booster-bundle prices are discarded upstream** by `sealed_index`, and ETB
  prices only stand in where a set never had a booster box. Mixing pack counts
  would corrupt the EV ratio, so the EV section uses booster boxes only.
- **Pull rates are a single snapshot per set** from one opening study, applied to
  every month. Collation does not actually change over a set's life, so this is
  benign, but the rate's own sampling error is not propagated.

