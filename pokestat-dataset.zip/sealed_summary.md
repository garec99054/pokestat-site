# Sealed Product Study

Standalone analysis of the sealed side of the catalogue: what is tracked, how
sealed prices relate to the chase singles a box contains, and how a box's price
compares to the expected value of its hits.

Window **2024-03 .. 2026-11** | **71 sets** | **199 sealed
products** | **47 sets usable** for the lead/lag study |
**29 sets** with a computable box EV.

Everything below is computed live from `sealed_index`, `price_history`,
`pull_rates` and `cards`. Nothing is hardcoded.

## 1. What sealed data exists

`sealed_index` holds **71 sets x 33 months**
(2024-03 .. 2026-11), built from
**199 distinct sealed products** in `price_history`
(entity_kind = 'sealed'). By product kind the per-set series break down as
54 booster_box, 17 elite_trainer_box; by era, SWSH 15, SM 14, SV 14, XY 12, ME 7, other 6, BW 3.

Depth is uneven and that matters more than the headline row count. The median
set contributes **33 monthly observations**;
**42** sets span the full window, while newer sets
(Mega Evolution) and delisted older products contribute a handful of months
each. **5** sets have interior holes in their series
(months where the product carried no market price).

Two structural limitations to state up front, before any of them is used for
anything:

- The median set has **1.0
  priced sealed products per month**. A set's "sealed price" is usually ONE
  product's series, not a cross-sectional average -- there is no within-set
  diversification to average away a single mispriced listing.
- **6** sets change `product_kind` mid-series (a
  booster box in some months, an elite trainer box in others, whichever was
  priced). The month-over-month change across such a boundary is a product
  swap, not a price move, so the return machinery below refuses to form a
  return across it -- exactly as it refuses to span a gap.

**47 of 71 sets** clear the gates for the
sealed-vs-singles study below (>= 12 overlapping months AND >=
5 chase singles priced in every month of the overlap).
Of the rest: 14 with fewer than 12 overlapping months; 10 with fewer than 5 chase singles priced in every month of the overlap.

| set | name | era | kind | kind switches | months | first | last | gaps | products/mo | chase basket | overlap | pull rates | usable |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| pgo | Pokémon GO | other | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 2.0 | 10 | 33 | no | yes |
| sm10 | Unbroken Bonds | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 19 | 33 | yes | yes |
| sm11 | Unified Minds | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 21 | 33 | yes | yes |
| sm12 | Cosmic Eclipse | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 35 | 33 | yes | yes |
| sm2 | Guardians Rising | SM | booster_box | 1 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 24 | 33 | yes | yes |
| sm3 | Burning Shadows | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 22 | 33 | yes | yes |
| sm35 | Shining Legends | SM | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 5 | 33 | yes | yes |
| sm4 | Crimson Invasion | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 13 | 33 | yes | yes |
| sm5 | Ultra Prism | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 15 | 33 | yes | yes |
| sm6 | Forbidden Light | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 14 | 33 | yes | yes |
| sm7 | Celestial Storm | SM | booster_box | 2 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 15 | 33 | yes | yes |
| sm75 | Dragon Majesty | SM | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 7 | 33 | yes | yes |
| sm8 | Lost Thunder | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 22 | 33 | yes | yes |
| sm9 | Team Up | SM | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 15 | 33 | yes | yes |
| sv1 | Scarlet & Violet | SV | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 16 | 33 | yes | yes |
| sv2 | Paldea Evolved | SV | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 23 | 33 | no | yes |
| sv3 | Obsidian Flames | SV | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 9 | 33 | yes | yes |
| sv3pt5 | 151 | SV | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 2.0 | 9 | 33 | yes | yes |
| sv4 | Paradox Rift | SV | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 22 | 33 | yes | yes |
| sv4pt5 | Paldean Fates | SV | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 2.0 | 14 | 33 | yes | yes |
| swsh1 | Sword & Shield | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 14 | 33 | no | yes |
| swsh10 | Astral Radiance | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 27 | 33 | yes | yes |
| swsh11 | Lost Origin | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 21 | 33 | yes | yes |
| swsh12 | Silver Tempest | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 20 | 33 | yes | yes |
| swsh2 | Rebel Clash | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 17 | 33 | no | yes |
| swsh3 | Darkness Ablaze | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 12 | 33 | no | yes |
| swsh35 | Champion's Path | SWSH | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 7 | 33 | no | yes |
| swsh4 | Vivid Voltage | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 18 | 33 | no | yes |
| swsh5 | Battle Styles | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 20 | 33 | no | yes |
| swsh6 | Chilling Reign | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 35 | 33 | no | yes |
| swsh7 | Evolving Skies | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 34 | 33 | yes | yes |
| swsh8 | Fusion Strike | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 20 | 33 | no | yes |
| swsh9 | Brilliant Stars | SWSH | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 14 | 33 | yes | yes |
| xy12 | Evolutions | XY | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 5 | 33 | no | yes |
| sv5 | Temporal Forces | SV | booster_box | 0 | 32 | 2024-04 | 2026-11 | 0 | 1.0 | 16 | 32 | yes | yes |
| sv6 | Twilight Masquerade | SV | booster_box | 0 | 30 | 2024-06 | 2026-11 | 0 | 1.0 | 17 | 30 | yes | yes |
| sv6pt5 | Shrouded Fable | SV | elite_trainer_box | 0 | 27 | 2024-09 | 2026-11 | 0 | 2.0 | 10 | 27 | yes | yes |
| sv7 | Stellar Crown | SV | booster_box | 0 | 26 | 2024-10 | 2026-11 | 0 | 1.0 | 9 | 26 | yes | yes |
| sv8 | Surging Sparks | SV | booster_box | 0 | 24 | 2024-12 | 2026-11 | 0 | 1.0 | 17 | 24 | yes | yes |
| sv8pt5 | Prismatic Evolutions | SV | elite_trainer_box | 0 | 22 | 2025-02 | 2026-11 | 0 | 2.5 | 37 | 22 | yes | yes |
| sv9 | Journey Together | SV | booster_box | 0 | 20 | 2025-04 | 2026-11 | 0 | 2.0 | 9 | 20 | yes | yes |
| xy7 | Ancient Origins | XY | booster_box | 2 | 19 | 2024-03 | 2026-11 | 14 | 1.0 | 5 | 19 | no | yes |
| sv10 | Destined Rivals | SV | booster_box | 0 | 18 | 2025-06 | 2026-11 | 0 | 1.0 | 17 | 18 | yes | yes |
| rsv10pt5 | White Flare | other | elite_trainer_box | 0 | 16 | 2025-08 | 2026-11 | 0 | 2.0 | 7 | 16 | no | yes |
| zsv10pt5 | Black Bolt | other | elite_trainer_box | 0 | 16 | 2025-08 | 2026-11 | 0 | 2.0 | 7 | 16 | no | yes |
| me1 | Mega Evolution | ME | booster_box | 0 | 14 | 2025-10 | 2026-11 | 0 | 2.0 | 12 | 14 | yes | yes |
| me2 | Phantasmal Flames | ME | booster_box | 0 | 12 | 2025-12 | 2026-11 | 0 | 1.0 | 6 | 12 | yes | yes |
| cel25 | Celebrations | other | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 2.0 | 0 | 0 | no | no |
| g1 | Generations | other | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 0 | 0 | no | no |
| sm115 | Hidden Fates | SM | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 1 | 33 | yes | no |
| swsh12pt5 | Crown Zenith | SWSH | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 2.0 | 1 | 33 | yes | no |
| swsh45 | Shining Fates | SWSH | elite_trainer_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 1 | 33 | no | no |
| xy11 | Steam Siege | XY | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 2 | 33 | no | no |
| xy6 | Roaring Skies | XY | booster_box | 0 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 2 | 33 | no | no |
| xy8 | BREAKthrough | XY | booster_box | 2 | 33 | 2024-03 | 2026-11 | 0 | 1.0 | 2 | 33 | no | no |
| xy10 | Fates Collide | XY | booster_box | 2 | 31 | 2024-03 | 2026-11 | 2 | 1.0 | 1 | 31 | no | no |
| xy9 | BREAKpoint | XY | booster_box | 4 | 31 | 2024-05 | 2026-11 | 0 | 1.0 | 1 | 31 | no | no |
| xy1 | XY | XY | booster_box | 0 | 30 | 2024-04 | 2026-10 | 1 | 1.0 | 0 | 0 | no | no |
| xy3 | Furious Fists | XY | booster_box | 0 | 28 | 2024-04 | 2026-11 | 4 | 1.0 | 2 | 28 | no | no |
| xy5 | Primal Clash | XY | booster_box | 0 | 28 | 2024-03 | 2026-10 | 4 | 1.0 | 4 | 28 | no | no |
| me2pt5 | Ascended Heroes | ME | elite_trainer_box | 0 | 10 | 2026-02 | 2026-11 | 0 | 2.0 | 15 | 10 | yes | no |
| me3 | Perfect Order | ME | booster_box | 0 | 8 | 2026-04 | 2026-11 | 0 | 1.0 | 7 | 8 | no | no |
| bw11 | Legendary Treasures | BW | booster_box | 0 | 6 | 2024-06 | 2024-11 | 0 | 1.0 | 2 | 6 | no | no |
| me4 | Chaos Rising | ME | booster_box | 0 | 6 | 2026-06 | 2026-11 | 0 | 1.0 | 7 | 6 | yes | no |
| xy2 | Flashfire | XY | booster_box | 0 | 5 | 2024-03 | 2024-07 | 0 | 1.0 | 3 | 5 | no | no |
| xy4 | Phantom Forces | XY | booster_box | 0 | 5 | 2024-08 | 2024-12 | 0 | 1.0 | 3 | 5 | no | no |
| bw4 | Next Destinies | BW | booster_box | 0 | 4 | 2024-03 | 2024-06 | 0 | 1.0 | 4 | 4 | no | no |
| me5 | Pitch Black | ME | booster_box | 0 | 4 | 2026-08 | 2026-11 | 0 | 1.0 | 7 | 4 | yes | no |
| bw9 | Plasma Freeze | BW | booster_box | 0 | 3 | 2024-03 | 2024-05 | 0 | 1.0 | 6 | 3 | no | no |
| me55 | 30th Celebration | ME | elite_trainer_box | 0 | 2 | 2026-10 | 2026-11 | 0 | 2.0 | 12 | 2 | yes | no |
| gym1 | Gym Heroes | other | booster_box | 0 | 1 | 2026-08 | 2026-08 | 0 | 1.0 | 0 | 0 | no | no |

## 2. Sealed vs singles: lead, lag, or track?

A booster box is the raw input whose expected value is literally the singles
distribution, so the two prices ought to be linked. This section measures the
link directly.

**Construction.** For each of the **47 usable sets** the singles side is a
CONSTANT-BASKET median: only cards priced in every month of that set's
sealed/singles overlap window enter, so the index moves because prices moved and
not because the basket grew (median basket
**15 cards**; tiers: Special Illustration Rare, Hyper Rare, Mega Hyper Rare, Rare Secret, Rare Rainbow, Futuristic Rare). The sealed side is the
`sealed_index` mean price for the same month. The paired panel spans
**1398 (set, month)** rows over **33 months**.

**Sign convention.** `rho(k) = corr(sealed_return[t], singles_return[t + k])`.
So **k < 0 means the singles move came EARLIER** (singles lead) and **k > 0
means it came LATER** (sealed leads). k = 0 is contemporaneous.

**Two error bars, and why.** Every set rides the same market tide, so a t-stat
over 1398 pooled observations would be badly overconfident. Each
cell therefore carries both:

- **t (month)** -- CONSERVATIVE. One calendar month counts as one observation
  (all sets move together), and that month count is deflated for the lag-1
  autocorrelation of the monthly mean sealed return using the same `effective_n`
  the forward model uses. Overlapping H-month returns are autocorrelated by
  construction and are made to pay for it here.
- **t (set)** -- PERMISSIVE. Fisher-z average of the per-set correlations with a
  standard error across SETS, i.e. it pretends sets are independent draws. They
  are not.

The truth is bracketed by the two. **A direction is claimed only when both clear
|t| >= 2.** Cells thinner than 8 sets or
100 pairs report no estimate at all; per-set correlations need
8 observations to enter the permissive average.

**Neither side leads. The data cannot even establish that they reliably co-move.** Not one of the 4 profiles has a lag clearing both error bars, so no direction is claimed. What the numbers do show descriptively: the cross-correlation peaks at lag 0 in 4 of 4 profiles; the contemporaneous correlation runs 0.156-0.326 across the profiles, and the +1/-1 shoulders differ by only -0.035 to 0.039 in rho -- a symmetric hump centred on zero, which is the shape of two prices moving together, not of one price moving first. Under the permissive set-clustered bar alone the reading would be `tracks` -- so even the optimistic reading is *tracking*, never *leading*.

The size of the contemporaneous correlation is itself the interesting part. A booster box is a claim on the singles inside it, so the naive expectation is near-lockstep monthly co-movement. What is actually there is a moderate positive association that the conservative bar cannot separate from the common market tide. Whatever prices a sealed box in this window, it is largely not the month-to-month value of its chase singles.

### 1-month log returns, raw

| lag k | reading | rho | pairs | sets | months | sealed autocorr | n_eff months | t (month) | t (set) | clears both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -3 | singles lead by 3m | -0.076 | 1198 | 47 | 29 | 0.430 | 11.6 | -0.24 | -3.10 | no |
| -2 | singles lead by 2m | 0.026 | 1246 | 47 | 30 | 0.413 | 12.5 | 0.08 | 1.31 | no |
| -1 | singles lead by 1m | 0.138 | 1294 | 47 | 31 | 0.422 | 12.6 | 0.45 | 4.78 | no |
| +0 | contemporaneous | 0.245 | 1344 | 47 | 32 | 0.413 | 13.3 | 0.85 | 7.00 | no |
| +1 | sealed leads by 1m | 0.177 | 1294 | 47 | 31 | 0.394 | 13.5 | 0.61 | 5.32 | no |
| +2 | sealed leads by 2m | 0.070 | 1246 | 47 | 30 | 0.368 | 13.9 | 0.24 | 2.39 | no |
| +3 | sealed leads by 3m | -0.060 | 1198 | 47 | 29 | 0.322 | 14.9 | -0.22 | -0.99 | no |

**1m returns, raw: `insufficient`** -- no lag clears both error bars. Largest correlation sits at lag +0 (rho 0.245); under the permissive (set-clustered) bar alone the reading would be `tracks`.

### 1-month log returns, market-tide-neutralized

| lag k | reading | rho | pairs | sets | months | sealed autocorr | n_eff months | t (month) | t (set) | clears both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -3 | singles lead by 3m | -0.045 | 1198 | 47 | 29 | 0.156 | 21.2 | -0.20 | -2.83 | no |
| -2 | singles lead by 2m | 0.079 | 1246 | 47 | 30 | 0.059 | 26.6 | 0.39 | 2.16 | no |
| -1 | singles lead by 1m | 0.127 | 1294 | 47 | 31 | 0.034 | 29.0 | 0.67 | 3.70 | no |
| +0 | contemporaneous | 0.156 | 1344 | 47 | 32 | 0.123 | 25.0 | 0.76 | 5.28 | no |
| +1 | sealed leads by 1m | 0.104 | 1294 | 47 | 31 | 0.116 | 24.6 | 0.50 | 3.57 | no |
| +2 | sealed leads by 2m | 0.025 | 1246 | 47 | 30 | 0.037 | 27.9 | 0.13 | 0.39 | no |
| +3 | sealed leads by 3m | -0.064 | 1198 | 47 | 29 | -0.013 | 29.0 | -0.33 | -1.78 | no |

**1m returns, market-tide-neutralized: `insufficient`** -- no lag clears both error bars. Largest correlation sits at lag +0 (rho 0.156); under the permissive (set-clustered) bar alone the reading would be `tracks`.

### 3-month log returns, raw

| lag k | reading | rho | pairs | sets | months | sealed autocorr | n_eff months | t (month) | t (set) | clears both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -3 | singles lead by 3m | -0.048 | 1096 | 47 | 27 | 0.821 | 2.6 | -0.04 | -1.81 | no |
| -2 | singles lead by 2m | 0.087 | 1145 | 47 | 28 | 0.816 | 2.8 | 0.08 | 1.74 | no |
| -1 | singles lead by 1m | 0.236 | 1194 | 47 | 29 | 0.815 | 3.0 | 0.24 | 6.03 | no |
| +0 | contemporaneous | 0.326 | 1244 | 47 | 30 | 0.809 | 3.2 | 0.37 | 8.28 | no |
| +1 | sealed leads by 1m | 0.272 | 1194 | 47 | 29 | 0.790 | 3.4 | 0.33 | 6.28 | no |
| +2 | sealed leads by 2m | 0.104 | 1145 | 47 | 28 | 0.769 | 3.7 | 0.13 | 2.57 | no |
| +3 | sealed leads by 3m | -0.096 | 1096 | 47 | 27 | 0.769 | 3.5 | -0.12 | -2.39 | no |

**3m returns, raw: `insufficient`** -- no lag clears both error bars. Largest correlation sits at lag +0 (rho 0.326); under the permissive (set-clustered) bar alone the reading would be `tracks`. NOTE: overlapping 3m returns leave a median of only **3.2 effective months** here, so the conservative bar has almost no power at this horizon -- its failure to reject is absence of evidence, not evidence of absence.

### 3-month log returns, market-tide-neutralized

| lag k | reading | rho | pairs | sets | months | sealed autocorr | n_eff months | t (month) | t (set) | clears both |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -3 | singles lead by 3m | 0.015 | 1096 | 47 | 27 | 0.143 | 20.3 | 0.06 | -1.43 | no |
| -2 | singles lead by 2m | 0.134 | 1145 | 47 | 28 | 0.139 | 21.2 | 0.59 | 2.18 | no |
| -1 | singles lead by 1m | 0.204 | 1194 | 47 | 29 | 0.127 | 22.4 | 0.94 | 3.92 | no |
| +0 | contemporaneous | 0.242 | 1244 | 47 | 30 | 0.072 | 25.9 | 1.22 | 5.24 | no |
| +1 | sealed leads by 1m | 0.168 | 1194 | 47 | 29 | 0.036 | 27.0 | 0.85 | 3.45 | no |
| +2 | sealed leads by 2m | 0.035 | 1145 | 47 | 28 | 0.023 | 26.7 | 0.18 | 1.01 | no |
| +3 | sealed leads by 3m | -0.086 | 1096 | 47 | 27 | -0.001 | 27.0 | -0.43 | -2.49 | no |

**3m returns, market-tide-neutralized: `insufficient`** -- no lag clears both error bars. Largest correlation sits at lag +0 (rho 0.242); under the permissive (set-clustered) bar alone the reading would be `tracks`.

**Price LEVELS, for context only.** median per-set level correlation **0.541** across 47 sets, 68.1% of them positive. This is not evidence of a
pricing link: both series trend hard over this window, so correlated levels are
mostly shared trend. The return-based profiles above are the actual test, and
they are what the verdict rests on.

**Robustness.** widening the singles basket from the chase tiers to the full modeled universe gives `insufficient` at 1m raw (peak lag +0, rho 0.265) -- the same reading, so the headline does not hinge on the basket choice.

## 3. Expected value vs box price

**What is computed.** For each set with both `pull_rates` and a booster-box
`sealed_index` series, and for each month:

    EV per pack  = SUM over pull-rate tiers of  mean(tier's priced card prices) / packs_per_hit
    EV per box   = EV per pack x 36
    EV / price   = EV per box / booster-box market price

Both sides are read at the SAME month, from `price_history` only -- no
present-day price is projected backwards. **29 sets** and
**808 set-months** qualify. Elite-trainer-box sets are excluded because an
ETB's pack count varies by set and is not comparable to a
36-pack box.

**What this number ignores.** This estimates the tracked hit tiers, not total box value.
Missing cards are priced at the mean of the priced cards in their tier, so incomplete
coverage does not establish a lower bound:

- Only the tiers `pull_rates` covers contribute. Commons, uncommons, ordinary rares, reverse holos and energy carry real bulk value that is counted as zero here.
- Within a tier every card is assumed equally likely, and the tier's expected value is the MEAN market price of its priced cards. Real pack collation is not uniform.
- Prices are TCGplayer raw near-mint market prices. Condition, centering, and any grading upside or downside are ignored.
- Seller fees, shipping, and sales tax are ignored on both sides.
- A box is assumed to hold 36 packs (see PACKS_PER_BOX). The ratio is exactly linear in that count.
- `packs_per_hit` is a point estimate from a finite opening study (sample_size packs); its own sampling error is not propagated.
- Guaranteed-hit collation inside a box (a box is not 36 independent packs) is ignored; only the average rate is used.
- Sealed product has option value -- it can be held, opened later, or graded as sealed. None of that is priced here.

Read it as *"what fraction of the box price is explained by the tracked hit
tiers"*, not as *"how overpriced boxes are"*. A ratio of 25% does not mean a box
is 4x too expensive; it means the tiers `pull_rates` covers account for a quarter
of the price and everything in the caveat list accounts for the rest.

### Latest month per set

| set | era | month | EV/pack | EV/box | box price | EV / price | tier coverage |
| --- | --- | --- | --- | --- | --- | --- | --- |
| sv5 | SV | 2026-11 | $3.20 | $115.32 | $319.20 | 36.1% | 100.0% |
| sv4 | SV | 2026-11 | $2.32 | $83.54 | $282.98 | 29.5% | 100.0% |
| me5 | ME | 2026-11 | $1.46 | $52.49 | $180.19 | 29.1% | 100.0% |
| sv7 | SV | 2026-11 | $2.41 | $86.90 | $307.31 | 28.3% | 100.0% |
| sv6 | SV | 2026-11 | $2.44 | $87.80 | $332.69 | 26.4% | 100.0% |
| sv1 | SV | 2026-11 | $2.16 | $77.65 | $297.99 | 26.1% | 100.0% |
| me2 | ME | 2026-11 | $2.66 | $95.93 | $387.12 | 24.8% | 100.0% |
| me4 | ME | 2026-11 | $1.19 | $42.76 | $182.57 | 23.4% | 100.0% |
| me1 | ME | 2026-11 | $1.94 | $69.71 | $299.04 | 23.3% | 100.0% |
| sv8 | SV | 2026-11 | $1.82 | $65.65 | $298.83 | 22.0% | 100.0% |
| sv3 | SV | 2026-11 | $2.24 | $80.55 | $378.33 | 21.3% | 100.0% |
| sv9 | SV | 2026-11 | $1.27 | $45.59 | $217.61 | 21.0% | 100.0% |
| sv10 | SV | 2026-11 | $2.04 | $73.30 | $381.05 | 19.2% | 100.0% |
| swsh9 | SWSH | 2026-11 | $1.92 | $68.98 | $558.23 | 12.4% | 100.0% |
| swsh10 | SWSH | 2026-11 | $1.24 | $44.81 | $409.29 | 10.9% | 100.0% |
| swsh12 | SWSH | 2026-11 | $1.49 | $53.63 | $506.04 | 10.6% | 100.0% |
| swsh11 | SWSH | 2026-11 | $2.15 | $77.55 | $732.10 | 10.6% | 100.0% |
| swsh7 | SWSH | 2026-11 | $6.10 | $219.77 | $2162.79 | 10.2% | 100.0% |
| sm5 | SM | 2026-11 | $4.26 | $153.36 | $1561.08 | 9.8% | 91.7% |
| sm8 | SM | 2026-11 | $3.78 | $136.04 | $1618.82 | 8.4% | 100.0% |
| sm10 | SM | 2026-11 | $5.31 | $191.32 | $2724.40 | 7.0% | 97.8% |
| sm11 | SM | 2026-11 | $6.51 | $234.50 | $3376.76 | 6.9% | 97.8% |
| sm9 | SM | 2026-11 | $22.52 | $810.79 | $11737.50 | 6.9% | 100.0% |
| sm3 | SM | 2026-11 | $2.36 | $84.84 | $1286.31 | 6.6% | 100.0% |
| sm12 | SM | 2026-11 | $6.91 | $248.84 | $4216.67 | 5.9% | 97.6% |
| sm4 | SM | 2026-11 | $1.00 | $35.98 | $671.59 | 5.4% | 100.0% |
| sm6 | SM | 2026-11 | $2.09 | $75.29 | $1631.98 | 4.6% | 96.4% |
| sm7 | SM | 2026-11 | $3.14 | $112.90 | $2676.74 | 4.2% | 97.0% |
| sm2 | SM | 2026-11 | $1.20 | $43.05 | $1881.33 | 2.3% | 97.5% |

### By era (latest month)

| era | sets | median EV/price | min | max |
| --- | --- | --- | --- | --- |
| SV | 9 | 26.1% | 19.2% | 36.1% |
| ME | 4 | 24.1% | 23.3% | 29.1% |
| SWSH | 5 | 10.6% | 10.2% | 12.4% |
| SM | 11 | 6.6% | 2.3% | 9.8% |

The spread across eras is large and systematic: **SV** boxes sit at a median ratio of 26.1% while **SM** boxes sit at 6.6%. The natural reading is that an out-of-print box is priced as a scarce collectible in its own right, not as a claim on the singles inside it -- but this study measures the ratio, it does not test that explanation.

### Median EV/price ratio over time

The "all sets" column's basket GROWS as new sets are released, so part of any
move in it is composition, not price. The "constant basket" column holds only
the sets priced in every month of the panel and is the line to read when the
question is whether the relationship itself moved.

| month | all sets | n (all) | constant basket | n (fixed) |
| --- | --- | --- | --- | --- |
| 2024-03 | 11.7% | 18 | 11.9% | 17 |
| 2024-04 | 10.8% | 20 | 11.0% | 17 |
| 2024-05 | 11.7% | 20 | 12.3% | 17 |
| 2024-06 | 14.0% | 21 | 14.0% | 17 |
| 2024-07 | 14.2% | 21 | 14.2% | 17 |
| 2024-08 | 13.9% | 21 | 13.9% | 17 |
| 2024-09 | 12.8% | 21 | 12.8% | 17 |
| 2024-10 | 13.8% | 22 | 12.6% | 17 |
| 2024-11 | 14.7% | 21 | 11.3% | 17 |
| 2024-12 | 15.3% | 22 | 11.2% | 17 |
| 2025-01 | 14.9% | 22 | 12.0% | 17 |
| 2025-02 | 14.1% | 22 | 11.1% | 17 |
| 2025-03 | 13.7% | 23 | 11.9% | 17 |
| 2025-04 | 12.8% | 24 | 11.8% | 17 |
| 2025-05 | 12.4% | 24 | 12.2% | 17 |
| 2025-06 | 10.7% | 25 | 9.7% | 17 |
| 2025-07 | 10.2% | 25 | 9.1% | 17 |
| 2025-08 | 9.2% | 25 | 8.8% | 17 |
| 2025-09 | 8.6% | 25 | 7.3% | 17 |
| 2025-10 | 9.3% | 26 | 7.4% | 17 |
| 2025-11 | 9.2% | 26 | 7.4% | 17 |
| 2025-12 | 8.6% | 27 | 7.5% | 17 |
| 2026-01 | 8.8% | 27 | 7.7% | 17 |
| 2026-02 | 8.7% | 27 | 6.6% | 17 |
| 2026-03 | 8.8% | 27 | 6.7% | 17 |
| 2026-04 | 9.7% | 27 | 7.2% | 17 |
| 2026-05 | 11.1% | 27 | 7.3% | 17 |
| 2026-06 | 10.7% | 28 | 7.7% | 17 |
| 2026-07 | 11.1% | 28 | 8.5% | 17 |
| 2026-08 | 11.2% | 29 | 9.3% | 17 |
| 2026-09 | 11.4% | 29 | 9.4% | 17 |
| 2026-10 | 11.2% | 29 | 9.8% | 17 |
| 2026-11 | 10.9% | 29 | 9.8% | 17 |

Across all available sets the median ratio moved from
**11.7%** (2024-03,
18 sets) to **10.9%**
(2026-11, 29 sets), peaking at
**15.3%** in 2024-12 and bottoming at
**8.6%** in 2025-09. On a fixed basket,
the constant-basket line (17 sets present in all 33 months) runs from **11.9%** to **9.8%**, peaking at **14.2%**. A rising ratio means singles outran box prices over that
stretch; a falling ratio means box prices outran singles.

No claim is made here that the ratio predicts anything -- testing that would
need its own walk-forward study with its own selection discipline.

## 4. What this study deliberately does not do

- **Sealed is NOT wired into the forward-model training panel.** It is a
  set-level cross-section with its own leakage questions (a sealed price is
  shared by every card in the set, so a naive card-level merge manufactures
  cross-sectional dependence). The panel's existing `sealed_trend_3m` feature is
  unchanged by this study.
- **No predictive claim.** Nothing here is scored out-of-sample against future
  returns. The lead/lag profiles are contemporaneous descriptions of a
  co-movement structure, not a trading signal.
- **81.7% of sets have a median of one priced sealed
  product per month.** A single delisting, relisting, or one thin-volume seller
  moves that set's entire "sealed price" for the month, and there is no
  within-set averaging to damp it.
- **Booster-bundle prices are discarded upstream** by `sealed_index`, and ETB
  prices only stand in where a set never had a booster box. Mixing pack counts
  would corrupt the EV ratio, so the EV section uses booster boxes only.
- **Pull rates are a single snapshot per set** from one opening study, applied to
  every month. Collation does not actually change over a set's life, so this is
  benign, but the rate's own sampling error is not propagated.

