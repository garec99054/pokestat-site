# Variant Premium Study

**As-of date: 2026-08-26.** `prices.sub_type` carries 7 distinct finishes and
135k+ rows in this database, but every other model in this repo reads only
`market`, silently pooling across finishes of the same product. This study
measures the premium one finish commands over another on the SAME product, on
the SAME date.

## Headline (all defined pairs, pooled)

| pair | n | median ratio [95% CI] | mean ratio | IQR |
| --- | --- | --- | --- | --- |
| Reverse Holofoil / Normal | 11161 | 2.692x  [2.640, 2.737] | 6.127 | [1.800, 5.457] |
| Reverse Holofoil / Holofoil | 1626 | 1.231x  [1.201, 1.259] | 1.443 | [0.994, 1.612] |
| 1st Edition / Unlimited | 760 | 2.794x  [2.669, 2.934] | 3.687 | [2.070, 4.074] |
| Holofoil / Normal | 274 | 1.994x  [1.753, 2.270] | 3.804 | [1.335, 3.317] |
| 1st Edition Holofoil / Unlimited Holofoil | 169 | 2.441x  [2.263, 2.615] | 2.666 | [1.886, 3.119] |

MEDIAN is the headline because the ratio distribution is right-skewed (a few
very rare finishes trade at 50-1000x the base finish and drag the mean far
above the median -- compare the median/mean columns above). The 95% interval
is a percentile bootstrap over products (2000 draws, seed fixed for
reproducibility); cells below n=20 are suppressed rather than reported
with an unstable estimate.

## Reverse Holofoil / Normal

### By rarity (TCGplayer extRarity) (1 cell(s) below n=20 suppressed)

| group | n | median ratio [95% CI] | mean ratio | IQR |
| --- | --- | --- | --- | --- |
| Common | n=4816 | 2.857x  [2.778, 3.000] | 7.791 | [1.842, 6.660] |
| Uncommon | n=4421 | 2.744x  [2.667, 2.818] | 5.203 | [1.867, 5.129] |
| Rare | n=1881 | 2.237x  [2.167, 2.316] | 3.995 | [1.625, 4.019] |
| Holo Rare | n=42 | 2.330x  [1.802, 3.320] | 8.218 | [1.419, 4.297] |
| Promo | insufficient (n=1) |  |  |  |

### By era (via card_product_map -> cards.set_id)

| group | n | median ratio [95% CI] | mean ratio | IQR |
| --- | --- | --- | --- | --- |
| other | n=5198 | 4.361x  [4.231, 4.523] | 9.751 | [2.500, 9.780] |
| SWSH | n=1714 | 2.000x  [2.000, 2.095] | 2.719 | [1.571, 3.200] |
| SV | n=1706 | 1.824x  [1.793, 1.857] | 2.359 | [1.450, 2.500] |
| SM | n=1508 | 2.120x  [2.071, 2.172] | 2.994 | [1.700, 3.086] |
| unmapped | n=623 | 3.324x  [3.071, 3.750] | 5.707 | [2.080, 6.672] |
| ME | n=412 | 2.000x  [1.909, 2.111] | 2.288 | [1.549, 2.667] |

### By set -- top 10 of 119 by n

| group | n | median ratio [95% CI] | mean ratio | IQR |
| --- | --- | --- | --- | --- |
| SWSH08: Fusion Strike | n=204 | 2.263x  [1.975, 2.408] | 3.038 | [1.641, 3.758] |
| SM - Unified Minds | n=175 | 1.974x  [1.833, 2.095] | 2.790 | [1.631, 2.584] |
| SM - Cosmic Eclipse | n=171 | 2.464x  [2.250, 2.583] | 3.219 | [1.934, 3.284] |
| SV03: Obsidian Flames | n=166 | 1.750x  [1.667, 1.857] | 2.018 | [1.539, 2.195] |
| SV01: Scarlet & Violet Base Set | n=165 | 1.733x  [1.600, 1.818] | 1.869 | [1.375, 2.100] |
| SWSH01: Sword & Shield Base Set | n=157 | 2.636x  [2.304, 3.125] | 3.668 | [1.889, 4.209] |
| SM - Unbroken Bonds | n=154 | 1.965x  [1.889, 2.142] | 2.662 | [1.669, 2.598] |
| SM - Lost Thunder | n=153 | 2.255x  [2.111, 2.579] | 2.918 | [1.818, 3.292] |
| SV02: Paldea Evolved | n=151 | 1.545x  [1.476, 1.600] | 1.777 | [1.333, 1.908] |
| Aquapolis | n=149 | 3.322x  [2.973, 3.611] | 4.374 | [2.216, 5.580] |


### By price level (base-finish price decile)

| decile | base price range | n | median ratio [95% CI] | mean ratio |
| --- | --- | --- | --- | --- |
| 1 | $0.02-$0.09 | 1258 | 3.667x  [3.556, 3.750] | 4.321 |
| 2 | $0.09-$0.13 | 1006 | 2.000x  [2.000, 2.083] | 2.228 |
| 3 | $0.13-$0.18 | 1369 | 1.765x  [1.722, 1.800] | 2.041 |
| 4 | $0.18-$0.22 | 955 | 1.750x  [1.684, 1.800] | 2.244 |
| 5 | $0.22-$0.28 | 1054 | 2.000x  [1.958, 2.074] | 3.091 |
| 6 | $0.28-$0.37 | 1087 | 2.676x  [2.567, 2.833] | 5.526 |
| 7 | $0.37-$0.58 | 1110 | 4.673x  [4.289, 5.126] | 10.180 |
| 8 | $0.58-$1.17 | 1099 | 6.339x  [5.864, 6.850] | 14.608 |
| 9 | $1.17-$3.57 | 1107 | 6.297x  [5.799, 6.803] | 11.213 |
| 10 | $3.57-$279.99 | 1116 | 3.814x  [3.629, 4.030] | 6.035 |

Spearman rho(ratio, log base price) = **0.327** (p=5.69e-277, n=11161). Not negative -- the premium is not simply a cheap-card artifact, though see the cheapest decile below.


### Largest premiums (named examples, sanity-check these against the live market)

- **Dratini** (Legendary Collection, Common): $319.99 / $1.04 = **307.68x**
- **Machop** (Legendary Collection, Common): $200.00 / $0.66 = **303.03x**
- **Rattata** (Legendary Collection, Common): $149.99 / $0.52 = **288.44x**
- **Charmander** (Legendary Collection, Common): $616.33 / $2.24 = **275.15x**
- **Onix** (Legendary Collection, Common): $149.16 / $0.59 = **252.81x**

### Smallest / negative premiums (named examples)

- **Chatot** (Majestic Dawn, Common): $0.10 / $1.19 = **0.08x**
- **Skiploom** (HeartGold SoulSilver, Uncommon): $0.25 / $1.47 = **0.17x**
- **Weakness Guard** (Aquapolis, Uncommon): $14.66 / $57.34 = **0.26x**
- **Recover Energy** (Majestic Dawn, Uncommon): $0.25 / $0.54 = **0.46x**
- **Team Yell Grunt** (Champion's Path, Uncommon): $0.09 / $0.18 = **0.50x**

### Stability across the available dates (2026-07-22, 2026-08-25, 2026-08-26)

2026-07-22: 2.783x (n=11145); 2026-08-25: 2.720x (n=11160); 2026-08-26: 2.692x (n=11161) -- **not a trend**; see the single-snapshot caveat below.
## 1st Edition / Unlimited

### By rarity (TCGplayer extRarity)

| group | n | median ratio [95% CI] | mean ratio | IQR |
| --- | --- | --- | --- | --- |
| Common | n=306 | 3.280x  [3.101, 3.519] | 4.488 | [2.440, 4.848] |
| Uncommon | n=280 | 2.724x  [2.558, 2.964] | 3.509 | [1.993, 4.028] |
| Rare | n=174 | 2.168x  [2.103, 2.343] | 2.566 | [1.680, 2.789] |

### By era (via card_product_map -> cards.set_id) (1 cell(s) below n=20 suppressed)

| group | n | median ratio [95% CI] | mean ratio | IQR |
| --- | --- | --- | --- | --- |
| other | n=747 | 2.778x  [2.663, 2.921] | 3.674 | [2.061, 4.069] |
| unmapped | insufficient (n=13) |  |  |  |

### By set

| group | n | median ratio [95% CI] | mean ratio | IQR |
| --- | --- | --- | --- | --- |
| Gym Heroes | n=113 | 2.414x  [2.211, 2.855] | 2.713 | [1.801, 3.263] |
| Gym Challenge | n=112 | 2.231x  [2.141, 2.312] | 2.452 | [1.830, 2.934] |
| Neo Genesis | n=92 | 2.495x  [2.169, 2.623] | 2.743 | [1.777, 3.277] |
| Neo Destiny | n=89 | 2.560x  [2.345, 2.870] | 2.860 | [1.906, 3.447] |
| Base Set (Shadowless) | n=87 | 6.573x  [5.928, 7.917] | 8.592 | [4.149, 9.954] |
| Team Rocket | n=65 | 2.529x  [2.188, 2.747] | 2.722 | [1.820, 2.962] |
| Neo Discovery | n=57 | 3.069x  [2.679, 3.608] | 3.325 | [2.454, 4.296] |
| Neo Revelation | n=50 | 2.587x  [2.198, 3.017] | 2.712 | [2.023, 3.323] |
| Jungle | n=48 | 4.324x  [3.333, 5.627] | 4.773 | [2.429, 6.116] |
| Fossil | n=47 | 4.133x  [3.612, 5.231] | 5.010 | [2.934, 6.374] |


### By price level (base-finish price decile)

| decile | base price range | n | median ratio [95% CI] | mean ratio |
| --- | --- | --- | --- | --- |
| 1 | $0.26-$0.66 | 81 | 3.750x  [3.273, 4.067] | 4.431 |
| 2 | $0.66-$1.01 | 71 | 3.293x  [3.091, 4.000] | 5.889 |
| 3 | $1.01-$1.40 | 78 | 2.601x  [2.419, 3.036] | 3.507 |
| 4 | $1.40-$1.86 | 74 | 2.646x  [2.267, 3.225] | 3.597 |
| 5 | $1.86-$2.73 | 76 | 2.661x  [2.308, 3.356] | 3.793 |
| 6 | $2.73-$4.08 | 76 | 3.033x  [2.558, 3.612] | 3.689 |
| 7 | $4.08-$6.23 | 76 | 2.802x  [2.493, 3.167] | 3.603 |
| 8 | $6.23-$9.01 | 76 | 2.360x  [2.107, 2.697] | 2.860 |
| 9 | $9.01-$15.67 | 76 | 2.217x  [1.973, 2.537] | 2.625 |
| 10 | $15.67-$202.85 | 76 | 2.429x  [2.177, 2.778] | 2.974 |

Spearman rho(ratio, log base price) = **-0.282** (p=2.51e-15, n=760). Negative but well short of the -0.66 that killed the `spread` metric -- a partial cheap-card tilt, not the dominant story.


### Largest premiums (named examples, sanity-check these against the live market)

- **Energy Retrieval** (Base Set (Shadowless), Uncommon): $39.09 / $0.98 = **39.89x**
- **Gust of Wind** (Base Set (Shadowless), Common): $25.43 / $0.84 = **30.27x**
- **Grass Energy** (Base Set (Shadowless), Common): $25.06 / $0.90 = **27.84x**
- **Potion** (Base Set (Shadowless), Common): $18.70 / $0.73 = **25.62x**
- **Bill** (Base Set (Shadowless), Common): $28.99 / $1.40 = **20.71x**

### Smallest / negative premiums (named examples)

- **Fire Energy** (Gym Heroes, Common): $2.01 / $3.47 = **0.58x**
- **Fighting Energy** (Gym Challenge, Common): $1.29 / $2.07 = **0.62x**
- **Girafarig** (Neo Destiny, Common): $11.28 / $17.28 = **0.65x**
- **Water Energy** (Gym Challenge, Common): $3.18 / $4.15 = **0.77x**
- **Lightning Energy** (Gym Challenge, Common): $2.24 / $2.70 = **0.83x**

### Stability across the available dates (2026-07-22, 2026-08-25, 2026-08-26)

2026-07-22: 2.780x (n=761); 2026-08-25: 2.818x (n=760); 2026-08-26: 2.794x (n=760) -- **not a trend**; see the single-snapshot caveat below.

## Caveat 1: this is a cross-sectional snapshot, not a time series

`prices` carries only **3 distinct dates** (2026-07-22, 2026-08-25, 2026-08-26), covering about
five weeks of live-book pulls -- not a monthly panel like the rest of this
repo's models. Every number above is computed on the single latest date
(2026-08-26). The "stability across dates" line in each pair's section
recomputes the pooled median independently on each available date as a
same-number-twice sanity check (does it move day to day?) -- it is NOT
evidence of a trend in either direction, because five weeks of heavily
overlapping products carries far too little independent information to
support a trend claim, and the caption above says so explicitly rather than
implying otherwise.

## Caveat 2: selection bias -- dual-finish products are not a random sample

Of 30,457 priced products on 2026-08-26, 13,900
carry more than one `sub_type` and 16,557 carry exactly one. The two
groups are systematically different:

- **Price**: dual-finish products have a median base price of
  $0.34; single-finish products have a median
  price of $4.87 -- **14.3x**
  higher.
- **Rarity**: only **0.0%** of dual-finish
  products sit in a chase-tier rarity (Special Illustration Rare / Hyper Rare /
  Secret Rare / etc.), versus **8.9%** of
  single-finish products.

The mechanism is not mysterious: full-art and secret-rare cards mostly print in
one finish only and never get a Reverse Holofoil (or 1st Edition) counterpart
to compare against, so they are structurally excluded from this study. **"The
reverse-holo premium" describes the mainstream-set universe where a second
finish exists to be priced -- it is not a statement about the catalogue as a
whole, and in particular says nothing about premiums on the game's most
expensive chase cards, which mostly do not have the comparison this study
needs.**

## Caveat 3: is the ratio just a cheap-card artifact?

This repo already retired one metric (`spread`) after finding its headline
number correlated at Spearman rho -0.66 with log price -- i.e. it was mostly
measuring how cheap the card was, not a real signal. The same check applied
here (Spearman rho of ratio vs. log base-finish price, per pair) is in each
pair's price-level section above. Reading across pairs: none reach -0.66, and
`reverse_holo_over_normal` (the highest-volume pair) is **positive**, so the
premium is not simply shrinking toward 1x as price rises -- but the price-decile
tables show the CHEAPEST decile is visibly inflated in every pair, consistent
with TCGplayer's ~$0.09-0.10 listing floor mechanically exaggerating a ratio
between two already-near-floor prices. Read the decile table, not just the
correlation, before trusting any single-pair number at the bottom of the price
range.

## What this is NOT

- Not a time series and not a return forecast -- see Caveat 1.
- Not a claim about the whole catalogue -- see Caveat 2.
- Not wired into any page. This is an analysis artifact only.

Full per-product pair table: `variant_premium.csv` (same directory).
