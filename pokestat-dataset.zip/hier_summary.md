# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 1000 draws (1000 tune), target_accept = 0.9, non-centered
parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 579, max r_hat 1.0052. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 3623, max r_hat 1.0011. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.488 (90% interval 1.314 to 1.662) vs OLS point estimate 0.856 (SE 0.063)
- **beta_desir (desirability)**: hierarchical posterior mean 0.605 (90% interval 0.558 to 0.652) vs OLS point estimate 0.687 (SE 0.030)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.64 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -660.00 | 22.00 | 0.00 | 0.00 | 0.90 |
| flat | 1 | -720.00 | 14.00 | -60.00 | 14.00 | 0.10 |

Hierarchical: elpd_loo = -658.48 +/- 21.66, p_loo = 23.77, 1/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

Flat: elpd_loo = -720.40 +/- 14.28, p_loo = 3.79, 0/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

**Verdict**: hierarchical is favored by elpd_loo diff = +61.93 (dse = 14.00), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-186 | Giratina V | swsh11 | 850.15 | 17.85 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 206.10 | 7.15 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 517.78 | 25.66 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 196.12 | 6.09 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 10.64 | 64.92 | 0.017 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 14.70 | 86.96 | 0.022 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.15 | 464.20 | 0.028 | undervalued |
| me2pt5-251 | Sprigatito ex | me2pt5 | 1.76 | 10.19 | 0.029 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.827.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 5.090 | 3.795 | 1.295 |
| sv4pt5 | 9 | 4.084 | 3.915 | 0.169 |
| sv6pt5 | 11 | 3.600 | 3.510 | 0.090 |
| me55 | 12 | 4.247 | 4.097 | 0.149 |
| sv7 | 12 | 3.595 | 3.511 | 0.084 |
| sv3 | 13 | 3.511 | 3.443 | 0.068 |
| me5 | 13 | 3.623 | 3.548 | 0.075 |
| me2 | 13 | 2.877 | 2.866 | 0.010 |
| me4 | 13 | 3.368 | 3.314 | 0.054 |
| sv9 | 16 | 2.962 | 2.952 | 0.010 |
| sv3pt5 | 17 | 3.620 | 3.558 | 0.061 |
| me1 | 18 | 2.666 | 2.676 | -0.010 |
| sv1 | 20 | 2.909 | 2.903 | 0.006 |
| sv8pt5 | 23 | 2.361 | 2.387 | -0.026 |
| sv8 | 23 | 2.374 | 2.401 | -0.027 |
| sv6 | 23 | 2.422 | 2.448 | -0.027 |
| swsh9 | 23 | 2.537 | 2.552 | -0.015 |
| sv5 | 24 | 2.588 | 2.605 | -0.017 |
| me2pt5 | 24 | 2.635 | 2.643 | -0.008 |
| sv10 | 26 | 2.218 | 2.249 | -0.031 |
| swsh11 | 26 | 1.764 | 1.817 | -0.053 |
| swsh12 | 27 | 1.665 | 1.722 | -0.057 |
| sv4 | 30 | 2.420 | 2.437 | -0.018 |
| swsh10 | 33 | 1.609 | 1.656 | -0.047 |
| swsh7 | 53 | 1.893 | 1.918 | -0.024 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- me55-155: OLS = overvalued, hierarchical = fair
- sv1-227: OLS = undervalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-160: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-226: OLS = undervalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-175: OLS = fair, hierarchical = overvalued
- swsh10-176: OLS = undervalued, hierarchical = fair
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-207: OLS = undervalued, hierarchical = fair

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
