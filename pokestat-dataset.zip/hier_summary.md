# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 1000 draws (1000 tune), target_accept = 0.9, non-centered
parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 512, max r_hat 1.0045. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 3220, max r_hat 1.0009. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.489 (90% interval 1.321 to 1.661) vs OLS point estimate 0.829 (SE 0.063)
- **beta_desir (desirability)**: hierarchical posterior mean 0.603 (90% interval 0.557 to 0.649) vs OLS point estimate 0.695 (SE 0.031)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.63 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -660.00 | 22.00 | 0.00 | 0.00 | 0.90 |
| flat | 1 | -720.00 | 14.00 | -70.00 | 14.00 | 0.10 |

Hierarchical: elpd_loo = -656.29 +/- 21.90, p_loo = 23.84, 1/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

Flat: elpd_loo = -723.28 +/- 13.99, p_loo = 3.75, 0/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

**Verdict**: hierarchical is favored by elpd_loo diff = +66.98 (dse = 14.00), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh10-172 | Machamp V | swsh10 | 195.66 | 6.05 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 841.43 | 17.76 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 209.42 | 6.91 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 516.63 | 26.35 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 10.75 | 65.10 | 0.018 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 14.69 | 90.84 | 0.020 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.77 | 48.41 | 0.027 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.73 | 462.48 | 0.028 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.870.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 5.155 | 3.908 | 1.246 |
| sv4pt5 | 9 | 4.117 | 3.965 | 0.152 |
| sv6pt5 | 11 | 3.660 | 3.579 | 0.080 |
| me55 | 12 | 4.530 | 4.373 | 0.156 |
| sv7 | 12 | 3.606 | 3.538 | 0.068 |
| sv3 | 13 | 3.515 | 3.459 | 0.057 |
| me5 | 13 | 3.699 | 3.629 | 0.070 |
| me2 | 13 | 2.872 | 2.872 | 0.000 |
| me4 | 13 | 3.479 | 3.428 | 0.051 |
| sv9 | 16 | 2.989 | 2.979 | 0.010 |
| sv3pt5 | 17 | 3.669 | 3.613 | 0.056 |
| me1 | 18 | 2.697 | 2.708 | -0.012 |
| sv1 | 20 | 2.944 | 2.936 | 0.008 |
| sv8pt5 | 23 | 2.362 | 2.390 | -0.028 |
| sv8 | 23 | 2.410 | 2.435 | -0.026 |
| sv6 | 23 | 2.404 | 2.429 | -0.025 |
| swsh9 | 23 | 2.550 | 2.571 | -0.021 |
| sv5 | 24 | 2.563 | 2.580 | -0.017 |
| me2pt5 | 24 | 2.684 | 2.692 | -0.008 |
| sv10 | 26 | 2.273 | 2.303 | -0.030 |
| swsh11 | 26 | 1.752 | 1.803 | -0.051 |
| swsh12 | 27 | 1.675 | 1.732 | -0.057 |
| sv4 | 30 | 2.385 | 2.406 | -0.021 |
| swsh10 | 33 | 1.640 | 1.688 | -0.047 |
| swsh7 | 53 | 1.901 | 1.924 | -0.023 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-116: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- me55-155: OLS = overvalued, hierarchical = fair
- sv1-243: OLS = overvalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-184: OLS = fair, hierarchical = overvalued
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-207: OLS = fair, hierarchical = undervalued
- swsh7-218: OLS = fair, hierarchical = overvalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
