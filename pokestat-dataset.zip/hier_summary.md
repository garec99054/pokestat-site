# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 865, max r_hat 1.0030. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7550, max r_hat 1.0004. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.472 (90% interval 1.304 to 1.639) vs OLS point estimate 0.875 (SE 0.061)
- **beta_desir (desirability)**: hierarchical posterior mean 0.599 (90% interval 0.553 to 0.646) vs OLS point estimate 0.671 (SE 0.030)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.64 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -655.44 | 21.77 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -712.93 | 14.45 | -57.49 | 13.44 | 0.11 |

Hierarchical: elpd_loo = -655.44 +/- 21.77, p_loo = 23.56, 1/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: True.

Flat: elpd_loo = -712.93 +/- 14.45, p_loo = 3.79, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: the LOO comparison is unreliable; resolve its warnings before interpreting a model preference.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-186 | Giratina V | swsh11 | 847.55 | 18.43 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 203.67 | 7.06 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 193.48 | 6.24 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 514.00 | 25.71 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.97 | 61.42 | 0.018 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.26 | 450.10 | 0.027 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.90 | 48.13 | 0.028 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.20 | 86.89 | 0.028 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.803.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.961 | 3.692 | 1.269 |
| sv4pt5 | 9 | 4.075 | 3.890 | 0.185 |
| sv6pt5 | 11 | 3.538 | 3.451 | 0.087 |
| me55 | 12 | 3.873 | 3.752 | 0.121 |
| sv7 | 12 | 3.566 | 3.479 | 0.087 |
| sv3 | 13 | 3.462 | 3.395 | 0.067 |
| me5 | 13 | 3.546 | 3.466 | 0.080 |
| me2 | 13 | 2.840 | 2.836 | 0.005 |
| me4 | 13 | 3.403 | 3.337 | 0.066 |
| sv9 | 16 | 2.966 | 2.952 | 0.013 |
| sv3pt5 | 17 | 3.618 | 3.552 | 0.067 |
| me1 | 18 | 2.661 | 2.672 | -0.011 |
| sv1 | 20 | 2.912 | 2.904 | 0.008 |
| sv8pt5 | 23 | 2.345 | 2.372 | -0.026 |
| sv8 | 23 | 2.351 | 2.379 | -0.028 |
| sv6 | 23 | 2.402 | 2.426 | -0.024 |
| swsh9 | 23 | 2.525 | 2.540 | -0.015 |
| sv5 | 24 | 2.570 | 2.582 | -0.012 |
| me2pt5 | 24 | 2.597 | 2.607 | -0.010 |
| sv10 | 26 | 2.202 | 2.235 | -0.033 |
| swsh11 | 26 | 1.775 | 1.830 | -0.055 |
| swsh12 | 27 | 1.668 | 1.729 | -0.061 |
| sv4 | 30 | 2.418 | 2.436 | -0.018 |
| swsh10 | 33 | 1.618 | 1.668 | -0.050 |
| swsh7 | 53 | 1.919 | 1.944 | -0.025 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv6pt5-95: OLS = fair, hierarchical = undervalued
- sv7-160: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8pt5-163: OLS = fair, hierarchical = undervalued
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-175: OLS = fair, hierarchical = overvalued
- swsh10-176: OLS = undervalued, hierarchical = fair
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-218: OLS = fair, hierarchical = overvalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
