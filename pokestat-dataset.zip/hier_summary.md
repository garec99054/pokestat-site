# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 24 sets, n = 491 chase cards. Sampled with
4 chains x 1000 draws (1000 tune), target_accept = 0.9, non-centered
parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 546, max r_hat 1.0100. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 3685, max r_hat 1.0000. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.496 (90% interval 1.328 to 1.664) vs OLS point estimate 0.892 (SE 0.065)
- **beta_desir (desirability)**: hierarchical posterior mean 0.594 (90% interval 0.548 to 0.641) vs OLS point estimate 0.658 (SE 0.032)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.63 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -650.00 | 21.00 | 0.00 | 0.00 | 0.90 |
| flat | 1 | -710.00 | 14.00 | -60.00 | 14.00 | 0.10 |

Hierarchical: elpd_loo = -645.12 +/- 21.50, p_loo = 23.17, 1/491 observations with an unreliable (Pareto k > 0.7) LOO estimate.

Flat: elpd_loo = -707.75 +/- 13.96, p_loo = 3.71, 0/491 observations with an unreliable (Pareto k > 0.7) LOO estimate.

**Verdict**: hierarchical is favored by elpd_loo diff = +62.63 (dse = 14.00), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-186 | Giratina V | swsh11 | 826.57 | 18.22 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 211.61 | 7.34 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 199.29 | 6.41 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 525.93 | 25.23 | 0.999 | overvalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 14.86 | 93.92 | 0.021 | undervalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.66 | 61.67 | 0.022 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.39 | 49.84 | 0.025 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 85.05 | 445.51 | 0.030 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.832.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 5.009 | 3.736 | 1.274 |
| sv4pt5 | 9 | 4.105 | 3.926 | 0.179 |
| sv6pt5 | 11 | 3.612 | 3.524 | 0.088 |
| sv7 | 12 | 3.600 | 3.517 | 0.084 |
| sv3 | 13 | 3.599 | 3.521 | 0.079 |
| me4 | 13 | 3.586 | 3.509 | 0.077 |
| me5 | 13 | 3.872 | 3.768 | 0.104 |
| me2 | 13 | 2.995 | 2.980 | 0.015 |
| sv9 | 16 | 3.127 | 3.107 | 0.020 |
| sv3pt5 | 17 | 3.739 | 3.667 | 0.072 |
| me1 | 18 | 2.753 | 2.757 | -0.004 |
| sv1 | 20 | 2.970 | 2.964 | 0.007 |
| sv8pt5 | 23 | 2.398 | 2.424 | -0.026 |
| swsh9 | 23 | 2.513 | 2.533 | -0.020 |
| sv6 | 23 | 2.417 | 2.442 | -0.026 |
| sv8 | 23 | 2.424 | 2.448 | -0.024 |
| me2pt5 | 24 | 2.759 | 2.761 | -0.002 |
| sv5 | 24 | 2.660 | 2.671 | -0.011 |
| swsh11 | 26 | 1.739 | 1.800 | -0.061 |
| sv10 | 26 | 2.332 | 2.361 | -0.029 |
| swsh12 | 27 | 1.651 | 1.712 | -0.061 |
| sv4 | 30 | 2.494 | 2.511 | -0.017 |
| swsh10 | 33 | 1.643 | 1.693 | -0.051 |
| swsh7 | 53 | 1.929 | 1.953 | -0.024 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-116: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv1-243: OLS = overvalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv6pt5-92: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-173: OLS = undervalued, hierarchical = fair
- swsh10-175: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-184: OLS = fair, hierarchical = overvalued
- swsh11-197: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-172: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-182: OLS = fair, hierarchical = overvalued
- swsh7-208: OLS = fair, hierarchical = undervalued

## Limitations

- n = 491 cards across 24 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
