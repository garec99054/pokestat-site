# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 1055, max r_hat 1.0049. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7729, max r_hat 1.0007. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.456 (90% interval 1.294 to 1.618) vs OLS point estimate 0.867 (SE 0.059)
- **beta_desir (desirability)**: hierarchical posterior mean 0.602 (90% interval 0.555 to 0.647) vs OLS point estimate 0.671 (SE 0.029)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.64 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -648.39 | 22.21 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -705.10 | 14.89 | -56.71 | 13.40 | 0.11 |

Hierarchical: elpd_loo = -648.39 +/- 22.21, p_loo = 23.53, 1/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: True.

Flat: elpd_loo = -705.10 +/- 14.89, p_loo = 3.87, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: the LOO comparison is unreliable; resolve its warnings before interpreting a model preference.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh10-172 | Machamp V | swsh10 | 191.87 | 6.44 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 477.54 | 24.35 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 203.23 | 6.78 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 855.69 | 18.33 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.47 | 61.13 | 0.017 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.33 | 448.52 | 0.026 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.31 | 86.79 | 0.026 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.58 | 46.55 | 0.027 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.748.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.912 | 3.646 | 1.266 |
| sv4pt5 | 9 | 4.037 | 3.851 | 0.185 |
| sv6pt5 | 11 | 3.552 | 3.449 | 0.103 |
| me55 | 12 | 3.766 | 3.660 | 0.107 |
| sv7 | 12 | 3.537 | 3.449 | 0.088 |
| sv3 | 13 | 3.436 | 3.366 | 0.070 |
| me5 | 13 | 3.507 | 3.427 | 0.080 |
| me2 | 13 | 2.767 | 2.764 | 0.004 |
| me4 | 13 | 3.315 | 3.258 | 0.057 |
| sv9 | 16 | 2.890 | 2.877 | 0.013 |
| sv3pt5 | 17 | 3.584 | 3.518 | 0.066 |
| me1 | 18 | 2.589 | 2.600 | -0.011 |
| sv1 | 20 | 2.879 | 2.867 | 0.012 |
| sv8pt5 | 23 | 2.288 | 2.313 | -0.026 |
| sv8 | 23 | 2.320 | 2.346 | -0.026 |
| sv6 | 23 | 2.354 | 2.378 | -0.024 |
| swsh9 | 23 | 2.472 | 2.488 | -0.016 |
| sv5 | 24 | 2.558 | 2.568 | -0.010 |
| me2pt5 | 24 | 2.469 | 2.487 | -0.018 |
| sv10 | 26 | 2.125 | 2.160 | -0.034 |
| swsh11 | 26 | 1.765 | 1.816 | -0.051 |
| swsh12 | 27 | 1.632 | 1.691 | -0.059 |
| sv4 | 30 | 2.335 | 2.353 | -0.018 |
| swsh10 | 33 | 1.626 | 1.672 | -0.046 |
| swsh7 | 53 | 1.923 | 1.945 | -0.022 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv10-215: OLS = undervalued, hierarchical = fair
- sv10-216: OLS = undervalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-226: OLS = undervalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-173: OLS = undervalued, hierarchical = fair
- swsh10-176: OLS = undervalued, hierarchical = fair
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-210: OLS = fair, hierarchical = undervalued
- swsh7-218: OLS = fair, hierarchical = overvalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
