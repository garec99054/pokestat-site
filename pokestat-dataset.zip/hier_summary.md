# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 1352, max r_hat 1.0026. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7816, max r_hat 1.0007. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.385 (90% interval 1.224 to 1.547) vs OLS point estimate 0.882 (SE 0.057)
- **beta_desir (desirability)**: hierarchical posterior mean 0.594 (90% interval 0.549 to 0.639) vs OLS point estimate 0.649 (SE 0.028)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.65 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -643.25 | 22.01 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -689.22 | 15.78 | -45.98 | 12.02 | 0.11 |

Hierarchical: elpd_loo = -643.25 +/- 22.01, p_loo = 23.04, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

Flat: elpd_loo = -689.22 +/- 15.78, p_loo = 3.89, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: hierarchical is favored by elpd_loo diff = +45.98 (dse = 12.02), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-186 | Giratina V | swsh11 | 820.91 | 18.16 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 196.35 | 6.99 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 184.89 | 6.43 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 441.03 | 24.46 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.53 | 55.41 | 0.020 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.31 | 87.68 | 0.024 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 79.33 | 415.84 | 0.026 | undervalued |
| swsh7-211 | Sylveon VMAX | swsh7 | 53.61 | 263.73 | 0.037 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.639.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.678 | 3.378 | 1.300 |
| sv4pt5 | 9 | 4.006 | 3.772 | 0.234 |
| sv6pt5 | 11 | 3.384 | 3.275 | 0.108 |
| me55 | 12 | 3.269 | 3.185 | 0.085 |
| sv7 | 12 | 3.390 | 3.288 | 0.102 |
| sv3 | 13 | 3.275 | 3.197 | 0.078 |
| me5 | 13 | 3.257 | 3.179 | 0.078 |
| me2 | 13 | 2.700 | 2.692 | 0.008 |
| me4 | 13 | 3.131 | 3.070 | 0.061 |
| sv9 | 16 | 2.734 | 2.725 | 0.008 |
| sv3pt5 | 17 | 3.426 | 3.348 | 0.079 |
| me1 | 18 | 2.512 | 2.524 | -0.011 |
| sv1 | 20 | 2.854 | 2.835 | 0.020 |
| sv8pt5 | 23 | 2.223 | 2.253 | -0.030 |
| sv8 | 23 | 2.296 | 2.322 | -0.026 |
| sv6 | 23 | 2.258 | 2.286 | -0.028 |
| swsh9 | 23 | 2.434 | 2.449 | -0.015 |
| sv5 | 24 | 2.481 | 2.493 | -0.011 |
| me2pt5 | 24 | 2.293 | 2.319 | -0.027 |
| sv10 | 26 | 2.018 | 2.060 | -0.042 |
| swsh11 | 26 | 1.803 | 1.862 | -0.059 |
| swsh12 | 27 | 1.613 | 1.681 | -0.068 |
| sv4 | 30 | 2.316 | 2.337 | -0.021 |
| swsh10 | 33 | 1.655 | 1.708 | -0.053 |
| swsh7 | 53 | 1.998 | 2.020 | -0.021 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv1-227: OLS = fair, hierarchical = undervalued
- sv1-243: OLS = overvalued, hierarchical = fair
- sv10-208: OLS = undervalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv4pt5-242: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-226: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv8pt5-161: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-173: OLS = undervalued, hierarchical = fair
- swsh10-175: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-207: OLS = fair, hierarchical = undervalued
- swsh7-210: OLS = fair, hierarchical = undervalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
