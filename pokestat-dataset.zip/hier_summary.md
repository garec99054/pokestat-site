# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 1054, max r_hat 1.0037. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7915, max r_hat 1.0010. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.438 (90% interval 1.274 to 1.601) vs OLS point estimate 0.860 (SE 0.059)
- **beta_desir (desirability)**: hierarchical posterior mean 0.603 (90% interval 0.557 to 0.649) vs OLS point estimate 0.670 (SE 0.029)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.65 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -645.51 | 22.33 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -702.00 | 14.95 | -56.49 | 13.39 | 0.11 |

Hierarchical: elpd_loo = -645.51 +/- 22.33, p_loo = 23.34, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

Flat: elpd_loo = -702.00 +/- 14.95, p_loo = 3.77, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: hierarchical is favored by elpd_loo diff = +56.49 (dse = 13.39), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-180 | Aerodactyl V | swsh11 | 203.23 | 6.69 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 855.69 | 18.29 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 474.42 | 24.01 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 191.22 | 6.52 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.38 | 61.00 | 0.016 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.11 | 87.38 | 0.025 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.42 | 45.24 | 0.026 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.59 | 439.93 | 0.028 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.741.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.839 | 3.600 | 1.239 |
| sv4pt5 | 9 | 4.024 | 3.835 | 0.189 |
| sv6pt5 | 11 | 3.566 | 3.462 | 0.104 |
| me55 | 12 | 3.724 | 3.613 | 0.111 |
| sv7 | 12 | 3.509 | 3.423 | 0.086 |
| sv3 | 13 | 3.392 | 3.323 | 0.069 |
| me5 | 13 | 3.482 | 3.404 | 0.078 |
| me2 | 13 | 2.751 | 2.748 | 0.004 |
| me4 | 13 | 3.336 | 3.275 | 0.061 |
| sv9 | 16 | 2.893 | 2.881 | 0.012 |
| sv3pt5 | 17 | 3.561 | 3.490 | 0.070 |
| me1 | 18 | 2.586 | 2.599 | -0.013 |
| sv1 | 20 | 2.867 | 2.857 | 0.010 |
| sv8pt5 | 23 | 2.300 | 2.328 | -0.028 |
| sv8 | 23 | 2.318 | 2.343 | -0.024 |
| sv6 | 23 | 2.372 | 2.395 | -0.023 |
| swsh9 | 23 | 2.469 | 2.487 | -0.018 |
| sv5 | 24 | 2.557 | 2.569 | -0.012 |
| me2pt5 | 24 | 2.473 | 2.490 | -0.017 |
| sv10 | 26 | 2.082 | 2.119 | -0.037 |
| swsh11 | 26 | 1.769 | 1.823 | -0.054 |
| swsh12 | 27 | 1.621 | 1.681 | -0.060 |
| sv4 | 30 | 2.357 | 2.377 | -0.020 |
| swsh10 | 33 | 1.642 | 1.694 | -0.052 |
| swsh7 | 53 | 1.934 | 1.954 | -0.020 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv10-215: OLS = undervalued, hierarchical = fair
- sv10-216: OLS = undervalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-176: OLS = undervalued, hierarchical = fair
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-207: OLS = fair, hierarchical = undervalued
- swsh7-210: OLS = fair, hierarchical = undervalued
- swsh7-218: OLS = fair, hierarchical = overvalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
