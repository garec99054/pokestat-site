# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 1000 draws (1000 tune), target_accept = 0.9, non-centered
parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 571, max r_hat 1.0032. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 3420, max r_hat 1.0013. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.494 (90% interval 1.325 to 1.662) vs OLS point estimate 0.840 (SE 0.064)
- **beta_desir (desirability)**: hierarchical posterior mean 0.602 (90% interval 0.553 to 0.649) vs OLS point estimate 0.689 (SE 0.031)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.63 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -660.00 | 22.00 | 0.00 | 0.00 | 0.90 |
| flat | 1 | -720.00 | 14.00 | -70.00 | 14.00 | 0.10 |

Hierarchical: elpd_loo = -657.15 +/- 21.91, p_loo = 23.71, 0/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

Flat: elpd_loo = -723.12 +/- 14.12, p_loo = 3.77, 0/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

**Verdict**: hierarchical is favored by elpd_loo diff = +65.97 (dse = 14.00), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh10-172 | Machamp V | swsh10 | 195.66 | 6.06 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 208.96 | 6.89 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 518.63 | 26.02 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 841.43 | 17.78 | 1.000 | overvalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 14.31 | 88.43 | 0.019 | undervalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 10.75 | 64.84 | 0.020 | undervalued |
| me2pt5-251 | Sprigatito ex | me2pt5 | 1.76 | 10.17 | 0.027 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.77 | 47.34 | 0.028 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.866.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 5.162 | 3.900 | 1.262 |
| sv4pt5 | 9 | 4.132 | 3.977 | 0.155 |
| sv6pt5 | 11 | 3.650 | 3.570 | 0.080 |
| me55 | 12 | 4.379 | 4.234 | 0.146 |
| sv7 | 12 | 3.605 | 3.535 | 0.070 |
| me2 | 13 | 2.857 | 2.856 | 0.001 |
| me4 | 13 | 3.448 | 3.398 | 0.050 |
| me5 | 13 | 3.717 | 3.640 | 0.077 |
| sv3 | 13 | 3.523 | 3.468 | 0.055 |
| sv9 | 16 | 2.986 | 2.978 | 0.008 |
| sv3pt5 | 17 | 3.666 | 3.609 | 0.057 |
| me1 | 18 | 2.682 | 2.695 | -0.013 |
| sv1 | 20 | 2.969 | 2.961 | 0.008 |
| sv8pt5 | 23 | 2.362 | 2.387 | -0.025 |
| sv8 | 23 | 2.419 | 2.442 | -0.023 |
| swsh9 | 23 | 2.549 | 2.568 | -0.018 |
| sv6 | 23 | 2.422 | 2.448 | -0.026 |
| me2pt5 | 24 | 2.667 | 2.675 | -0.008 |
| sv5 | 24 | 2.588 | 2.602 | -0.014 |
| sv10 | 26 | 2.261 | 2.287 | -0.026 |
| swsh11 | 26 | 1.754 | 1.806 | -0.052 |
| swsh12 | 27 | 1.674 | 1.729 | -0.055 |
| sv4 | 30 | 2.402 | 2.421 | -0.019 |
| swsh10 | 33 | 1.625 | 1.671 | -0.046 |
| swsh7 | 53 | 1.893 | 1.917 | -0.024 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-116: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- me55-155: OLS = overvalued, hierarchical = fair
- sv1-243: OLS = overvalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-210: OLS = fair, hierarchical = undervalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
