# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 1051, max r_hat 1.0020. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7301, max r_hat 1.0007. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.461 (90% interval 1.292 to 1.628) vs OLS point estimate 0.875 (SE 0.059)
- **beta_desir (desirability)**: hierarchical posterior mean 0.606 (90% interval 0.561 to 0.652) vs OLS point estimate 0.675 (SE 0.029)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.65 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -649.59 | 22.05 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -706.09 | 14.83 | -56.50 | 13.26 | 0.11 |

Hierarchical: elpd_loo = -649.59 +/- 22.05, p_loo = 23.13, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

Flat: elpd_loo = -706.09 +/- 14.83, p_loo = 3.78, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: hierarchical is favored by elpd_loo diff = +56.50 (dse = 13.26), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-186 | Giratina V | swsh11 | 854.73 | 18.72 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 203.23 | 6.83 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 191.87 | 6.34 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 488.36 | 24.90 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.52 | 62.86 | 0.015 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.17 | 88.04 | 0.025 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.48 | 46.00 | 0.027 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.47 | 451.83 | 0.027 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.744.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.869 | 3.630 | 1.239 |
| sv4pt5 | 9 | 4.060 | 3.873 | 0.187 |
| sv6pt5 | 11 | 3.531 | 3.435 | 0.096 |
| me55 | 12 | 3.755 | 3.645 | 0.110 |
| sv7 | 12 | 3.524 | 3.437 | 0.086 |
| sv3 | 13 | 3.433 | 3.362 | 0.071 |
| me5 | 13 | 3.514 | 3.436 | 0.077 |
| me2 | 13 | 2.765 | 2.763 | 0.002 |
| me4 | 13 | 3.325 | 3.268 | 0.057 |
| sv9 | 16 | 2.901 | 2.888 | 0.013 |
| sv3pt5 | 17 | 3.548 | 3.481 | 0.066 |
| me1 | 18 | 2.619 | 2.626 | -0.007 |
| sv1 | 20 | 2.867 | 2.860 | 0.008 |
| sv8pt5 | 23 | 2.273 | 2.300 | -0.027 |
| sv8 | 23 | 2.284 | 2.312 | -0.028 |
| sv6 | 23 | 2.330 | 2.359 | -0.028 |
| swsh9 | 23 | 2.474 | 2.490 | -0.016 |
| sv5 | 24 | 2.550 | 2.560 | -0.010 |
| me2pt5 | 24 | 2.486 | 2.501 | -0.015 |
| sv10 | 26 | 2.118 | 2.154 | -0.037 |
| swsh11 | 26 | 1.776 | 1.828 | -0.052 |
| swsh12 | 27 | 1.634 | 1.695 | -0.060 |
| sv4 | 30 | 2.359 | 2.379 | -0.019 |
| swsh10 | 33 | 1.629 | 1.678 | -0.049 |
| swsh7 | 53 | 1.914 | 1.937 | -0.023 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2-108: OLS = undervalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv10-216: OLS = undervalued, hierarchical = fair
- sv3-222: OLS = overvalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-240: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-226: OLS = undervalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-208: OLS = fair, hierarchical = undervalued
- swsh7-210: OLS = fair, hierarchical = undervalued
- swsh9-163: OLS = undervalued, hierarchical = fair

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
