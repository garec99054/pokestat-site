# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 913, max r_hat 1.0033. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7719, max r_hat 1.0003. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.414 (90% interval 1.252 to 1.578) vs OLS point estimate 0.856 (SE 0.058)
- **beta_desir (desirability)**: hierarchical posterior mean 0.603 (90% interval 0.557 to 0.648) vs OLS point estimate 0.670 (SE 0.029)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.65 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -645.08 | 22.29 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -698.87 | 15.14 | -53.78 | 13.08 | 0.11 |

Hierarchical: elpd_loo = -645.08 +/- 22.29, p_loo = 23.27, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

Flat: elpd_loo = -698.87 +/- 15.14, p_loo = 3.88, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: hierarchical is favored by elpd_loo diff = +53.78 (dse = 13.08), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-180 | Aerodactyl V | swsh11 | 202.67 | 6.74 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 855.69 | 18.42 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 471.26 | 24.42 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 190.78 | 6.57 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.44 | 60.85 | 0.016 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.27 | 47.96 | 0.020 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.59 | 436.50 | 0.028 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.19 | 85.83 | 0.028 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.733.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.780 | 3.543 | 1.236 |
| sv4pt5 | 9 | 4.001 | 3.805 | 0.196 |
| sv6pt5 | 11 | 3.537 | 3.434 | 0.103 |
| me55 | 12 | 3.667 | 3.557 | 0.111 |
| sv7 | 12 | 3.485 | 3.394 | 0.091 |
| sv3 | 13 | 3.350 | 3.280 | 0.070 |
| me5 | 13 | 3.448 | 3.366 | 0.081 |
| me2 | 13 | 2.767 | 2.764 | 0.002 |
| me4 | 13 | 3.317 | 3.250 | 0.067 |
| sv9 | 16 | 2.850 | 2.838 | 0.012 |
| sv3pt5 | 17 | 3.529 | 3.458 | 0.071 |
| me1 | 18 | 2.590 | 2.599 | -0.009 |
| sv1 | 20 | 2.852 | 2.842 | 0.010 |
| sv8pt5 | 23 | 2.306 | 2.335 | -0.029 |
| sv8 | 23 | 2.355 | 2.380 | -0.025 |
| sv6 | 23 | 2.334 | 2.360 | -0.026 |
| swsh9 | 23 | 2.461 | 2.481 | -0.020 |
| sv5 | 24 | 2.559 | 2.572 | -0.013 |
| me2pt5 | 24 | 2.467 | 2.482 | -0.015 |
| sv10 | 26 | 2.096 | 2.133 | -0.037 |
| swsh11 | 26 | 1.782 | 1.837 | -0.055 |
| swsh12 | 27 | 1.627 | 1.689 | -0.063 |
| sv4 | 30 | 2.359 | 2.379 | -0.020 |
| swsh10 | 33 | 1.661 | 1.711 | -0.050 |
| swsh7 | 53 | 1.950 | 1.974 | -0.024 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv10-215: OLS = undervalued, hierarchical = fair
- sv10-216: OLS = undervalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv6pt5-92: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-173: OLS = undervalued, hierarchical = fair
- swsh10-176: OLS = undervalued, hierarchical = fair
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-218: OLS = fair, hierarchical = overvalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
