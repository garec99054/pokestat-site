# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 1034, max r_hat 1.0049. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7320, max r_hat 1.0002. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.474 (90% interval 1.305 to 1.639) vs OLS point estimate 0.874 (SE 0.060)
- **beta_desir (desirability)**: hierarchical posterior mean 0.606 (90% interval 0.560 to 0.653) vs OLS point estimate 0.677 (SE 0.030)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.64 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -651.41 | 22.08 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -709.99 | 14.68 | -58.58 | 13.55 | 0.11 |

Hierarchical: elpd_loo = -651.41 +/- 22.08, p_loo = 23.37, 1/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: True.

Flat: elpd_loo = -709.99 +/- 14.68, p_loo = 3.77, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: the LOO comparison is unreliable; resolve its warnings before interpreting a model preference.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-180 | Aerodactyl V | swsh11 | 203.23 | 6.89 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 851.13 | 18.39 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 505.76 | 25.36 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 193.31 | 6.23 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.83 | 62.25 | 0.018 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.26 | 453.49 | 0.027 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.31 | 89.51 | 0.027 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.95 | 46.73 | 0.029 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.785.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.952 | 3.684 | 1.269 |
| sv4pt5 | 9 | 4.080 | 3.896 | 0.184 |
| sv6pt5 | 11 | 3.558 | 3.468 | 0.090 |
| me55 | 12 | 3.843 | 3.725 | 0.117 |
| sv7 | 12 | 3.578 | 3.491 | 0.087 |
| sv3 | 13 | 3.438 | 3.374 | 0.065 |
| me5 | 13 | 3.547 | 3.467 | 0.080 |
| me2 | 13 | 2.841 | 2.833 | 0.007 |
| me4 | 13 | 3.411 | 3.346 | 0.064 |
| sv9 | 16 | 2.935 | 2.924 | 0.011 |
| sv3pt5 | 17 | 3.593 | 3.528 | 0.065 |
| me1 | 18 | 2.624 | 2.636 | -0.011 |
| sv1 | 20 | 2.909 | 2.899 | 0.010 |
| sv8pt5 | 23 | 2.318 | 2.346 | -0.027 |
| sv8 | 23 | 2.331 | 2.358 | -0.026 |
| sv6 | 23 | 2.333 | 2.359 | -0.026 |
| swsh9 | 23 | 2.507 | 2.524 | -0.017 |
| sv5 | 24 | 2.526 | 2.542 | -0.015 |
| me2pt5 | 24 | 2.546 | 2.559 | -0.013 |
| sv10 | 26 | 2.172 | 2.207 | -0.034 |
| swsh11 | 26 | 1.775 | 1.828 | -0.053 |
| swsh12 | 27 | 1.668 | 1.722 | -0.054 |
| sv4 | 30 | 2.401 | 2.417 | -0.016 |
| swsh10 | 33 | 1.614 | 1.663 | -0.049 |
| swsh7 | 53 | 1.908 | 1.932 | -0.024 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv1-246: OLS = overvalued, hierarchical = fair
- sv10-216: OLS = undervalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-160: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-173: OLS = undervalued, hierarchical = fair
- swsh10-175: OLS = fair, hierarchical = overvalued
- swsh10-176: OLS = undervalued, hierarchical = fair
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-207: OLS = fair, hierarchical = undervalued
- swsh7-210: OLS = fair, hierarchical = undervalued
- swsh7-218: OLS = fair, hierarchical = overvalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
