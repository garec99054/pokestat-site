# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 1000 draws (1000 tune), target_accept = 0.9, non-centered
parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 353, max r_hat 1.0189. Flags: min ESS_bulk 353 < 400; max r_hat 1.019 > 1.01.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 3597, max r_hat 1.0009. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.490 (90% interval 1.322 to 1.651) vs OLS point estimate 0.824 (SE 0.063)
- **beta_desir (desirability)**: hierarchical posterior mean 0.604 (90% interval 0.558 to 0.652) vs OLS point estimate 0.698 (SE 0.031)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.63 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -660.00 | 22.00 | 0.00 | 0.00 | 0.90 |
| flat | 1 | -720.00 | 14.00 | -70.00 | 14.00 | 0.10 |

Hierarchical: elpd_loo = -655.99 +/- 21.95, p_loo = 23.57, 1/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

Flat: elpd_loo = -723.75 +/- 14.04, p_loo = 3.80, 0/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

**Verdict**: hierarchical is favored by elpd_loo diff = +67.75 (dse = 14.00), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh10-172 | Machamp V | swsh10 | 195.66 | 6.16 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 209.42 | 6.89 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 841.43 | 17.60 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 516.63 | 25.93 | 1.000 | overvalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 14.69 | 90.96 | 0.019 | undervalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 10.42 | 65.69 | 0.019 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.67 | 49.41 | 0.024 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.73 | 465.20 | 0.028 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.860.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 5.162 | 3.952 | 1.210 |
| sv4pt5 | 9 | 4.121 | 3.966 | 0.155 |
| sv6pt5 | 11 | 3.647 | 3.573 | 0.074 |
| me55 | 12 | 4.562 | 4.406 | 0.156 |
| sv7 | 12 | 3.612 | 3.544 | 0.068 |
| me2 | 13 | 2.920 | 2.912 | 0.008 |
| me4 | 13 | 3.458 | 3.410 | 0.048 |
| me5 | 13 | 3.746 | 3.664 | 0.081 |
| sv3 | 13 | 3.511 | 3.457 | 0.054 |
| sv9 | 16 | 3.000 | 2.994 | 0.006 |
| sv3pt5 | 17 | 3.670 | 3.617 | 0.053 |
| me1 | 18 | 2.698 | 2.706 | -0.008 |
| sv1 | 20 | 2.935 | 2.928 | 0.007 |
| sv8pt5 | 23 | 2.377 | 2.400 | -0.023 |
| sv8 | 23 | 2.413 | 2.437 | -0.024 |
| swsh9 | 23 | 2.538 | 2.555 | -0.017 |
| sv6 | 23 | 2.415 | 2.436 | -0.021 |
| me2pt5 | 24 | 2.672 | 2.678 | -0.006 |
| sv5 | 24 | 2.583 | 2.596 | -0.013 |
| sv10 | 26 | 2.279 | 2.306 | -0.027 |
| swsh11 | 26 | 1.749 | 1.799 | -0.050 |
| swsh12 | 27 | 1.665 | 1.717 | -0.052 |
| sv4 | 30 | 2.394 | 2.416 | -0.022 |
| swsh10 | 33 | 1.637 | 1.681 | -0.043 |
| swsh7 | 53 | 1.901 | 1.921 | -0.020 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-116: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- me55-152: OLS = overvalued, hierarchical = fair
- me55-155: OLS = overvalued, hierarchical = fair
- sv1-243: OLS = overvalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-167: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-184: OLS = fair, hierarchical = overvalued
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
