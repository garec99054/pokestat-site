# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 1229, max r_hat 1.0026. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7428, max r_hat 1.0008. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.396 (90% interval 1.234 to 1.558) vs OLS point estimate 0.886 (SE 0.057)
- **beta_desir (desirability)**: hierarchical posterior mean 0.593 (90% interval 0.548 to 0.637) vs OLS point estimate 0.648 (SE 0.028)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.65 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -642.82 | 22.32 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -691.68 | 15.67 | -48.86 | 12.59 | 0.11 |

Hierarchical: elpd_loo = -642.82 +/- 22.32, p_loo = 23.02, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

Flat: elpd_loo = -691.68 +/- 15.67, p_loo = 3.96, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: hierarchical is favored by elpd_loo diff = +48.86 (dse = 12.59), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-180 | Aerodactyl V | swsh11 | 199.36 | 7.10 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 820.91 | 17.17 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 187.54 | 6.48 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 444.35 | 23.48 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.50 | 57.69 | 0.016 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.30 | 86.07 | 0.025 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 80.16 | 417.75 | 0.025 | undervalued |
| swsh7-211 | Sylveon VMAX | swsh7 | 53.76 | 267.86 | 0.035 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.668.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.695 | 3.435 | 1.261 |
| sv4pt5 | 9 | 4.050 | 3.823 | 0.227 |
| sv6pt5 | 11 | 3.428 | 3.327 | 0.101 |
| me55 | 12 | 3.294 | 3.217 | 0.077 |
| sv7 | 12 | 3.368 | 3.274 | 0.094 |
| sv3 | 13 | 3.306 | 3.230 | 0.076 |
| me5 | 13 | 3.322 | 3.244 | 0.078 |
| me2 | 13 | 2.731 | 2.727 | 0.005 |
| me4 | 13 | 3.120 | 3.063 | 0.057 |
| sv9 | 16 | 2.785 | 2.774 | 0.011 |
| sv3pt5 | 17 | 3.439 | 3.366 | 0.073 |
| me1 | 18 | 2.547 | 2.557 | -0.010 |
| sv1 | 20 | 2.848 | 2.836 | 0.011 |
| sv8pt5 | 23 | 2.277 | 2.306 | -0.029 |
| sv8 | 23 | 2.269 | 2.299 | -0.030 |
| sv6 | 23 | 2.297 | 2.323 | -0.026 |
| swsh9 | 23 | 2.410 | 2.429 | -0.019 |
| sv5 | 24 | 2.502 | 2.515 | -0.012 |
| me2pt5 | 24 | 2.337 | 2.360 | -0.022 |
| sv10 | 26 | 2.044 | 2.082 | -0.038 |
| swsh11 | 26 | 1.787 | 1.844 | -0.057 |
| swsh12 | 27 | 1.587 | 1.653 | -0.066 |
| sv4 | 30 | 2.382 | 2.399 | -0.017 |
| swsh10 | 33 | 1.642 | 1.694 | -0.052 |
| swsh7 | 53 | 1.996 | 2.018 | -0.022 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-116: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv1-243: OLS = overvalued, hierarchical = fair
- sv10-208: OLS = undervalued, hierarchical = fair
- sv10-212: OLS = undervalued, hierarchical = fair
- sv10-216: OLS = undervalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-242: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-226: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv8pt5-161: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-173: OLS = undervalued, hierarchical = fair
- swsh10-175: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-207: OLS = fair, hierarchical = undervalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
