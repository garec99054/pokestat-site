# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 2000 draws (2000 tune), target_accept = 0.9, random_seed = 42, non-centered parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 1038, max r_hat 1.0035. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 7434, max r_hat 1.0008. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.475 (90% interval 1.306 to 1.640) vs OLS point estimate 0.876 (SE 0.061)
- **beta_desir (desirability)**: hierarchical posterior mean 0.600 (90% interval 0.553 to 0.646) vs OLS point estimate 0.671 (SE 0.030)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.64 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -655.26 | 21.79 | 0.00 | 0.00 | 0.89 |
| flat | 1 | -713.77 | 14.46 | -58.51 | 13.53 | 0.11 |

Hierarchical: elpd_loo = -655.26 +/- 21.79, p_loo = 23.38, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

Flat: elpd_loo = -713.77 +/- 14.46, p_loo = 3.76, 0/503 observations with an unreliable (Pareto k > 0.70) LOO estimate.
ArviZ LOO warning: False.

**Verdict**: hierarchical is favored by elpd_loo diff = +58.51 (dse = 13.53), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-186 | Giratina V | swsh11 | 847.55 | 18.27 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 203.47 | 7.05 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 194.52 | 6.33 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 517.68 | 26.09 | 1.000 | overvalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 9.97 | 62.95 | 0.019 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 9.00 | 48.64 | 0.026 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.11 | 452.42 | 0.027 | undervalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 16.15 | 87.93 | 0.027 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.799.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 5.002 | 3.699 | 1.303 |
| sv4pt5 | 9 | 4.072 | 3.884 | 0.189 |
| sv6pt5 | 11 | 3.553 | 3.458 | 0.095 |
| me55 | 12 | 3.867 | 3.749 | 0.118 |
| sv7 | 12 | 3.585 | 3.498 | 0.087 |
| sv3 | 13 | 3.458 | 3.390 | 0.069 |
| me5 | 13 | 3.558 | 3.478 | 0.079 |
| me2 | 13 | 2.811 | 2.814 | -0.002 |
| me4 | 13 | 3.436 | 3.369 | 0.066 |
| sv9 | 16 | 2.999 | 2.983 | 0.016 |
| sv3pt5 | 17 | 3.618 | 3.552 | 0.066 |
| me1 | 18 | 2.664 | 2.672 | -0.008 |
| sv1 | 20 | 2.904 | 2.897 | 0.007 |
| sv8pt5 | 23 | 2.359 | 2.388 | -0.029 |
| sv8 | 23 | 2.359 | 2.384 | -0.025 |
| sv6 | 23 | 2.411 | 2.436 | -0.025 |
| swsh9 | 23 | 2.529 | 2.546 | -0.016 |
| sv5 | 24 | 2.571 | 2.581 | -0.010 |
| me2pt5 | 24 | 2.609 | 2.620 | -0.011 |
| sv10 | 26 | 2.209 | 2.242 | -0.033 |
| swsh11 | 26 | 1.759 | 1.819 | -0.060 |
| swsh12 | 27 | 1.670 | 1.729 | -0.059 |
| sv4 | 30 | 2.414 | 2.431 | -0.017 |
| swsh10 | 33 | 1.619 | 1.671 | -0.052 |
| swsh7 | 53 | 1.915 | 1.942 | -0.026 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-160: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-175: OLS = fair, hierarchical = overvalued
- swsh10-176: OLS = undervalued, hierarchical = fair
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-207: OLS = fair, hierarchical = undervalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
