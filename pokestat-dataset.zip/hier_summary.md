# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 1000 draws (1000 tune), target_accept = 0.9, non-centered
parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 486, max r_hat 1.0067. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 3754, max r_hat 1.0040. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.488 (90% interval 1.315 to 1.661) vs OLS point estimate 0.842 (SE 0.064)
- **beta_desir (desirability)**: hierarchical posterior mean 0.601 (90% interval 0.552 to 0.650) vs OLS point estimate 0.688 (SE 0.030)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.63 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -660.00 | 22.00 | 0.00 | 0.00 | 0.90 |
| flat | 1 | -720.00 | 14.00 | -70.00 | 14.00 | 0.10 |

Hierarchical: elpd_loo = -657.48 +/- 21.88, p_loo = 24.12, 0/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

Flat: elpd_loo = -723.06 +/- 14.09, p_loo = 3.82, 0/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

**Verdict**: hierarchical is favored by elpd_loo diff = +65.59 (dse = 14.00), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh12-186 | Lugia V | swsh12 | 518.63 | 26.23 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 841.43 | 17.99 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 208.96 | 6.96 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 195.66 | 6.07 | 1.000 | overvalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 14.31 | 88.47 | 0.020 | undervalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 10.75 | 64.38 | 0.021 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.77 | 47.81 | 0.027 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.73 | 460.39 | 0.029 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.843.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 5.156 | 3.870 | 1.286 |
| sv4pt5 | 9 | 4.128 | 3.961 | 0.167 |
| sv6pt5 | 11 | 3.644 | 3.563 | 0.081 |
| me55 | 12 | 4.375 | 4.219 | 0.156 |
| sv7 | 12 | 3.598 | 3.522 | 0.076 |
| sv3 | 13 | 3.511 | 3.444 | 0.067 |
| me5 | 13 | 3.711 | 3.635 | 0.077 |
| me2 | 13 | 2.847 | 2.845 | 0.002 |
| me4 | 13 | 3.458 | 3.401 | 0.058 |
| sv9 | 16 | 2.980 | 2.970 | 0.011 |
| sv3pt5 | 17 | 3.653 | 3.595 | 0.058 |
| me1 | 18 | 2.682 | 2.690 | -0.008 |
| sv1 | 20 | 2.964 | 2.956 | 0.009 |
| sv8pt5 | 23 | 2.368 | 2.396 | -0.027 |
| sv8 | 23 | 2.418 | 2.439 | -0.021 |
| sv6 | 23 | 2.421 | 2.444 | -0.023 |
| swsh9 | 23 | 2.543 | 2.560 | -0.017 |
| sv5 | 24 | 2.587 | 2.599 | -0.012 |
| me2pt5 | 24 | 2.679 | 2.686 | -0.007 |
| sv10 | 26 | 2.258 | 2.285 | -0.027 |
| swsh11 | 26 | 1.755 | 1.808 | -0.053 |
| swsh12 | 27 | 1.681 | 1.738 | -0.057 |
| sv4 | 30 | 2.404 | 2.422 | -0.017 |
| swsh10 | 33 | 1.628 | 1.674 | -0.045 |
| swsh7 | 53 | 1.899 | 1.924 | -0.025 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-116: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- me55-155: OLS = overvalued, hierarchical = fair
- sv1-243: OLS = overvalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-210: OLS = fair, hierarchical = undervalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
