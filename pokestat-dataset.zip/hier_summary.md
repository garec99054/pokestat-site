# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 24 sets, n = 491 chase cards. Sampled with
4 chains x 1000 draws (1000 tune), target_accept = 0.9, non-centered
parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 520, max r_hat 1.0100. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 3705, max r_hat 1.0000. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.473 (90% interval 1.300 to 1.643) vs OLS point estimate 0.884 (SE 0.065)
- **beta_desir (desirability)**: hierarchical posterior mean 0.596 (90% interval 0.548 to 0.644) vs OLS point estimate 0.658 (SE 0.033)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.63 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -650.00 | 22.00 | 0.00 | 0.00 | 0.90 |
| flat | 1 | -710.00 | 14.00 | -60.00 | 14.00 | 0.10 |

Hierarchical: elpd_loo = -645.40 +/- 21.59, p_loo = 22.73, 0/491 observations with an unreliable (Pareto k > 0.7) LOO estimate.

Flat: elpd_loo = -706.76 +/- 14.21, p_loo = 3.75, 0/491 observations with an unreliable (Pareto k > 0.7) LOO estimate.

**Verdict**: hierarchical is favored by elpd_loo diff = +61.36 (dse = 14.00), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh10-172 | Machamp V | swsh10 | 199.49 | 6.32 | 1.000 | overvalued |
| swsh11-186 | Giratina V | swsh11 | 835.33 | 17.93 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 209.68 | 7.13 | 1.000 | overvalued |
| swsh7-215 | Umbreon VMAX | swsh7 | 2368.34 | 156.91 | 0.999 | overvalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 14.37 | 90.11 | 0.020 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.69 | 51.38 | 0.024 | undervalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 10.11 | 62.79 | 0.024 | undervalued |
| me2pt5-251 | Sprigatito ex | me2pt5 | 2.03 | 11.08 | 0.028 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.831.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 4.937 | 3.702 | 1.234 |
| sv4pt5 | 9 | 4.136 | 3.950 | 0.186 |
| sv6pt5 | 11 | 3.638 | 3.540 | 0.098 |
| sv7 | 12 | 3.589 | 3.503 | 0.086 |
| sv3 | 13 | 3.560 | 3.481 | 0.079 |
| me4 | 13 | 3.553 | 3.479 | 0.074 |
| me5 | 13 | 3.819 | 3.713 | 0.106 |
| me2 | 13 | 2.967 | 2.953 | 0.015 |
| sv9 | 16 | 3.050 | 3.027 | 0.023 |
| sv3pt5 | 17 | 3.730 | 3.654 | 0.076 |
| me1 | 18 | 2.747 | 2.754 | -0.008 |
| sv1 | 20 | 2.973 | 2.962 | 0.012 |
| sv8pt5 | 23 | 2.401 | 2.427 | -0.026 |
| swsh9 | 23 | 2.496 | 2.514 | -0.018 |
| sv6 | 23 | 2.413 | 2.436 | -0.024 |
| sv8 | 23 | 2.404 | 2.434 | -0.030 |
| me2pt5 | 24 | 2.752 | 2.758 | -0.007 |
| sv5 | 24 | 2.668 | 2.678 | -0.011 |
| swsh11 | 26 | 1.747 | 1.805 | -0.058 |
| sv10 | 26 | 2.358 | 2.382 | -0.024 |
| swsh12 | 27 | 1.673 | 1.735 | -0.062 |
| sv4 | 30 | 2.450 | 2.468 | -0.018 |
| swsh10 | 33 | 1.659 | 1.712 | -0.052 |
| swsh7 | 53 | 1.930 | 1.953 | -0.024 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-116: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- sv1-243: OLS = overvalued, hierarchical = fair
- sv1-246: OLS = overvalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-198: OLS = overvalued, hierarchical = fair
- sv3pt5-201: OLS = overvalued, hierarchical = fair
- sv3pt5-202: OLS = overvalued, hierarchical = fair
- sv4-246: OLS = overvalued, hierarchical = fair
- sv4pt5-242: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv6pt5-92: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv8-226: OLS = undervalued, hierarchical = fair
- sv8-236: OLS = overvalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-173: OLS = undervalued, hierarchical = fair
- swsh10-175: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-176: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-184: OLS = fair, hierarchical = overvalued
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-182: OLS = fair, hierarchical = overvalued

## Limitations

- n = 491 cards across 24 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
