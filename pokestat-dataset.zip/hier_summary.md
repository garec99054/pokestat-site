# Bayesian hierarchical pricing model

Partial pooling of the per-set intercept: log(price) ~ alpha_set + beta_pull *
log(pull_cost) + beta_desir * desirability, alpha_set ~ Normal(mu_alpha,
tau_alpha) across 25 sets, n = 503 chase cards. Sampled with
4 chains x 1000 draws (1000 tune), target_accept = 0.9, non-centered
parameterization.

## Diagnostics

Hierarchical model: 0 divergences, min ESS_bulk 423, max r_hat 1.0072. Flags: none.

Flat (pooled) reference model: 0 divergences, min ESS_bulk 3731, max r_hat 1.0018. Flags: none.

## Coefficient posteriors vs OLS

- **beta_pull (log pull cost elasticity)**: hierarchical posterior mean 1.486 (90% interval 1.314 to 1.649) vs OLS point estimate 0.837 (SE 0.063)
- **beta_desir (desirability)**: hierarchical posterior mean 0.604 (90% interval 0.556 to 0.652) vs OLS point estimate 0.690 (SE 0.031)

OLS reference: log(price) ~ log(pull_cost) + desirability, HC3 SEs, LOOCV R^2 = 0.63 (pokestat/model/regress.py).

## Model comparison (arviz LOO)

| model | rank | elpd | se | elpd_diff | dse | weight |
| --- | --- | --- | --- | --- | --- | --- |
| hierarchical | 0 | -660.00 | 22.00 | 0.00 | 0.00 | 0.90 |
| flat | 1 | -720.00 | 14.00 | -60.00 | 14.00 | 0.10 |

Hierarchical: elpd_loo = -657.82 +/- 21.73, p_loo = 23.59, 1/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

Flat: elpd_loo = -722.59 +/- 14.21, p_loo = 3.81, 0/503 observations with an unreliable (Pareto k > 0.7) LOO estimate.

**Verdict**: hierarchical is favored by elpd_loo diff = +64.77 (dse = 14.00), more than 2 standard errors clear of noise.

## Top 8 by mispricing tail probability

tail_prob = P(market price > posterior predictive | features); near 1.0 is overvalued, near 0.0 is undervalued.

| card_id | name | set_id | market | predicted_median | tail_prob | flag |
| --- | --- | --- | --- | --- | --- | --- |
| swsh11-186 | Giratina V | swsh11 | 844.22 | 17.91 | 1.000 | overvalued |
| swsh11-180 | Aerodactyl V | swsh11 | 207.62 | 7.15 | 1.000 | overvalued |
| swsh12-186 | Lugia V | swsh12 | 519.03 | 25.56 | 1.000 | overvalued |
| swsh10-172 | Machamp V | swsh10 | 196.12 | 6.06 | 1.000 | overvalued |
| swsh10-193 | Hisuian Typhlosion VSTAR | swsh10 | 14.53 | 90.78 | 0.020 | undervalued |
| swsh7-213 | Lycanroc VMAX | swsh7 | 10.75 | 64.31 | 0.021 | undervalued |
| swsh11-203 | Hisuian Zoroark VSTAR | swsh11 | 8.55 | 48.36 | 0.025 | undervalued |
| swsh7-214 | Umbreon VMAX | swsh7 | 83.73 | 465.20 | 0.027 | undervalued |

## Shrinkage: which sets get pulled hardest

Per-set hierarchical alpha (posterior mean) vs a naive unpooled per-set intercept (mean log-price after removing the fitted slope effects), sorted by set size -- smaller sets should shrink furthest toward the pooled mean mu_alpha = 2.838.

| set_id | n_cards | unpooled_alpha | hier_alpha | shrinkage |
| --- | --- | --- | --- | --- |
| swsh12pt5 | 1 | 5.123 | 3.869 | 1.254 |
| sv4pt5 | 9 | 4.100 | 3.937 | 0.163 |
| sv6pt5 | 11 | 3.590 | 3.515 | 0.075 |
| me55 | 12 | 4.363 | 4.209 | 0.154 |
| sv7 | 12 | 3.612 | 3.540 | 0.072 |
| sv3 | 13 | 3.526 | 3.462 | 0.064 |
| me5 | 13 | 3.708 | 3.627 | 0.081 |
| me2 | 13 | 2.881 | 2.874 | 0.007 |
| me4 | 13 | 3.505 | 3.447 | 0.059 |
| sv9 | 16 | 2.953 | 2.947 | 0.006 |
| sv3pt5 | 17 | 3.645 | 3.589 | 0.056 |
| me1 | 18 | 2.665 | 2.680 | -0.015 |
| sv1 | 20 | 2.947 | 2.945 | 0.001 |
| sv8pt5 | 23 | 2.348 | 2.371 | -0.023 |
| sv8 | 23 | 2.401 | 2.425 | -0.024 |
| sv6 | 23 | 2.389 | 2.410 | -0.021 |
| swsh9 | 23 | 2.534 | 2.553 | -0.020 |
| sv5 | 24 | 2.571 | 2.586 | -0.015 |
| me2pt5 | 24 | 2.650 | 2.657 | -0.007 |
| sv10 | 26 | 2.225 | 2.253 | -0.028 |
| swsh11 | 26 | 1.766 | 1.819 | -0.052 |
| swsh12 | 27 | 1.682 | 1.737 | -0.055 |
| sv4 | 30 | 2.430 | 2.448 | -0.018 |
| swsh10 | 33 | 1.632 | 1.679 | -0.047 |
| swsh7 | 53 | 1.897 | 1.919 | -0.023 |

## Does the hierarchical model change any OLS flags?

- me1-187: OLS = overvalued, hierarchical = fair
- me2pt5-276: OLS = overvalued, hierarchical = fair
- me4-122: OLS = overvalued, hierarchical = fair
- me5-116: OLS = overvalued, hierarchical = fair
- me5-117: OLS = overvalued, hierarchical = fair
- me5-120: OLS = overvalued, hierarchical = fair
- me55-155: OLS = overvalued, hierarchical = fair
- sv1-243: OLS = overvalued, hierarchical = fair
- sv10-228: OLS = overvalued, hierarchical = fair
- sv3pt5-199: OLS = overvalued, hierarchical = fair
- sv4pt5-244: OLS = overvalued, hierarchical = fair
- sv4pt5-245: OLS = overvalued, hierarchical = fair
- sv7-167: OLS = overvalued, hierarchical = fair
- sv8-217: OLS = undervalued, hierarchical = fair
- sv9-182: OLS = overvalued, hierarchical = fair
- swsh10-163: OLS = fair, hierarchical = overvalued
- swsh10-177: OLS = fair, hierarchical = overvalued
- swsh10-192: OLS = undervalued, hierarchical = fair
- swsh10-197: OLS = undervalued, hierarchical = fair
- swsh10-198: OLS = undervalued, hierarchical = fair
- swsh11-177: OLS = fair, hierarchical = overvalued
- swsh11-178: OLS = undervalued, hierarchical = fair
- swsh11-201: OLS = undervalued, hierarchical = fair
- swsh12-178: OLS = undervalued, hierarchical = fair
- swsh12-179: OLS = undervalued, hierarchical = fair
- swsh12-184: OLS = fair, hierarchical = overvalued
- swsh12-197: OLS = undervalued, hierarchical = fair
- swsh12-199: OLS = undervalued, hierarchical = fair
- swsh12-202: OLS = undervalued, hierarchical = fair
- swsh12pt5-160: OLS = overvalued, hierarchical = fair
- swsh7-167: OLS = fair, hierarchical = overvalued
- swsh7-176: OLS = undervalued, hierarchical = fair
- swsh7-180: OLS = fair, hierarchical = overvalued
- swsh7-186: OLS = fair, hierarchical = overvalued
- swsh7-207: OLS = fair, hierarchical = undervalued

## Limitations

- n = 503 cards across 25 sets is small for a variance component (tau_alpha); some sets have very few cards, so their alpha_set estimate is mostly the pooled mean plus noise, not real evidence of a set-specific effect.
- The LOO comparison above is the honest read: if the verdict says the hierarchy has not earned its complexity, prefer the simpler flat or OLS model for interpretability, and treat any per-set differences here as suggestive at best.
- Desirability and pull cost are treated as measured without error; any error in the character-premium, artwork, or pageview components (see pokestat/model/dataset.py) propagates into beta_desir and the per-card predictions but is not itself modeled.
- Pareto k warnings above (if any) mean the corresponding cards' LOO estimate is unreliable; those cards are influential outliers the model does not generalize well to, not necessarily good over/undervalued signals.
- The posterior predictive tail probability is an in-sample quantity: each card's own price partly informs its set's alpha_set, so tail_prob is not a fully honest out-of-sample check (the OLS model's LOOCV R^2 is the more honest cross-validated number to trust for overall fit quality).

Full per-card table: hier_results.csv (same directory).
