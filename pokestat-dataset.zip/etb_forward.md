# Can ETB returns be predicted cross-sectionally?

*Measurement, not investment advice.* This asks one narrow question: standing at month T with only information available at T, can we rank Elite Trainer Boxes by how much they will beat the ETB basket over the next H months? It does NOT ask whether ETBs went up -- `pokestat.model.etb_index` measures that -- and nothing here is a recommendation to buy, hold or sell anything.

**We cannot establish cross-sectional predictability of ETB returns at the primary 6-month horizon.** The pre-registered model's held-out mean rank correlation is -0.102 across 14 purged folds -- the point estimate is negative, and the effective sample is 2.42 independent draws against a 4.0 bar. This is a NULL, and on an archive this short it is the expected and honest answer.

## The window is the finding's ceiling

The archive is 28 monthly cross-sections (2024-06-01..2026-09-01) covering 107 ETB products across 60 sets, of which 1753 rows in 22 months carry a realized 6-month forward return. Every one of those months sits inside a single regime -- a historic sealed-product boom. Nothing here observes a bust, so nothing here can tell you what predicts returns in one.

More sharply: with an H-month forward window, N consecutive monthly folds contain at most (N-1)//H + 1 NON-OVERLAPPING label windows. That is a fact about the design, invisible to any autocorrelation estimate, and it is the binding constraint on almost every cell below. The effective sample used everywhere is the MINIMUM of the autocorrelation-deflated n_eff and that structural bound, and the repo's 4.0-effective-fold bar is applied to it.

Reading the tables: `clears both gates?` is TWO-SIDED -- it asks whether a cell is further from zero than one of its own error bars on a sufficient effective sample, not whether it is positive. That is why a scorer and its exact negation (`momentum_3m` and `reversal_3m`) can both clear it: each is evidence of ITS OWN direction. The sign is stated separately in every verdict line.

## What the model is allowed to see

Target: log(P_{T+H} / P_T) minus the same month's cross-sectional median, so a model that only knows 'everything went up' scores zero. Within a fold this is rank-identical to the absolute return, so the relative framing cannot flatter the IC. Features, all as-of T: trailing 1/3/6-month returns and 6-month volatility; log price; months since release; log set size; the listing-book shape (relative spread, where market clears inside the book, mid-vs-market skew) and its 3-month change; the SET'S OWN chase-single index return and the box price relative to that index; Pokemon Center / retailer-exclusive flags; era dummies; and an in-print PROXY (age <= 24 months).

Two honest notes on the features. (1) **In-print status is not in the database.** There is no field for it; the proxy is age, and it is labelled a proxy everywhere rather than dressed up as a fact. (2) **TCGplayer-Direct quotes do not exist for sealed product** -- `direct_low` is NULL for every sealed row in the archive -- so the direct-discount feature the singles model uses is structurally unavailable here and is excluded rather than carried as an all-missing column.

## Results by horizon

### Horizon H = 1 months

24 purged folds, 2024-09-01..2026-08-01; median cross-section 85.5 products.

*Purge audit* (summed over folds): 0 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 2021 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 24 | 0.266 | 0.089 | 3.00 | 8.31 | 24.0 | 8.31 | yes |
| ridge / static-ablated | 24 | 0.270 | 0.076 | 3.55 | 8.94 | 24.0 | 8.94 | yes |
| ridge / momentum-only | 24 | 0.208 | 0.063 | 3.31 | 14.06 | 24.0 | 14.06 | yes |
| ridge / book-ablated | 24 | 0.177 | 0.094 | 1.90 | 8.67 | 24.0 | 8.67 | yes |
| baseline: age | 24 | -0.049 | 0.173 | -0.28 | 4.51 | 24.0 | 4.51 | no |
| baseline: cheap | 24 | 0.051 | 0.123 | 0.41 | 5.22 | 24.0 | 5.22 | no |
| baseline: momentum_3m | 24 | 0.067 | 0.070 | 0.95 | 9.56 | 24.0 | 9.56 | no |
| baseline: momentum_6m | 24 | -0.006 | 0.112 | -0.06 | 4.61 | 24.0 | 4.61 | no |
| baseline: reversal_3m | 24 | -0.067 | 0.070 | -0.95 | 9.56 | 24.0 | 9.56 | no |
| baseline: zero | 24 | 0.000 | 0.000 | n/a | 24.00 | 24.0 | 24.00 | no |
| ridge - momentum_3m (paired) | 24 | 0.200 | 0.071 | 2.83 | 7.92 | 24.0 | 7.92 | yes |
| ridge, embargo=0m | 24 | 0.266 | 0.089 | 3.00 | 8.31 | 24.0 | 8.31 | yes |
| ridge, embargo=1m | 23 | 0.214 | 0.088 | 2.42 | 8.18 | 23.0 | 8.18 | yes |
| oracle (unattainable ceiling) | 24 | 1.000 | 0.000 | n/a | 24.00 | 24.0 | 24.00 | yes |

**Verdict at H=1: evidence of a positive association.**

Fold-wise label permutation (2000 draws): observed mean IC 0.266 against a null centred on -0.001 with SD 0.022; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.270, n_eff 9.70, clears both gates: yes). The fitted model scores 0.266, i.e. it MATCHES its own strongest single input -- every fitted parameter beyond that one feature bought nothing.

### Horizon H = 3 months

20 purged folds, 2024-11-01..2026-06-01; median cross-section 85.5 products.

*Purge audit* (summed over folds): 3329 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1625 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 20 | 0.008 | 0.159 | 0.05 | 4.54 | 7.0 | 4.54 | no |
| ridge / static-ablated | 20 | 0.074 | 0.111 | 0.67 | 5.51 | 7.0 | 5.51 | no |
| ridge / momentum-only | 20 | 0.034 | 0.111 | 0.31 | 5.82 | 7.0 | 5.82 | no |
| ridge / book-ablated | 20 | -0.037 | 0.177 | -0.21 | 3.86 | 7.0 | 3.86 | no |
| baseline: age | 20 | -0.039 | 0.262 | -0.15 | 2.99 | 7.0 | 2.99 | no |
| baseline: cheap | 20 | 0.053 | 0.310 | 0.17 | 1.57 | 7.0 | 1.57 | no |
| baseline: momentum_3m | 20 | -0.077 | 0.143 | -0.54 | 3.84 | 7.0 | 3.84 | no |
| baseline: momentum_6m | 20 | -0.061 | 0.121 | -0.50 | 4.03 | 7.0 | 4.03 | no |
| baseline: reversal_3m | 20 | 0.077 | 0.143 | 0.54 | 3.84 | 7.0 | 3.84 | no |
| baseline: zero | 20 | 0.000 | 0.000 | n/a | 20.00 | 7.0 | 7.00 | no |
| ridge - momentum_3m (paired) | 20 | 0.084 | 0.120 | 0.70 | 7.38 | 7.0 | 7.00 | no |
| ridge, embargo=0m | 20 | 0.008 | 0.159 | 0.05 | 4.54 | 7.0 | 4.54 | no |
| ridge, embargo=1m | 19 | -0.026 | 0.142 | -0.18 | 4.96 | 7.0 | 4.96 | no |
| oracle (unattainable ceiling) | 20 | 1.000 | 0.000 | n/a | 20.00 | 7.0 | 7.00 | yes |

**Verdict at H=3: no signal (does not clear its own one-SE error bar).**

Fold-wise label permutation (2000 draws): observed mean IC 0.008 against a null centred on 0.000 with SD 0.025; two-sided p = 0.763. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.247, n_eff 5.87, clears both gates: yes). The fitted model scores 0.008, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 6 months

14 purged folds, 2025-02-01..2026-03-01; median cross-section 85.5 products.

*Purge audit* (summed over folds): 5638 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1073 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 14 | -0.102 | 0.135 | -0.76 | 2.42 | 3.0 | 2.42 | no |
| ridge / static-ablated | 14 | 0.009 | 0.116 | 0.08 | 2.56 | 3.0 | 2.56 | no |
| ridge / momentum-only | 14 | -0.033 | 0.090 | -0.37 | 5.22 | 3.0 | 3.00 | no |
| ridge / book-ablated | 14 | -0.138 | 0.127 | -1.09 | 2.70 | 3.0 | 2.70 | no |
| baseline: age | 14 | 0.059 | 0.288 | 0.21 | 1.13 | 3.0 | 1.13 | no |
| baseline: cheap | 14 | -0.162 | 0.457 | -0.35 | 1.00 | 3.0 | 1.00 | no |
| baseline: momentum_3m | 14 | -0.150 | 0.133 | -1.13 | 3.56 | 3.0 | 3.00 | no |
| baseline: momentum_6m | 14 | -0.136 | 0.113 | -1.21 | 2.83 | 3.0 | 2.83 | no |
| baseline: reversal_3m | 14 | 0.150 | 0.133 | 1.13 | 3.56 | 3.0 | 3.00 | no |
| baseline: zero | 14 | 0.000 | 0.000 | n/a | 14.00 | 3.0 | 3.00 | no |
| ridge - momentum_3m (paired) | 14 | 0.048 | 0.261 | 0.18 | 2.03 | 3.0 | 2.03 | no |
| ridge, embargo=0m | 14 | -0.102 | 0.135 | -0.76 | 2.42 | 3.0 | 2.42 | no |
| ridge, embargo=1m | 13 | -0.101 | 0.161 | -0.63 | 2.12 | 3.0 | 2.12 | no |
| oracle (unattainable ceiling) | 14 | 1.000 | 0.000 | n/a | 14.00 | 3.0 | 3.00 | no |

**Verdict at H=6: no signal, and n_eff 2.42 is too thin to have found one.**

Fold-wise label permutation (2000 draws): observed mean IC -0.102 against a null centred on -0.000 with SD 0.029; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.287, n_eff 3.00, clears both gates: no). The fitted model scores -0.102, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 12 months

2 purged folds, 2025-08-01..2025-09-01; median cross-section 85.5 products.

*Purge audit* (summed over folds): 1672 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 143 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 2 | -0.160 | 0.238 | -0.67 | 2.00 | 1.0 | 1.00 | no |
| ridge / static-ablated | 2 | -0.006 | 0.246 | -0.02 | 2.00 | 1.0 | 1.00 | no |
| ridge / momentum-only | 2 | -0.021 | 0.275 | -0.08 | 2.00 | 1.0 | 1.00 | no |
| ridge / book-ablated | 2 | -0.252 | 0.150 | -1.68 | 2.00 | 1.0 | 1.00 | no |
| baseline: age | 2 | 0.174 | 0.094 | 1.85 | 2.00 | 1.0 | 1.00 | no |
| baseline: cheap | 2 | -0.034 | 0.154 | -0.22 | 2.00 | 1.0 | 1.00 | no |
| baseline: momentum_3m | 2 | 0.064 | 0.212 | 0.30 | 2.00 | 1.0 | 1.00 | no |
| baseline: momentum_6m | 2 | -0.046 | 0.069 | -0.66 | 2.00 | 1.0 | 1.00 | no |
| baseline: reversal_3m | 2 | -0.064 | 0.212 | -0.30 | 2.00 | 1.0 | 1.00 | no |
| baseline: zero | 2 | 0.000 | 0.000 | n/a | 2.00 | 1.0 | 1.00 | no |
| ridge - momentum_3m (paired) | 2 | -0.224 | 0.026 | -8.77 | 2.00 | 1.0 | 1.00 | no |
| ridge, embargo=0m | 2 | -0.160 | 0.238 | -0.67 | 2.00 | 1.0 | 1.00 | no |
| ridge, embargo=1m | 1 | -0.343 | n/a | n/a | 1.00 | 1.0 | 1.00 | no |
| oracle (unattainable ceiling) | 2 | 1.000 | 0.000 | n/a | 2.00 | 1.0 | 1.00 | no |

**Verdict at H=12: no signal, and n_eff 1.00 is too thin to have found one.**

Fold-wise label permutation (2000 draws): observed mean IC -0.160 against a null centred on 0.004 with SD 0.079; two-sided p = 0.042. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `market_pos` (mean IC 0.223, n_eff 1.00, clears both gates: no). The fitted model scores -0.160, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

## The strongest feature: artefact or signal? Not established

`mid_skew` = (mid - market) / market is the best single predictor in this panel at H = 1, 3, 6 (not everywhere: H = 12 `rel_spread`). It has two rival readings, and they disagree about what the listing book does NEXT: if sellers are holding out because demand is real, the book should keep rising; if TCGplayer's trailing `market` average simply has not caught up, the two series should converge. The test is direct.

| H | mid_skew -> forward MARKET return | -> forward change in BOOK MID | -> change in the gap | signature |
|---|---|---|---|---|
| 1 | 0.270 (t 4.23) | -0.241 (t -4.53) | -0.449 (t -16.63) | CONVERGENCE |
| 3 | 0.247 (t 2.95) | -0.299 (t -5.95) | -0.530 (t -10.84) | CONVERGENCE |
| 6 | 0.287 (t 3.35) | -0.297 (t -5.11) | -0.612 (t -9.23) | CONVERGENCE |
| 12 | -0.062 (t -0.89) | -0.406 (t -5.64) | -0.667 (t -4.17) | not convergence |

The signature is NOT uniform across horizons, so the measurement-lag reading is not established; both readings survive and `mid_skew` should be treated as unexplained rather than as either signal or artefact.

The same defect has a second edge. Because `market` is a trailing transaction-weighted average, a monthly change in it is a change in a SMOOTHED series, and smoothing induces positive autocorrelation in measured returns even when the underlying price is a random walk -- the appraisal-smoothing problem familiar from illiquid asset indices. That is exactly where the second-strongest one-month feature lives: `mom_1m` scores a mean IC of 0.218 at H=1 (n_eff 24.00) and fades at longer horizons. Short-horizon 'momentum' in this panel should therefore be read as a property of the price SERIES, not of the market, until a non-smoothed quote can confirm it -- and no such quote exists in the permitted sources.

## Against the only benchmark that matters: buy the whole basket

A rank correlation is not money. This is the same walk-forward, turned into an equal-weight top-5th portfolio rebalanced every H months and differenced against holding every ETB in the panel. `cost drag` is 15% round-trip (the conservative end of the bid-ask + fees range the data audit found on thin sealed listings) applied at every rebalance, 12/H times a year; buy-and-hold pays it once and amortises it to roughly nothing.

Read the `zero` row first: it scores every product identically, so its 'top quintile' is an ARBITRARY fifth of the basket. Whatever edge it shows is pure partition noise, and it is the floor any real scorer has to clear.

| H | scorer | top-quintile %/yr | basket %/yr | gross edge | cost drag | net edge | t | n_eff | beats buy-and-hold? |
|---|---|---|---|---|---|---|---|---|---|
| 1 | ridge | 169.9 | 100.8 | +69.1pp | -85.8pp | -16.6pp | 2.51 | 13.28 | YES |
| 1 | age | 92.7 | 100.8 | -8.1pp | -85.8pp | -93.8pp | -0.14 | 4.77 | no |
| 1 | cheap | 109.2 | 100.8 | +8.4pp | -85.8pp | -77.4pp | 0.31 | 10.05 | no |
| 1 | momentum_3m | 114.7 | 100.8 | +13.9pp | -85.8pp | -71.8pp | 0.54 | 9.33 | no |
| 1 | momentum_6m | 107.1 | 100.8 | +6.3pp | -85.8pp | -79.5pp | 0.18 | 5.70 | no |
| 1 | reversal_3m | 75.9 | 100.8 | -24.9pp | -85.8pp | -110.6pp | -1.33 | 11.35 | no |
| 1 | zero | 98.0 | 100.8 | -2.8pp | -85.8pp | -88.6pp | -0.08 | 7.76 | no |
| 1 | oracle | 734.2 | 100.8 | +633.4pp | -85.8pp | +547.6pp | 18.45 | 17.11 | YES |
| 3 | ridge | 111.8 | 113.1 | -1.3pp | -47.8pp | -49.1pp | -0.05 | 6.57 | no |
| 3 | age | 104.0 | 113.1 | -9.1pp | -47.8pp | -56.9pp | -0.12 | 2.21 | no |
| 3 | cheap | 125.8 | 113.1 | +12.7pp | -47.8pp | -35.1pp | 0.23 | 1.68 | no |
| 3 | momentum_3m | 95.6 | 113.1 | -17.5pp | -47.8pp | -65.3pp | -0.56 | 2.98 | no |
| 3 | momentum_6m | 98.7 | 113.1 | -14.4pp | -47.8pp | -62.2pp | -0.44 | 2.78 | no |
| 3 | reversal_3m | 130.6 | 113.1 | +17.5pp | -47.8pp | -30.3pp | 0.59 | 5.55 | no |
| 3 | zero | 107.4 | 113.1 | -5.7pp | -47.8pp | -53.5pp | -0.14 | 3.16 | no |
| 3 | oracle | 412.0 | 113.1 | +298.9pp | -47.8pp | +251.1pp | 13.68 | 6.37 | YES |
| 6 | ridge | 84.5 | 91.4 | -7.0pp | -27.8pp | -34.7pp | -0.41 | 3.00 | no |
| 6 | age | 118.7 | 91.4 | +27.2pp | -27.8pp | -0.5pp | 0.57 | 1.18 | no |
| 6 | cheap | 84.5 | 91.4 | -7.0pp | -27.8pp | -34.7pp | -0.14 | 1.00 | no |
| 6 | momentum_3m | 82.2 | 91.4 | -9.3pp | -27.8pp | -37.0pp | -0.40 | 2.10 | no |
| 6 | momentum_6m | 86.5 | 91.4 | -5.0pp | -27.8pp | -32.7pp | -0.25 | 2.33 | no |
| 6 | reversal_3m | 116.7 | 91.4 | +25.3pp | -27.8pp | -2.5pp | 1.33 | 3.00 | no |
| 6 | zero | 76.8 | 91.4 | -14.6pp | -27.8pp | -42.4pp | -0.40 | 1.15 | no |
| 6 | oracle | 226.6 | 91.4 | +135.2pp | -27.8pp | +107.4pp | 12.34 | 3.00 | no |
| 12 | ridge | 50.8 | 64.0 | -13.2pp | -15.0pp | -28.2pp | -0.80 | 1.00 | no |
| 12 | age | 82.6 | 64.0 | +18.6pp | -15.0pp | +3.6pp | 2.66 | 1.00 | no |
| 12 | cheap | 73.0 | 64.0 | +8.9pp | -15.0pp | -6.1pp | 1.22 | 1.00 | no |
| 12 | momentum_3m | 68.0 | 64.0 | +4.0pp | -15.0pp | -11.0pp | 0.57 | 1.00 | no |
| 12 | momentum_6m | 62.0 | 64.0 | -2.0pp | -15.0pp | -17.0pp | -0.30 | 1.00 | no |
| 12 | reversal_3m | 56.8 | 64.0 | -7.2pp | -15.0pp | -22.2pp | -1.27 | 1.00 | no |
| 12 | zero | 49.1 | 64.0 | -14.9pp | -15.0pp | -29.9pp | -4.12 | 1.00 | no |
| 12 | oracle | 116.2 | 64.0 | +52.2pp | -15.0pp | +37.2pp | 497.64 | 1.00 | no |

The model's portfolio beats buy-and-hold GROSS at H = 1 months. Net of the rebalancing cost it beats buy-and-hold at NO horizon. A gross-only edge is not a reason to trade; it is a reason to distrust the gross number.

## The selection protocol (reported, never the headline)

The headline model is PRE-REGISTERED (`ridge`), so every fold above is held out and no selection step touched them. For completeness the full candidate roster was also run through choose-on-selection-folds / score-on-evaluation-folds:

- selection folds: 7 (2025-02-01..2025-08-01)
- evaluation folds: 7 (2025-09-01..2026-03-01)
- selection-fold ranking: huber -0.122; rank_linear -0.125; rf -0.141; ridge -0.141; elasticnet -0.174; gbm -0.177; ensemble -0.181; pls -0.213
- winner `huber` scores -0.032 on the evaluation folds (n_eff 1.00): no signal, and n_eff 1.00 is too thin to have found one

**This split is NOT clean and the number above is contaminated.** With an H=6 label window, the last selection fold's outcome is still being realised during the first 5 evaluation folds, and there are not enough months on this archive to buy that gap back and still have folds on both sides. Stating it is the only available remedy; it is also why the headline does not come from here.

## What would change this answer

- **More history.** The binding constraint is the number of non-overlapping forward windows, and that grows only with calendar time. tcgcsv's archive starts 2024-03; eBay and PriceCharting are excluded on terms-of-service grounds, so there is no legitimate way to extend it backwards.
- **A regime change.** Every fold here is a boom month. A signal that works only in a boom is not distinguishable from no signal until a bust supplies the contrast.
- **A tradeable price.** Even where the model's portfolio beats buy-and-hold gross (H = 1), it does not survive a realistic round-trip cost. Any future version of this study should report net, not gross, or it is measuring the wrong thing.

