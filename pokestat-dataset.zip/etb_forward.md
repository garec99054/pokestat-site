# Can ETB returns be predicted cross-sectionally?

*Measurement, not investment advice.* This asks one narrow question: standing at month T with only information available at T, can we rank Elite Trainer Boxes by how much they will beat the ETB basket over the next H months? It does NOT ask whether ETBs went up -- `pokestat.model.etb_index` measures that -- and nothing here is a recommendation to buy, hold or sell anything.

**We cannot establish cross-sectional predictability of ETB returns at the primary 6-month horizon.** The pre-registered model's held-out mean rank correlation is -0.121 across 14 purged folds -- the point estimate is negative, and the effective sample is 1.82 independent draws against a 4.0 bar. This is a NULL, and on 29 months of data it is the expected and honest answer.

## The window is the finding's ceiling

The archive is 28 monthly cross-sections (2024-06-01..2026-09-01) covering 108 ETB products across 60 sets, of which 1779 rows in 22 months carry a realized 6-month forward return. Every one of those months sits inside a single regime -- a historic sealed-product boom. Nothing here observes a bust, so nothing here can tell you what predicts returns in one.

More sharply: with an H-month forward window, N consecutive monthly folds contain at most (N-1)//H + 1 NON-OVERLAPPING label windows. That is a fact about the design, invisible to any autocorrelation estimate, and it is the binding constraint on almost every cell below. The effective sample used everywhere is the MINIMUM of the autocorrelation-deflated n_eff and that structural bound, and the repo's 4.0-effective-fold bar is applied to it.

Reading the tables: `clears both gates?` is TWO-SIDED -- it asks whether a cell is further from zero than one of its own error bars on a sufficient effective sample, not whether it is positive. That is why a scorer and its exact negation (`momentum_3m` and `reversal_3m`) can both clear it: each is evidence of ITS OWN direction. The sign is stated separately in every verdict line.

## What the model is allowed to see

Target: log(P_{T+H} / P_T) minus the same month's cross-sectional median, so a model that only knows 'everything went up' scores zero. Within a fold this is rank-identical to the absolute return, so the relative framing cannot flatter the IC. Features, all as-of T: trailing 1/3/6-month returns and 6-month volatility; log price; months since release; log set size; the listing-book shape (relative spread, where market clears inside the book, mid-vs-market skew) and its 3-month change; the SET'S OWN chase-single index return and the box price relative to that index; Pokemon Center / retailer-exclusive flags; era dummies; and an in-print PROXY (age <= 24 months).

Two honest notes on the features. (1) **In-print status is not in the database.** There is no field for it; the proxy is age, and it is labelled a proxy everywhere rather than dressed up as a fact. (2) **TCGplayer-Direct quotes do not exist for sealed product** -- `direct_low` is NULL for every sealed row in the archive -- so the direct-discount feature the singles model uses is structurally unavailable here and is excluded rather than carried as an all-missing column.

## Results by horizon

### Horizon H = 1 months

24 purged folds, 2024-09-01..2026-08-01; median cross-section 87.0 products.

*Purge audit* (summed over folds): 0 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 2047 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 24 | 0.271 | 0.076 | 3.57 | 10.37 | 24.0 | 10.37 | yes |
| ridge / static-ablated | 24 | 0.278 | 0.068 | 4.09 | 10.68 | 24.0 | 10.68 | yes |
| ridge / momentum-only | 24 | 0.212 | 0.060 | 3.54 | 13.70 | 24.0 | 13.70 | yes |
| ridge / book-ablated | 24 | 0.184 | 0.082 | 2.24 | 9.87 | 24.0 | 9.87 | yes |
| baseline: age | 24 | -0.035 | 0.172 | -0.20 | 4.71 | 24.0 | 4.71 | no |
| baseline: cheap | 24 | 0.048 | 0.119 | 0.40 | 5.60 | 24.0 | 5.60 | no |
| baseline: momentum_3m | 24 | 0.077 | 0.062 | 1.25 | 10.58 | 24.0 | 10.58 | yes |
| baseline: momentum_6m | 24 | 0.004 | 0.115 | 0.03 | 4.21 | 24.0 | 4.21 | no |
| baseline: reversal_3m | 24 | -0.077 | 0.062 | -1.25 | 10.58 | 24.0 | 10.58 | yes |
| baseline: zero | 24 | 0.000 | 0.000 | n/a | 24.00 | 24.0 | 24.00 | no |
| ridge - momentum_3m (paired) | 24 | 0.193 | 0.061 | 3.15 | 10.05 | 24.0 | 10.05 | yes |
| ridge, embargo=0m | 24 | 0.271 | 0.076 | 3.57 | 10.37 | 24.0 | 10.37 | yes |
| ridge, embargo=1m | 23 | 0.219 | 0.086 | 2.56 | 8.16 | 23.0 | 8.16 | yes |
| oracle (unattainable ceiling) | 24 | 1.000 | 0.000 | n/a | 24.00 | 24.0 | 24.00 | yes |

**Verdict at H=1: evidence of a positive association.**

Fold-wise label permutation (2000 draws): observed mean IC 0.271 against a null centred on 0.000 with SD 0.022; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.271, n_eff 10.34, clears both gates: yes). The fitted model scores 0.271, i.e. it MATCHES its own strongest single input -- every fitted parameter beyond that one feature bought nothing.

### Horizon H = 3 months

20 purged folds, 2024-11-01..2026-06-01; median cross-section 87.0 products.

*Purge audit* (summed over folds): 3377 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1648 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 20 | -0.031 | 0.154 | -0.20 | 3.86 | 7.0 | 3.86 | no |
| ridge / static-ablated | 20 | 0.074 | 0.097 | 0.76 | 5.57 | 7.0 | 5.57 | no |
| ridge / momentum-only | 20 | -0.000 | 0.106 | -0.00 | 6.04 | 7.0 | 6.04 | no |
| ridge / book-ablated | 20 | -0.099 | 0.204 | -0.49 | 2.53 | 7.0 | 2.53 | no |
| baseline: age | 20 | -0.023 | 0.256 | -0.09 | 3.22 | 7.0 | 3.22 | no |
| baseline: cheap | 20 | 0.055 | 0.303 | 0.18 | 1.59 | 7.0 | 1.59 | no |
| baseline: momentum_3m | 20 | -0.058 | 0.129 | -0.45 | 4.21 | 7.0 | 4.21 | no |
| baseline: momentum_6m | 20 | -0.049 | 0.128 | -0.38 | 3.92 | 7.0 | 3.92 | no |
| baseline: reversal_3m | 20 | 0.058 | 0.129 | 0.45 | 4.21 | 7.0 | 4.21 | no |
| baseline: zero | 20 | 0.000 | 0.000 | n/a | 20.00 | 7.0 | 7.00 | no |
| ridge - momentum_3m (paired) | 20 | 0.027 | 0.107 | 0.25 | 8.13 | 7.0 | 7.00 | no |
| ridge, embargo=0m | 20 | -0.031 | 0.154 | -0.20 | 3.86 | 7.0 | 3.86 | no |
| ridge, embargo=1m | 19 | -0.057 | 0.123 | -0.46 | 5.25 | 7.0 | 5.25 | no |
| oracle (unattainable ceiling) | 20 | 1.000 | 0.000 | n/a | 20.00 | 7.0 | 7.00 | yes |

**Verdict at H=3: no signal, and n_eff 3.86 is too thin to have found one.**

Fold-wise label permutation (2000 draws): observed mean IC -0.031 against a null centred on -0.000 with SD 0.024; two-sided p = 0.204. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.247, n_eff 6.47, clears both gates: yes). The fitted model scores -0.031, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 6 months

14 purged folds, 2025-02-01..2026-03-01; median cross-section 87.0 products.

*Purge audit* (summed over folds): 5734 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1088 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 14 | -0.121 | 0.165 | -0.73 | 1.82 | 3.0 | 1.82 | no |
| ridge / static-ablated | 14 | -0.034 | 0.116 | -0.29 | 2.16 | 3.0 | 2.16 | no |
| ridge / momentum-only | 14 | -0.110 | 0.098 | -1.12 | 5.55 | 3.0 | 3.00 | no |
| ridge / book-ablated | 14 | -0.170 | 0.127 | -1.34 | 2.49 | 3.0 | 2.49 | no |
| baseline: age | 14 | 0.067 | 0.295 | 0.23 | 1.17 | 3.0 | 1.17 | no |
| baseline: cheap | 14 | -0.153 | 0.445 | -0.34 | 1.00 | 3.0 | 1.00 | no |
| baseline: momentum_3m | 14 | -0.138 | 0.129 | -1.07 | 3.41 | 3.0 | 3.00 | no |
| baseline: momentum_6m | 14 | -0.136 | 0.121 | -1.13 | 2.99 | 3.0 | 2.99 | no |
| baseline: reversal_3m | 14 | 0.138 | 0.129 | 1.07 | 3.41 | 3.0 | 3.00 | no |
| baseline: zero | 14 | 0.000 | 0.000 | n/a | 14.00 | 3.0 | 3.00 | no |
| ridge - momentum_3m (paired) | 14 | 0.017 | 0.288 | 0.06 | 1.87 | 3.0 | 1.87 | no |
| ridge, embargo=0m | 14 | -0.121 | 0.165 | -0.73 | 1.82 | 3.0 | 1.82 | no |
| ridge, embargo=1m | 13 | -0.117 | 0.194 | -0.60 | 1.60 | 3.0 | 1.60 | no |
| oracle (unattainable ceiling) | 14 | 1.000 | 0.000 | n/a | 14.00 | 3.0 | 3.00 | no |

**Verdict at H=6: no signal, and n_eff 1.82 is too thin to have found one.**

Fold-wise label permutation (2000 draws): observed mean IC -0.121 against a null centred on -0.000 with SD 0.028; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.284, n_eff 3.00, clears both gates: no). The fitted model scores -0.121, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 12 months

2 purged folds, 2025-08-01..2025-09-01; median cross-section 87.0 products.

*Purge audit* (summed over folds): 1694 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 143 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 2 | -0.200 | 0.204 | -0.98 | 2.00 | 1.0 | 1.00 | no |
| ridge / static-ablated | 2 | -0.053 | 0.227 | -0.23 | 2.00 | 1.0 | 1.00 | no |
| ridge / momentum-only | 2 | -0.041 | 0.248 | -0.17 | 2.00 | 1.0 | 1.00 | no |
| ridge / book-ablated | 2 | -0.278 | 0.141 | -1.97 | 2.00 | 1.0 | 1.00 | no |
| baseline: age | 2 | 0.132 | 0.061 | 2.15 | 2.00 | 1.0 | 1.00 | no |
| baseline: cheap | 2 | -0.035 | 0.183 | -0.19 | 2.00 | 1.0 | 1.00 | no |
| baseline: momentum_3m | 2 | 0.041 | 0.219 | 0.19 | 2.00 | 1.0 | 1.00 | no |
| baseline: momentum_6m | 2 | -0.058 | 0.072 | -0.81 | 2.00 | 1.0 | 1.00 | no |
| baseline: reversal_3m | 2 | -0.041 | 0.219 | -0.19 | 2.00 | 1.0 | 1.00 | no |
| baseline: zero | 2 | 0.000 | 0.000 | n/a | 2.00 | 1.0 | 1.00 | no |
| ridge - momentum_3m (paired) | 2 | -0.241 | 0.015 | -16.46 | 2.00 | 1.0 | 1.00 | no |
| ridge, embargo=0m | 2 | -0.200 | 0.204 | -0.98 | 2.00 | 1.0 | 1.00 | no |
| ridge, embargo=1m | 1 | -0.381 | n/a | n/a | 1.00 | 1.0 | 1.00 | no |
| oracle (unattainable ceiling) | 2 | 1.000 | 0.000 | n/a | 2.00 | 1.0 | 1.00 | no |

**Verdict at H=12: no signal, and n_eff 1.00 is too thin to have found one.**

Fold-wise label permutation (2000 draws): observed mean IC -0.200 against a null centred on -0.002 with SD 0.077; two-sided p = 0.009. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `market_pos` (mean IC 0.225, n_eff 1.00, clears both gates: no). The fitted model scores -0.200, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

## The strongest feature is a measurement artefact, not a forecast

`mid_skew` = (mid - market) / market is the best single predictor in this panel at every horizon. It has two rival readings, and they disagree about what the listing book does NEXT: if sellers are holding out because demand is real, the book should keep rising; if TCGplayer's trailing `market` average simply has not caught up, the two series should converge. The test is direct.

| H | mid_skew -> forward MARKET return | -> forward change in BOOK MID | -> change in the gap | signature |
|---|---|---|---|---|
| 1 | 0.271 (t 4.36) | -0.238 (t -4.51) | -0.449 (t -16.68) | CONVERGENCE |
| 3 | 0.247 (t 3.16) | -0.298 (t -5.76) | -0.532 (t -11.29) | CONVERGENCE |
| 6 | 0.284 (t 3.39) | -0.287 (t -4.82) | -0.605 (t -9.29) | CONVERGENCE |
| 12 | -0.053 (t -0.47) | -0.399 (t -3.73) | -0.673 (t -4.43) | not convergence |

The signature is NOT uniform across horizons, so the measurement-lag reading is not established; both readings survive and `mid_skew` should be treated as unexplained rather than as either signal or artefact.

The same defect has a second edge. Because `market` is a trailing transaction-weighted average, a monthly change in it is a change in a SMOOTHED series, and smoothing induces positive autocorrelation in measured returns even when the underlying price is a random walk -- the appraisal-smoothing problem familiar from illiquid asset indices. That is exactly where the second-strongest one-month feature lives: `mom_1m` scores a mean IC of 0.227 at H=1 (n_eff 24.00) and fades at longer horizons. Short-horizon 'momentum' in this panel should therefore be read as a property of the price SERIES, not of the market, until a non-smoothed quote can confirm it -- and no such quote exists in the permitted sources.

## Against the only benchmark that matters: buy the whole basket

A rank correlation is not money. This is the same walk-forward, turned into an equal-weight top-5th portfolio rebalanced every H months and differenced against holding every ETB in the panel. `cost drag` is 15% round-trip (the conservative end of the bid-ask + fees range the data audit found on thin sealed listings) applied at every rebalance, 12/H times a year; buy-and-hold pays it once and amortises it to roughly nothing.

Read the `zero` row first: it scores every product identically, so its 'top quintile' is an ARBITRARY fifth of the basket. Whatever edge it shows is pure partition noise, and it is the floor any real scorer has to clear.

| H | scorer | top-quintile %/yr | basket %/yr | gross edge | cost drag | net edge | t | n_eff | beats buy-and-hold? |
|---|---|---|---|---|---|---|---|---|---|
| 1 | ridge | 169.8 | 98.8 | +71.0pp | -85.8pp | -14.8pp | 2.68 | 14.50 | YES |
| 1 | age | 93.0 | 98.8 | -5.9pp | -85.8pp | -91.6pp | -0.10 | 4.68 | no |
| 1 | cheap | 106.5 | 98.8 | +7.7pp | -85.8pp | -78.1pp | 0.30 | 11.60 | no |
| 1 | momentum_3m | 114.2 | 98.8 | +15.4pp | -85.8pp | -70.4pp | 0.63 | 9.88 | no |
| 1 | momentum_6m | 107.9 | 98.8 | +9.1pp | -85.8pp | -76.7pp | 0.28 | 6.36 | no |
| 1 | reversal_3m | 68.1 | 98.8 | -30.8pp | -85.8pp | -116.6pp | -2.15 | 13.85 | no |
| 1 | zero | 86.6 | 98.8 | -12.3pp | -85.8pp | -98.1pp | -0.36 | 8.73 | no |
| 1 | oracle | 736.5 | 98.8 | +637.7pp | -85.8pp | +551.9pp | 18.70 | 17.41 | YES |
| 3 | ridge | 94.9 | 111.6 | -16.7pp | -47.8pp | -64.5pp | -0.65 | 5.00 | no |
| 3 | age | 104.3 | 111.6 | -7.3pp | -47.8pp | -55.1pp | -0.10 | 2.30 | no |
| 3 | cheap | 123.6 | 111.6 | +12.1pp | -47.8pp | -35.7pp | 0.22 | 1.70 | no |
| 3 | momentum_3m | 94.4 | 111.6 | -17.2pp | -47.8pp | -65.0pp | -0.62 | 3.11 | no |
| 3 | momentum_6m | 98.9 | 111.6 | -12.7pp | -47.8pp | -60.5pp | -0.41 | 3.13 | no |
| 3 | reversal_3m | 121.0 | 111.6 | +9.4pp | -47.8pp | -38.4pp | 0.37 | 6.03 | no |
| 3 | zero | 96.8 | 111.6 | -14.8pp | -47.8pp | -62.6pp | -0.34 | 3.25 | no |
| 3 | oracle | 413.3 | 111.6 | +301.7pp | -47.8pp | +253.9pp | 13.86 | 6.24 | YES |
| 6 | ridge | 87.2 | 91.0 | -3.9pp | -27.8pp | -31.6pp | -0.22 | 2.90 | no |
| 6 | age | 119.0 | 91.0 | +28.0pp | -27.8pp | +0.2pp | 0.57 | 1.15 | no |
| 6 | cheap | 84.4 | 91.0 | -6.6pp | -27.8pp | -34.4pp | -0.13 | 1.00 | no |
| 6 | momentum_3m | 81.5 | 91.0 | -9.5pp | -27.8pp | -37.3pp | -0.42 | 2.32 | no |
| 6 | momentum_6m | 84.4 | 91.0 | -6.7pp | -27.8pp | -34.4pp | -0.38 | 3.00 | no |
| 6 | reversal_3m | 112.1 | 91.0 | +21.1pp | -27.8pp | -6.6pp | 1.31 | 3.00 | no |
| 6 | zero | 75.9 | 91.0 | -15.1pp | -27.8pp | -42.9pp | -0.35 | 1.00 | no |
| 6 | oracle | 228.6 | 91.0 | +137.6pp | -27.8pp | +109.8pp | 12.47 | 3.00 | no |
| 12 | ridge | 49.0 | 64.4 | -15.4pp | -15.0pp | -30.4pp | -0.83 | 1.00 | no |
| 12 | age | 82.6 | 64.4 | +18.2pp | -15.0pp | +3.2pp | 2.56 | 1.00 | no |
| 12 | cheap | 73.0 | 64.4 | +8.6pp | -15.0pp | -6.4pp | 0.82 | 1.00 | no |
| 12 | momentum_3m | 68.0 | 64.4 | +3.6pp | -15.0pp | -11.4pp | 0.52 | 1.00 | no |
| 12 | momentum_6m | 62.0 | 64.4 | -2.4pp | -15.0pp | -17.4pp | -0.36 | 1.00 | no |
| 12 | reversal_3m | 58.7 | 64.4 | -5.7pp | -15.0pp | -20.7pp | -0.91 | 1.00 | no |
| 12 | zero | 55.0 | 64.4 | -9.4pp | -15.0pp | -24.4pp | -1.70 | 1.00 | no |
| 12 | oracle | 118.7 | 64.4 | +54.3pp | -15.0pp | +39.3pp | 24.70 | 1.00 | no |

The model's portfolio beats buy-and-hold GROSS at H = 1 months. Net of the rebalancing cost it beats buy-and-hold at NO horizon. A gross-only edge is not a reason to trade; it is a reason to distrust the gross number.

## The selection protocol (reported, never the headline)

The headline model is PRE-REGISTERED (`ridge`), so every fold above is held out and no selection step touched them. For completeness the full candidate roster was also run through choose-on-selection-folds / score-on-evaluation-folds:

- selection folds: 7 (2025-02-01..2025-08-01)
- evaluation folds: 7 (2025-09-01..2026-03-01)
- selection-fold ranking: huber -0.160; rf -0.161; rank_linear -0.164; gbm -0.167; ridge -0.178; elasticnet -0.195; ensemble -0.205; pls -0.231
- winner `huber` scores -0.045 on the evaluation folds (n_eff 1.00): no signal, and n_eff 1.00 is too thin to have found one

**This split is NOT clean and the number above is contaminated.** With an H=6 label window, the last selection fold's outcome is still being realised during the first 5 evaluation folds, and there are not enough months on this archive to buy that gap back and still have folds on both sides. Stating it is the only available remedy; it is also why the headline does not come from here.

## What would change this answer

- **More history.** The binding constraint is the number of non-overlapping forward windows, and that grows only with calendar time. tcgcsv's archive starts 2024-03; eBay and PriceCharting are excluded on terms-of-service grounds, so there is no legitimate way to extend it backwards.
- **A regime change.** Every fold here is a boom month. A signal that works only in a boom is not distinguishable from no signal until a bust supplies the contrast.
- **A tradeable price.** Even the horizon where the model's gross edge is statistically real does not survive a realistic round-trip cost. Any future version of this study should report net, not gross, or it is measuring the wrong thing.

