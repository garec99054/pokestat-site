# Can ETB returns be predicted cross-sectionally?

*Measurement, not investment advice.* This asks one narrow question: standing at month T with only information available at T, can we rank Elite Trainer Boxes by how much they will beat the ETB basket over the next H months? It does NOT ask whether ETBs went up -- `pokestat.model.etb_index` measures that -- and nothing here is a recommendation to buy, hold or sell anything.

**We cannot establish cross-sectional predictability of ETB returns at the primary 6-month horizon.** The pre-registered model's held-out mean rank correlation is -0.116 across 15 purged folds -- the point estimate is negative, and the effective sample is 3.00 independent draws against a 4.0 bar. This is a NULL, and on an archive this short it is the expected and honest answer.

## The window is the finding's ceiling

The archive is 29 monthly cross-sections (2024-06-01..2026-10-01) covering 107 ETB products across 60 sets, of which 1847 rows in 23 months carry a realized 6-month forward return. Every one of those months sits inside a single regime -- a historic sealed-product boom. Nothing here observes a bust, so nothing here can tell you what predicts returns in one.

More sharply: with an H-month forward window, N consecutive monthly folds contain at most (N-1)//H + 1 NON-OVERLAPPING label windows. That is a fact about the design, invisible to any autocorrelation estimate, and it is the binding constraint on almost every cell below. The effective sample used everywhere is the MINIMUM of the autocorrelation-deflated n_eff and that structural bound, and the repo's 4.0-effective-fold bar is applied to it.

Reading the tables: `clears both gates?` is TWO-SIDED -- it asks whether a cell is further from zero than one of its own error bars on a sufficient effective sample, not whether it is positive. That is why a scorer and its exact negation (`momentum_3m` and `reversal_3m`) can both clear it: each is evidence of ITS OWN direction. The sign is stated separately in every verdict line.

## What the model is allowed to see

Target: log(P_{T+H} / P_T) minus the same month's cross-sectional median, so a model that only knows 'everything went up' scores zero. Within a fold this is rank-identical to the absolute return, so the relative framing cannot flatter the IC. Features, all as-of T: trailing 1/3/6-month returns and 6-month volatility; log price; months since release; log set size; the listing-book shape (relative spread, where market clears inside the book, mid-vs-market skew) and its 3-month change; the SET'S OWN chase-single index return and the box price relative to that index; Pokemon Center / retailer-exclusive flags; era dummies; and an in-print PROXY (age <= 24 months).

Two honest notes on the features. (1) **In-print status is not in the database.** There is no field for it; the proxy is age, and it is labelled a proxy everywhere rather than dressed up as a fact. (2) **TCGplayer-Direct quotes do not exist for sealed product** -- `direct_low` is NULL for every sealed row in the archive -- so the direct-discount feature the singles model uses is structurally unavailable here and is excluded rather than carried as an all-missing column.

## Results by horizon

### Horizon H = 1 months

25 purged folds, 2024-09-01..2026-09-01; median cross-section 86.0 products.

*Purge audit* (summed over folds): 0 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 2120 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 25 | 0.274 | 0.088 | 3.11 | 8.30 | 25.0 | 8.30 | yes |
| ridge / static-ablated | 25 | 0.278 | 0.077 | 3.63 | 8.70 | 25.0 | 8.70 | yes |
| ridge / momentum-only | 25 | 0.217 | 0.064 | 3.39 | 13.50 | 25.0 | 13.50 | yes |
| ridge / book-ablated | 25 | 0.188 | 0.093 | 2.01 | 8.66 | 25.0 | 8.66 | yes |
| baseline: age | 25 | -0.029 | 0.180 | -0.16 | 4.30 | 25.0 | 4.30 | no |
| baseline: cheap | 25 | 0.047 | 0.119 | 0.39 | 5.39 | 25.0 | 5.39 | no |
| baseline: momentum_3m | 25 | 0.081 | 0.069 | 1.17 | 10.59 | 25.0 | 10.59 | yes |
| baseline: momentum_6m | 25 | -0.009 | 0.103 | -0.09 | 5.23 | 25.0 | 5.23 | no |
| baseline: reversal_3m | 25 | -0.081 | 0.069 | -1.17 | 10.59 | 25.0 | 10.59 | yes |
| baseline: zero | 25 | 0.000 | 0.000 | n/a | 25.00 | 25.0 | 25.00 | no |
| ridge - momentum_3m (paired) | 25 | 0.192 | 0.062 | 3.12 | 10.28 | 25.0 | 10.28 | yes |
| ridge, embargo=0m | 25 | 0.274 | 0.088 | 3.11 | 8.30 | 25.0 | 8.30 | yes |
| ridge, embargo=1m | 24 | 0.222 | 0.088 | 2.52 | 8.09 | 24.0 | 8.09 | yes |
| oracle (unattainable ceiling) | 25 | 1.000 | 0.000 | n/a | 25.00 | 25.0 | 25.00 | yes |

**Verdict at H=1: evidence of a positive association.**

Fold-wise label permutation (2000 draws): observed mean IC 0.274 against a null centred on -0.001 with SD 0.022; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.268, n_eff 10.70, clears both gates: yes). The fitted model scores 0.274, i.e. it MATCHES its own strongest single input -- every fitted parameter beyond that one feature bought nothing.

### Horizon H = 3 months

21 purged folds, 2024-11-01..2026-07-01; median cross-section 86.0 products.

*Purge audit* (summed over folds): 3522 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1721 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 21 | 0.008 | 0.152 | 0.05 | 4.77 | 7.0 | 4.77 | no |
| ridge / static-ablated | 21 | 0.088 | 0.113 | 0.78 | 5.41 | 7.0 | 5.41 | no |
| ridge / momentum-only | 21 | 0.045 | 0.106 | 0.42 | 6.28 | 7.0 | 6.28 | no |
| ridge / book-ablated | 21 | -0.041 | 0.169 | -0.24 | 4.04 | 7.0 | 4.04 | no |
| baseline: age | 21 | -0.012 | 0.269 | -0.04 | 2.90 | 7.0 | 2.90 | no |
| baseline: cheap | 21 | 0.047 | 0.295 | 0.16 | 1.66 | 7.0 | 1.66 | no |
| baseline: momentum_3m | 21 | -0.084 | 0.136 | -0.62 | 4.09 | 7.0 | 4.09 | no |
| baseline: momentum_6m | 21 | -0.082 | 0.137 | -0.60 | 3.52 | 7.0 | 3.52 | no |
| baseline: reversal_3m | 21 | 0.084 | 0.136 | 0.62 | 4.09 | 7.0 | 4.09 | no |
| baseline: zero | 21 | 0.000 | 0.000 | n/a | 21.00 | 7.0 | 7.00 | no |
| ridge - momentum_3m (paired) | 21 | 0.092 | 0.118 | 0.78 | 7.56 | 7.0 | 7.00 | no |
| ridge, embargo=0m | 21 | 0.008 | 0.152 | 0.05 | 4.77 | 7.0 | 4.77 | no |
| ridge, embargo=1m | 20 | -0.023 | 0.135 | -0.17 | 5.20 | 7.0 | 5.20 | no |
| oracle (unattainable ceiling) | 21 | 1.000 | 0.000 | n/a | 21.00 | 7.0 | 7.00 | yes |

**Verdict at H=3: no signal (does not clear its own one-SE error bar).**

Fold-wise label permutation (2000 draws): observed mean IC 0.008 against a null centred on -0.000 with SD 0.023; two-sided p = 0.722. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.260, n_eff 5.67, clears both gates: yes). The fitted model scores 0.008, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 6 months

15 purged folds, 2025-02-01..2026-04-01; median cross-section 86.0 products.

*Purge audit* (summed over folds): 6096 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1160 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 15 | -0.116 | 0.120 | -0.96 | 3.56 | 3.0 | 3.00 | no |
| ridge / static-ablated | 15 | -0.010 | 0.112 | -0.09 | 4.18 | 3.0 | 3.00 | no |
| ridge / momentum-only | 15 | -0.060 | 0.105 | -0.57 | 8.67 | 3.0 | 3.00 | no |
| ridge / book-ablated | 15 | -0.155 | 0.122 | -1.27 | 3.79 | 3.0 | 3.00 | no |
| baseline: age | 15 | 0.067 | 0.236 | 0.28 | 1.59 | 3.0 | 1.59 | no |
| baseline: cheap | 15 | -0.122 | 0.467 | -0.26 | 1.00 | 3.0 | 1.00 | no |
| baseline: momentum_3m | 15 | -0.165 | 0.132 | -1.25 | 4.70 | 3.0 | 3.00 | no |
| baseline: momentum_6m | 15 | -0.127 | 0.107 | -1.18 | 3.40 | 3.0 | 3.00 | no |
| baseline: reversal_3m | 15 | 0.165 | 0.132 | 1.25 | 4.70 | 3.0 | 3.00 | no |
| baseline: zero | 15 | 0.000 | 0.000 | n/a | 15.00 | 3.0 | 3.00 | no |
| ridge - momentum_3m (paired) | 15 | 0.050 | 0.243 | 0.20 | 2.17 | 3.0 | 2.17 | no |
| ridge, embargo=0m | 15 | -0.116 | 0.120 | -0.96 | 3.56 | 3.0 | 3.00 | no |
| ridge, embargo=1m | 14 | -0.120 | 0.137 | -0.88 | 3.07 | 3.0 | 3.00 | no |
| oracle (unattainable ceiling) | 15 | 1.000 | 0.000 | n/a | 15.00 | 3.0 | 3.00 | no |

**Verdict at H=6: no signal, and n_eff 3.00 is too thin to have found one.**

Fold-wise label permutation (2000 draws): observed mean IC -0.116 against a null centred on -0.000 with SD 0.028; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.269, n_eff 3.00, clears both gates: no). The fitted model scores -0.116, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 12 months

3 purged folds, 2025-08-01..2025-10-01; median cross-section 86.0 products.

*Purge audit* (summed over folds): 2524 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 214 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 3 | -0.281 | 0.268 | -1.05 | 1.00 | 1.0 | 1.00 | no |
| ridge / static-ablated | 3 | -0.100 | 0.238 | -0.42 | 1.00 | 1.0 | 1.00 | no |
| ridge / momentum-only | 3 | -0.157 | 0.306 | -0.51 | 1.00 | 1.0 | 1.00 | no |
| ridge / book-ablated | 3 | -0.360 | 0.214 | -1.68 | 1.00 | 1.0 | 1.00 | no |
| baseline: age | 3 | 0.251 | 0.150 | 1.68 | 1.00 | 1.0 | 1.00 | no |
| baseline: cheap | 3 | 0.023 | 0.147 | 0.16 | 1.00 | 1.0 | 1.00 | no |
| baseline: momentum_3m | 3 | -0.102 | 0.325 | -0.32 | 1.00 | 1.0 | 1.00 | no |
| baseline: momentum_6m | 3 | -0.042 | 0.050 | -0.85 | 3.00 | 1.0 | 1.00 | no |
| baseline: reversal_3m | 3 | 0.102 | 0.325 | 0.32 | 1.00 | 1.0 | 1.00 | no |
| baseline: zero | 3 | 0.000 | 0.000 | n/a | 3.00 | 1.0 | 1.00 | no |
| ridge - momentum_3m (paired) | 3 | -0.179 | 0.081 | -2.20 | 3.00 | 1.0 | 1.00 | no |
| ridge, embargo=0m | 3 | -0.281 | 0.268 | -1.05 | 1.00 | 1.0 | 1.00 | no |
| ridge, embargo=1m | 2 | -0.438 | 0.134 | -3.27 | 2.00 | 1.0 | 1.00 | no |
| oracle (unattainable ceiling) | 3 | 1.000 | 0.000 | n/a | 3.00 | 1.0 | 1.00 | no |

**Verdict at H=12: clears the one-SE bar but on n_eff 1.00 < 4.0 -- INSUFFICIENT EVIDENCE.**

Fold-wise label permutation (2000 draws): observed mean IC -0.281 against a null centred on -0.001 with SD 0.064; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `months_since_release` (mean IC 0.251, n_eff 1.00, clears both gates: no). The fitted model scores -0.281, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

## The strongest feature is a measurement artefact, not a forecast

`mid_skew` = (mid - market) / market is the best single predictor in this panel at H = 1, 3, 6 (not everywhere: H = 12 `rel_spread`). It has two rival readings, and they disagree about what the listing book does NEXT: if sellers are holding out because demand is real, the book should keep rising; if TCGplayer's trailing `market` average simply has not caught up, the two series should converge. The test is direct.

| H | mid_skew -> forward MARKET return | -> forward change in BOOK MID | -> change in the gap | signature |
|---|---|---|---|---|
| 1 | 0.268 (t 4.50) | -0.234 (t -4.53) | -0.437 (t -15.29) | CONVERGENCE |
| 3 | 0.260 (t 3.00) | -0.293 (t -5.81) | -0.534 (t -11.11) | CONVERGENCE |
| 6 | 0.269 (t 2.92) | -0.316 (t -4.46) | -0.624 (t -8.98) | CONVERGENCE |
| 12 | 0.011 (t 0.08) | -0.385 (t -6.10) | -0.682 (t -5.88) | CONVERGENCE |

Every horizon shows the same pattern: a high `mid_skew` predicts the traded price RISING and the listing midpoint FALLING, with the gap between them closing hard. That is two measurements of the same thing meeting in the middle -- an artefact of `market` being a trailing transaction-weighted average while `mid` is a current quote -- not a forecast that a box is worth more. Half the convergence is the book coming DOWN, so a holder does not capture the full move, and none of it is realisable at the price the index records.

The same defect has a second edge. Because `market` is a trailing transaction-weighted average, a monthly change in it is a change in a SMOOTHED series, and smoothing induces positive autocorrelation in measured returns even when the underlying price is a random walk -- the appraisal-smoothing problem familiar from illiquid asset indices. That is exactly where the second-strongest one-month feature lives: `mom_1m` scores a mean IC of 0.227 at H=1 (n_eff 22.72) and fades at longer horizons. Short-horizon 'momentum' in this panel should therefore be read as a property of the price SERIES, not of the market, until a non-smoothed quote can confirm it -- and no such quote exists in the permitted sources.

## Against the only benchmark that matters: buy the whole basket

A rank correlation is not money. This is the same walk-forward, turned into an equal-weight top-5th portfolio rebalanced every H months and differenced against holding every ETB in the panel. `cost drag` is 15% round-trip (the conservative end of the bid-ask + fees range the data audit found on thin sealed listings) applied at every rebalance, 12/H times a year; buy-and-hold pays it once and amortises it to roughly nothing.

Read the `zero` row first: it scores every product identically, so its 'top quintile' is an ARBITRARY fifth of the basket. Whatever edge it shows is pure partition noise, and it is the floor any real scorer has to clear.

| H | scorer | top-quintile %/yr | basket %/yr | gross edge | cost drag | net edge | t | n_eff | beats buy-and-hold? |
|---|---|---|---|---|---|---|---|---|---|
| 1 | ridge | 160.9 | 93.8 | +67.1pp | -85.8pp | -18.7pp | 2.65 | 14.05 | YES |
| 1 | age | 89.3 | 93.8 | -4.5pp | -85.8pp | -90.2pp | -0.08 | 4.92 | no |
| 1 | cheap | 102.2 | 93.8 | +8.4pp | -85.8pp | -77.4pp | 0.33 | 10.48 | no |
| 1 | momentum_3m | 109.9 | 93.8 | +16.1pp | -85.8pp | -69.7pp | 0.67 | 10.17 | no |
| 1 | momentum_6m | 99.9 | 93.8 | +6.1pp | -85.8pp | -79.7pp | 0.20 | 6.47 | no |
| 1 | reversal_3m | 68.8 | 93.8 | -25.0pp | -85.8pp | -110.8pp | -1.44 | 11.67 | no |
| 1 | zero | 89.0 | 93.8 | -4.8pp | -85.8pp | -90.6pp | -0.15 | 7.91 | no |
| 1 | oracle | 680.8 | 93.8 | +587.0pp | -85.8pp | +501.2pp | 16.20 | 16.39 | YES |
| 3 | ridge | 102.0 | 104.5 | -2.5pp | -47.8pp | -50.3pp | -0.09 | 6.87 | no |
| 3 | age | 102.2 | 104.5 | -2.3pp | -47.8pp | -50.1pp | -0.03 | 2.17 | no |
| 3 | cheap | 116.9 | 104.5 | +12.4pp | -47.8pp | -35.4pp | 0.24 | 1.78 | no |
| 3 | momentum_3m | 86.7 | 104.5 | -17.8pp | -47.8pp | -65.6pp | -0.62 | 3.12 | no |
| 3 | momentum_6m | 88.0 | 104.5 | -16.5pp | -47.8pp | -64.3pp | -0.52 | 2.72 | no |
| 3 | reversal_3m | 121.1 | 104.5 | +16.6pp | -47.8pp | -31.2pp | 0.62 | 5.92 | no |
| 3 | zero | 95.5 | 104.5 | -9.0pp | -47.8pp | -56.8pp | -0.23 | 3.13 | no |
| 3 | oracle | 389.1 | 104.5 | +284.5pp | -47.8pp | +236.7pp | 13.95 | 6.48 | YES |
| 6 | ridge | 79.4 | 86.9 | -7.5pp | -27.8pp | -35.3pp | -0.46 | 3.00 | no |
| 6 | age | 113.1 | 86.9 | +26.1pp | -27.8pp | -1.6pp | 0.62 | 1.34 | no |
| 6 | cheap | 84.1 | 86.9 | -2.9pp | -27.8pp | -30.6pp | -0.06 | 1.00 | no |
| 6 | momentum_3m | 73.7 | 86.9 | -13.2pp | -27.8pp | -41.0pp | -0.57 | 2.33 | no |
| 6 | momentum_6m | 79.7 | 86.9 | -7.2pp | -27.8pp | -35.0pp | -0.36 | 2.22 | no |
| 6 | reversal_3m | 110.7 | 86.9 | +23.7pp | -27.8pp | -4.0pp | 1.33 | 3.00 | no |
| 6 | zero | 71.7 | 86.9 | -15.2pp | -27.8pp | -43.0pp | -0.50 | 1.48 | no |
| 6 | oracle | 216.6 | 86.9 | +129.7pp | -27.8pp | +101.9pp | 11.74 | 3.00 | no |
| 12 | ridge | 34.0 | 54.9 | -21.0pp | -15.0pp | -36.0pp | -1.12 | 1.00 | no |
| 12 | age | 75.9 | 54.9 | +20.9pp | -15.0pp | +5.9pp | 2.90 | 1.00 | no |
| 12 | cheap | 69.2 | 54.9 | +14.3pp | -15.0pp | -0.7pp | 1.29 | 1.00 | no |
| 12 | momentum_3m | 50.9 | 54.9 | -4.0pp | -15.0pp | -19.0pp | -0.29 | 1.00 | no |
| 12 | momentum_6m | 52.6 | 54.9 | -2.3pp | -15.0pp | -17.3pp | -0.51 | 1.00 | no |
| 12 | reversal_3m | 58.0 | 54.9 | +3.1pp | -15.0pp | -11.9pp | 0.17 | 1.00 | no |
| 12 | zero | 37.6 | 54.9 | -17.3pp | -15.0pp | -32.3pp | -2.75 | 1.00 | no |
| 12 | oracle | 106.0 | 54.9 | +51.0pp | -15.0pp | +36.0pp | 20.38 | 1.00 | no |

The model's portfolio beats buy-and-hold GROSS at H = 1 months. Net of the rebalancing cost it beats buy-and-hold at NO horizon. A gross-only edge is not a reason to trade; it is a reason to distrust the gross number.

## The selection protocol (reported, never the headline)

The headline model is PRE-REGISTERED (`ridge`), so every fold above is held out and no selection step touched them. For completeness the full candidate roster was also run through choose-on-selection-folds / score-on-evaluation-folds:

- selection folds: 8 (2025-02-01..2025-09-01)
- evaluation folds: 7 (2025-10-01..2026-04-01)
- selection-fold ranking: rank_linear -0.166; huber -0.166; gbm -0.168; rf -0.170; ridge -0.185; elasticnet -0.209; ensemble -0.212; pls -0.245
- winner `rank_linear` scores -0.021 on the evaluation folds (n_eff 2.00): no signal, and n_eff 2.00 is too thin to have found one

**This split is NOT clean and the number above is contaminated.** With an H=6 label window, the last selection fold's outcome is still being realised during the first 5 evaluation folds, and there are not enough months on this archive to buy that gap back and still have folds on both sides. Stating it is the only available remedy; it is also why the headline does not come from here.

## What would change this answer

- **More history.** The binding constraint is the number of non-overlapping forward windows, and that grows only with calendar time. tcgcsv's archive starts 2024-03; eBay and PriceCharting are excluded on terms-of-service grounds, so there is no legitimate way to extend it backwards.
- **A regime change.** Every fold here is a boom month. A signal that works only in a boom is not distinguishable from no signal until a bust supplies the contrast.
- **A tradeable price.** Even where the model's portfolio beats buy-and-hold gross (H = 1), it does not survive a realistic round-trip cost. Any future version of this study should report net, not gross, or it is measuring the wrong thing.

