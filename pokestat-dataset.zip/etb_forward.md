# Can ETB returns be predicted cross-sectionally?

*Measurement, not investment advice.* This asks one narrow question: standing at month T with only information available at T, can we rank Elite Trainer Boxes by how much they will beat the ETB basket over the next H months? It does NOT ask whether ETBs went up -- `pokestat.model.etb_index` measures that -- and nothing here is a recommendation to buy, hold or sell anything.

**We cannot establish cross-sectional predictability of ETB returns at the primary 6-month horizon.** The pre-registered model's held-out mean rank correlation is -0.121 across 14 purged folds -- the point estimate is negative, and the effective sample is 1.92 independent draws against a 4.0 bar. This is a NULL, and on 29 months of data it is the expected and honest answer.

## The window is the finding's ceiling

The archive is 28 monthly cross-sections (2024-06-01..2026-09-01) covering 109 ETB products across 61 sets, of which 1801 rows in 22 months carry a realized 6-month forward return. Every one of those months sits inside a single regime -- a historic sealed-product boom. Nothing here observes a bust, so nothing here can tell you what predicts returns in one.

More sharply: with an H-month forward window, N consecutive monthly folds contain at most (N-1)//H + 1 NON-OVERLAPPING label windows. That is a fact about the design, invisible to any autocorrelation estimate, and it is the binding constraint on almost every cell below. The effective sample used everywhere is the MINIMUM of the autocorrelation-deflated n_eff and that structural bound, and the repo's 4.0-effective-fold bar is applied to it.

Reading the tables: `clears both gates?` is TWO-SIDED -- it asks whether a cell is further from zero than one of its own error bars on a sufficient effective sample, not whether it is positive. That is why a scorer and its exact negation (`momentum_3m` and `reversal_3m`) can both clear it: each is evidence of ITS OWN direction. The sign is stated separately in every verdict line.

## What the model is allowed to see

Target: log(P_{T+H} / P_T) minus the same month's cross-sectional median, so a model that only knows 'everything went up' scores zero. Within a fold this is rank-identical to the absolute return, so the relative framing cannot flatter the IC. Features, all as-of T: trailing 1/3/6-month returns and 6-month volatility; log price; months since release; log set size; the listing-book shape (relative spread, where market clears inside the book, mid-vs-market skew) and its 3-month change; the SET'S OWN chase-single index return and the box price relative to that index; Pokemon Center / retailer-exclusive flags; era dummies; and an in-print PROXY (age <= 24 months).

Two honest notes on the features. (1) **In-print status is not in the database.** There is no field for it; the proxy is age, and it is labelled a proxy everywhere rather than dressed up as a fact. (2) **TCGplayer-Direct quotes do not exist for sealed product** -- `direct_low` is NULL for every sealed row in the archive -- so the direct-discount feature the singles model uses is structurally unavailable here and is excluded rather than carried as an all-missing column.

## Results by horizon

### Horizon H = 1 months

24 purged folds, 2024-09-01..2026-08-01; median cross-section 88.0 products.

*Purge audit* (summed over folds): 0 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 2071 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 24 | 0.266 | 0.076 | 3.49 | 10.02 | 24.0 | 10.02 | yes |
| ridge / static-ablated | 24 | 0.272 | 0.068 | 4.01 | 10.35 | 24.0 | 10.35 | yes |
| ridge / momentum-only | 24 | 0.205 | 0.060 | 3.40 | 13.62 | 24.0 | 13.62 | yes |
| ridge / book-ablated | 24 | 0.176 | 0.082 | 2.14 | 9.59 | 24.0 | 9.59 | yes |
| baseline: age | 24 | -0.035 | 0.172 | -0.20 | 4.62 | 24.0 | 4.62 | no |
| baseline: cheap | 24 | 0.049 | 0.120 | 0.41 | 5.39 | 24.0 | 5.39 | no |
| baseline: momentum_3m | 24 | 0.074 | 0.061 | 1.21 | 10.41 | 24.0 | 10.41 | yes |
| baseline: momentum_6m | 24 | 0.002 | 0.112 | 0.02 | 4.37 | 24.0 | 4.37 | no |
| baseline: reversal_3m | 24 | -0.074 | 0.061 | -1.21 | 10.41 | 24.0 | 10.41 | yes |
| baseline: zero | 24 | 0.000 | 0.000 | n/a | 24.00 | 24.0 | 24.00 | no |
| ridge - momentum_3m (paired) | 24 | 0.192 | 0.059 | 3.26 | 10.30 | 24.0 | 10.30 | yes |
| ridge, embargo=0m | 24 | 0.266 | 0.076 | 3.49 | 10.02 | 24.0 | 10.02 | yes |
| ridge, embargo=1m | 23 | 0.215 | 0.085 | 2.52 | 7.98 | 23.0 | 7.98 | yes |
| oracle (unattainable ceiling) | 24 | 1.000 | 0.000 | n/a | 24.00 | 24.0 | 24.00 | yes |

**Verdict at H=1: evidence of a positive association.**

Fold-wise label permutation (2000 draws): observed mean IC 0.266 against a null centred on -0.000 with SD 0.022; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.271, n_eff 10.50, clears both gates: yes). The fitted model scores 0.266, i.e. it MATCHES its own strongest single input -- every fitted parameter beyond that one feature bought nothing.

### Horizon H = 3 months

20 purged folds, 2024-11-01..2026-06-01; median cross-section 88.0 products.

*Purge audit* (summed over folds): 3417 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1668 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 20 | -0.027 | 0.148 | -0.18 | 4.10 | 7.0 | 4.10 | no |
| ridge / static-ablated | 20 | 0.071 | 0.095 | 0.74 | 5.70 | 7.0 | 5.70 | no |
| ridge / momentum-only | 20 | -0.003 | 0.104 | -0.03 | 6.14 | 7.0 | 6.14 | no |
| ridge / book-ablated | 20 | -0.098 | 0.199 | -0.49 | 2.58 | 7.0 | 2.58 | no |
| baseline: age | 20 | -0.023 | 0.255 | -0.09 | 3.22 | 7.0 | 3.22 | no |
| baseline: cheap | 20 | 0.055 | 0.307 | 0.18 | 1.56 | 7.0 | 1.56 | no |
| baseline: momentum_3m | 20 | -0.060 | 0.125 | -0.48 | 4.34 | 7.0 | 4.34 | no |
| baseline: momentum_6m | 20 | -0.049 | 0.126 | -0.39 | 3.93 | 7.0 | 3.93 | no |
| baseline: reversal_3m | 20 | 0.060 | 0.125 | 0.48 | 4.34 | 7.0 | 4.34 | no |
| baseline: zero | 20 | 0.000 | 0.000 | n/a | 20.00 | 7.0 | 7.00 | no |
| ridge - momentum_3m (paired) | 20 | 0.033 | 0.106 | 0.31 | 8.22 | 7.0 | 7.00 | no |
| ridge, embargo=0m | 20 | -0.027 | 0.148 | -0.18 | 4.10 | 7.0 | 4.10 | no |
| ridge, embargo=1m | 19 | -0.051 | 0.120 | -0.43 | 5.38 | 7.0 | 5.38 | no |
| oracle (unattainable ceiling) | 20 | 1.000 | 0.000 | n/a | 20.00 | 7.0 | 7.00 | yes |

**Verdict at H=3: no signal (does not clear its own one-SE error bar).**

Fold-wise label permutation (2000 draws): observed mean IC -0.027 against a null centred on 0.000 with SD 0.023; two-sided p = 0.260. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.244, n_eff 6.39, clears both gates: yes). The fitted model scores -0.027, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 6 months

14 purged folds, 2025-02-01..2026-03-01; median cross-section 88.0 products.

*Purge audit* (summed over folds): 5804 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1102 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 14 | -0.121 | 0.154 | -0.78 | 1.92 | 3.0 | 1.92 | no |
| ridge / static-ablated | 14 | -0.036 | 0.112 | -0.32 | 2.21 | 3.0 | 2.21 | no |
| ridge / momentum-only | 14 | -0.112 | 0.099 | -1.13 | 5.68 | 3.0 | 3.00 | no |
| ridge / book-ablated | 14 | -0.166 | 0.119 | -1.39 | 2.63 | 3.0 | 2.63 | no |
| baseline: age | 14 | 0.066 | 0.293 | 0.22 | 1.16 | 3.0 | 1.16 | no |
| baseline: cheap | 14 | -0.150 | 0.448 | -0.34 | 1.00 | 3.0 | 1.00 | no |
| baseline: momentum_3m | 14 | -0.138 | 0.127 | -1.09 | 3.47 | 3.0 | 3.00 | no |
| baseline: momentum_6m | 14 | -0.137 | 0.120 | -1.15 | 3.08 | 3.0 | 3.00 | no |
| baseline: reversal_3m | 14 | 0.138 | 0.127 | 1.09 | 3.47 | 3.0 | 3.00 | no |
| baseline: zero | 14 | 0.000 | 0.000 | n/a | 14.00 | 3.0 | 3.00 | no |
| ridge - momentum_3m (paired) | 14 | 0.017 | 0.272 | 0.06 | 1.96 | 3.0 | 1.96 | no |
| ridge, embargo=0m | 14 | -0.121 | 0.154 | -0.78 | 1.92 | 3.0 | 1.92 | no |
| ridge, embargo=1m | 13 | -0.117 | 0.183 | -0.64 | 1.68 | 3.0 | 1.68 | no |
| oracle (unattainable ceiling) | 14 | 1.000 | 0.000 | n/a | 14.00 | 3.0 | 3.00 | no |

**Verdict at H=6: no signal, and n_eff 1.92 is too thin to have found one.**

Fold-wise label permutation (2000 draws): observed mean IC -0.121 against a null centred on -0.001 with SD 0.029; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.282, n_eff 3.00, clears both gates: no). The fitted model scores -0.121, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 12 months

2 purged folds, 2025-08-01..2025-09-01; median cross-section 88.0 products.

*Purge audit* (summed over folds): 1716 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 145 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 2 | -0.201 | 0.203 | -0.99 | 2.00 | 1.0 | 1.00 | no |
| ridge / static-ablated | 2 | -0.056 | 0.222 | -0.25 | 2.00 | 1.0 | 1.00 | no |
| ridge / momentum-only | 2 | -0.051 | 0.251 | -0.20 | 2.00 | 1.0 | 1.00 | no |
| ridge / book-ablated | 2 | -0.281 | 0.151 | -1.86 | 2.00 | 1.0 | 1.00 | no |
| baseline: age | 2 | 0.130 | 0.062 | 2.09 | 2.00 | 1.0 | 1.00 | no |
| baseline: cheap | 2 | -0.020 | 0.184 | -0.11 | 2.00 | 1.0 | 1.00 | no |
| baseline: momentum_3m | 2 | 0.034 | 0.215 | 0.16 | 2.00 | 1.0 | 1.00 | no |
| baseline: momentum_6m | 2 | -0.066 | 0.075 | -0.88 | 2.00 | 1.0 | 1.00 | no |
| baseline: reversal_3m | 2 | -0.034 | 0.215 | -0.16 | 2.00 | 1.0 | 1.00 | no |
| baseline: zero | 2 | 0.000 | 0.000 | n/a | 2.00 | 1.0 | 1.00 | no |
| ridge - momentum_3m (paired) | 2 | -0.235 | 0.012 | -18.95 | 2.00 | 1.0 | 1.00 | no |
| ridge, embargo=0m | 2 | -0.201 | 0.203 | -0.99 | 2.00 | 1.0 | 1.00 | no |
| ridge, embargo=1m | 1 | -0.383 | n/a | n/a | 1.00 | 1.0 | 1.00 | no |
| oracle (unattainable ceiling) | 2 | 1.000 | 0.000 | n/a | 2.00 | 1.0 | 1.00 | no |

**Verdict at H=12: no signal, and n_eff 1.00 is too thin to have found one.**

Fold-wise label permutation (2000 draws): observed mean IC -0.201 against a null centred on 0.001 with SD 0.076; two-sided p = 0.009. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `market_pos` (mean IC 0.232, n_eff 1.00, clears both gates: no). The fitted model scores -0.201, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

## The strongest feature is a measurement artefact, not a forecast

`mid_skew` = (mid - market) / market is the best single predictor in this panel at every horizon. It has two rival readings, and they disagree about what the listing book does NEXT: if sellers are holding out because demand is real, the book should keep rising; if TCGplayer's trailing `market` average simply has not caught up, the two series should converge. The test is direct.

| H | mid_skew -> forward MARKET return | -> forward change in BOOK MID | -> change in the gap | signature |
|---|---|---|---|---|
| 1 | 0.271 (t 4.44) | -0.238 (t -4.60) | -0.449 (t -16.75) | CONVERGENCE |
| 3 | 0.244 (t 3.11) | -0.299 (t -5.79) | -0.532 (t -11.40) | CONVERGENCE |
| 6 | 0.282 (t 3.31) | -0.288 (t -4.88) | -0.606 (t -9.15) | CONVERGENCE |
| 12 | -0.065 (t -0.57) | -0.408 (t -3.92) | -0.672 (t -4.48) | not convergence |

The signature is NOT uniform across horizons, so the measurement-lag reading is not established; both readings survive and `mid_skew` should be treated as unexplained rather than as either signal or artefact.

The same defect has a second edge. Because `market` is a trailing transaction-weighted average, a monthly change in it is a change in a SMOOTHED series, and smoothing induces positive autocorrelation in measured returns even when the underlying price is a random walk -- the appraisal-smoothing problem familiar from illiquid asset indices. That is exactly where the second-strongest one-month feature lives: `mom_1m` scores a mean IC of 0.219 at H=1 (n_eff 24.00) and fades at longer horizons. Short-horizon 'momentum' in this panel should therefore be read as a property of the price SERIES, not of the market, until a non-smoothed quote can confirm it -- and no such quote exists in the permitted sources.

## Against the only benchmark that matters: buy the whole basket

A rank correlation is not money. This is the same walk-forward, turned into an equal-weight top-5th portfolio rebalanced every H months and differenced against holding every ETB in the panel. `cost drag` is 15% round-trip (the conservative end of the bid-ask + fees range the data audit found on thin sealed listings) applied at every rebalance, 12/H times a year; buy-and-hold pays it once and amortises it to roughly nothing.

Read the `zero` row first: it scores every product identically, so its 'top quintile' is an ARBITRARY fifth of the basket. Whatever edge it shows is pure partition noise, and it is the floor any real scorer has to clear.

| H | scorer | top-quintile %/yr | basket %/yr | gross edge | cost drag | net edge | t | n_eff | beats buy-and-hold? |
|---|---|---|---|---|---|---|---|---|---|
| 1 | ridge | 170.1 | 98.9 | +71.3pp | -85.8pp | -14.5pp | 2.77 | 14.40 | YES |
| 1 | age | 92.7 | 98.9 | -6.1pp | -85.8pp | -91.9pp | -0.10 | 4.56 | no |
| 1 | cheap | 108.4 | 98.9 | +9.5pp | -85.8pp | -76.3pp | 0.38 | 11.72 | no |
| 1 | momentum_3m | 113.2 | 98.9 | +14.3pp | -85.8pp | -71.4pp | 0.60 | 9.84 | no |
| 1 | momentum_6m | 107.5 | 98.9 | +8.6pp | -85.8pp | -77.2pp | 0.25 | 5.61 | no |
| 1 | reversal_3m | 69.1 | 98.9 | -29.8pp | -85.8pp | -115.6pp | -2.08 | 13.72 | no |
| 1 | zero | 89.1 | 98.9 | -9.8pp | -85.8pp | -95.6pp | -0.29 | 8.91 | no |
| 1 | oracle | 734.2 | 98.9 | +635.3pp | -85.8pp | +549.5pp | 18.09 | 15.67 | YES |
| 3 | ridge | 98.1 | 111.6 | -13.5pp | -47.8pp | -61.3pp | -0.53 | 5.34 | no |
| 3 | age | 106.6 | 111.6 | -5.0pp | -47.8pp | -52.8pp | -0.07 | 2.23 | no |
| 3 | cheap | 124.5 | 111.6 | +12.9pp | -47.8pp | -34.9pp | 0.24 | 1.76 | no |
| 3 | momentum_3m | 95.1 | 111.6 | -16.6pp | -47.8pp | -64.4pp | -0.64 | 3.48 | no |
| 3 | momentum_6m | 100.1 | 111.6 | -11.6pp | -47.8pp | -59.4pp | -0.42 | 4.13 | no |
| 3 | reversal_3m | 121.9 | 111.6 | +10.2pp | -47.8pp | -37.6pp | 0.42 | 6.46 | no |
| 3 | zero | 98.9 | 111.6 | -12.8pp | -47.8pp | -60.6pp | -0.30 | 3.36 | no |
| 3 | oracle | 409.2 | 111.6 | +297.6pp | -47.8pp | +249.8pp | 14.26 | 6.51 | YES |
| 6 | ridge | 86.1 | 91.0 | -4.8pp | -27.8pp | -32.6pp | -0.29 | 2.97 | no |
| 6 | age | 119.5 | 91.0 | +28.6pp | -27.8pp | +0.8pp | 0.57 | 1.10 | no |
| 6 | cheap | 86.3 | 91.0 | -4.7pp | -27.8pp | -32.4pp | -0.10 | 1.00 | no |
| 6 | momentum_3m | 81.8 | 91.0 | -9.2pp | -27.8pp | -36.9pp | -0.37 | 2.00 | no |
| 6 | momentum_6m | 84.1 | 91.0 | -6.9pp | -27.8pp | -34.6pp | -0.40 | 3.00 | no |
| 6 | reversal_3m | 112.6 | 91.0 | +21.6pp | -27.8pp | -6.1pp | 1.35 | 3.00 | no |
| 6 | zero | 76.0 | 91.0 | -14.9pp | -27.8pp | -42.7pp | -0.35 | 1.00 | no |
| 6 | oracle | 227.9 | 91.0 | +136.9pp | -27.8pp | +109.2pp | 11.85 | 3.00 | no |
| 12 | ridge | 48.4 | 64.7 | -16.3pp | -15.0pp | -31.3pp | -0.81 | 1.00 | no |
| 12 | age | 82.6 | 64.7 | +17.9pp | -15.0pp | +2.9pp | 2.60 | 1.00 | no |
| 12 | cheap | 73.8 | 64.7 | +9.1pp | -15.0pp | -5.9pp | 0.93 | 1.00 | no |
| 12 | momentum_3m | 68.0 | 64.7 | +3.3pp | -15.0pp | -11.7pp | 0.46 | 1.00 | no |
| 12 | momentum_6m | 62.0 | 64.7 | -2.7pp | -15.0pp | -17.7pp | -0.41 | 1.00 | no |
| 12 | reversal_3m | 59.3 | 64.7 | -5.5pp | -15.0pp | -20.5pp | -1.03 | 1.00 | no |
| 12 | zero | 55.0 | 64.7 | -9.7pp | -15.0pp | -24.7pp | -1.82 | 1.00 | no |
| 12 | oracle | 119.4 | 64.7 | +54.7pp | -15.0pp | +39.7pp | 33.06 | 1.00 | no |

The model's portfolio beats buy-and-hold GROSS at H = 1 months. Net of the rebalancing cost it beats buy-and-hold at NO horizon. A gross-only edge is not a reason to trade; it is a reason to distrust the gross number.

## The selection protocol (reported, never the headline)

The headline model is PRE-REGISTERED (`ridge`), so every fold above is held out and no selection step touched them. For completeness the full candidate roster was also run through choose-on-selection-folds / score-on-evaluation-folds:

- selection folds: 7 (2025-02-01..2025-08-01)
- evaluation folds: 7 (2025-09-01..2026-03-01)
- selection-fold ranking: huber -0.150; rank_linear -0.155; rf -0.159; gbm -0.170; ridge -0.171; elasticnet -0.188; ensemble -0.194; pls -0.225
- winner `huber` scores -0.049 on the evaluation folds (n_eff 1.00): no signal, and n_eff 1.00 is too thin to have found one

**This split is NOT clean and the number above is contaminated.** With an H=6 label window, the last selection fold's outcome is still being realised during the first 5 evaluation folds, and there are not enough months on this archive to buy that gap back and still have folds on both sides. Stating it is the only available remedy; it is also why the headline does not come from here.

## What would change this answer

- **More history.** The binding constraint is the number of non-overlapping forward windows, and that grows only with calendar time. tcgcsv's archive starts 2024-03; eBay and PriceCharting are excluded on terms-of-service grounds, so there is no legitimate way to extend it backwards.
- **A regime change.** Every fold here is a boom month. A signal that works only in a boom is not distinguishable from no signal until a bust supplies the contrast.
- **A tradeable price.** Even the horizon where the model's gross edge is statistically real does not survive a realistic round-trip cost. Any future version of this study should report net, not gross, or it is measuring the wrong thing.

