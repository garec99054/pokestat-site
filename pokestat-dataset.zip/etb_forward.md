# Can ETB returns be predicted cross-sectionally?

*Measurement, not investment advice.* This asks one narrow question: standing at month T with only information available at T, can we rank Elite Trainer Boxes by how much they will beat the ETB basket over the next H months? It does NOT ask whether ETBs went up -- `pokestat.model.etb_index` measures that -- and nothing here is a recommendation to buy, hold or sell anything.

**We cannot establish cross-sectional predictability of ETB returns at the primary 6-month horizon.** The pre-registered model's held-out mean rank correlation is -0.122 across 16 purged folds -- the point estimate is negative, and the effective sample is 3.00 independent draws against a 4.0 bar. This is a NULL, and on an archive this short it is the expected and honest answer.

## The window is the finding's ceiling

The archive is 30 monthly cross-sections (2024-06-01..2026-11-01) covering 109 ETB products across 61 sets, of which 1945 rows in 24 months carry a realized 6-month forward return. Every one of those months sits inside a single regime -- a historic sealed-product boom. Nothing here observes a bust, so nothing here can tell you what predicts returns in one.

More sharply: with an H-month forward window, N consecutive monthly folds contain at most (N-1)//H + 1 NON-OVERLAPPING label windows. That is a fact about the design, invisible to any autocorrelation estimate, and it is the binding constraint on almost every cell below. The effective sample used everywhere is the MINIMUM of the autocorrelation-deflated n_eff and that structural bound, and the repo's 4.0-effective-fold bar is applied to it.

Reading the tables: `clears both gates?` is TWO-SIDED -- it asks whether a cell is further from zero than one of its own error bars on a sufficient effective sample, not whether it is positive. That is why a scorer and its exact negation (`momentum_3m` and `reversal_3m`) can both clear it: each is evidence of ITS OWN direction. The sign is stated separately in every verdict line.

## What the model is allowed to see

Target: log(P_{T+H} / P_T) minus the same month's cross-sectional median, so a model that only knows 'everything went up' scores zero. Within a fold this is rank-identical to the absolute return, so the relative framing cannot flatter the IC. Features, all as-of T: trailing 1/3/6-month returns and 6-month volatility; log price; months since release; log set size; the listing-book shape (relative spread, where market clears inside the book, mid-vs-market skew) and its 3-month change; the SET'S OWN chase-single index return and the box price relative to that index; Pokemon Center / retailer-exclusive flags; era dummies; and an in-print PROXY (age <= 24 months).

Two honest notes on the features. (1) **In-print status is not in the database.** There is no field for it; the proxy is age, and it is labelled a proxy everywhere rather than dressed up as a fact. (2) **TCGplayer-Direct quotes do not exist for sealed product** -- `direct_low` is NULL for every sealed row in the archive -- so the direct-discount feature the singles model uses is structurally unavailable here and is excluded rather than carried as an all-missing column.

## Results by horizon

### Horizon H = 1 months

26 purged folds, 2024-09-01..2026-10-01; median cross-section 86.0 products.

*Purge audit* (summed over folds): 0 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 2222 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 26 | 0.273 | 0.084 | 3.26 | 8.77 | 26.0 | 8.77 | yes |
| ridge / static-ablated | 26 | 0.280 | 0.074 | 3.79 | 9.02 | 26.0 | 9.02 | yes |
| ridge / momentum-only | 26 | 0.219 | 0.062 | 3.55 | 13.91 | 26.0 | 13.91 | yes |
| ridge / book-ablated | 26 | 0.188 | 0.089 | 2.12 | 9.13 | 26.0 | 9.13 | yes |
| baseline: age | 26 | -0.011 | 0.185 | -0.06 | 4.15 | 26.0 | 4.15 | no |
| baseline: cheap | 26 | 0.041 | 0.115 | 0.36 | 5.55 | 26.0 | 5.55 | no |
| baseline: momentum_3m | 26 | 0.093 | 0.073 | 1.26 | 9.70 | 26.0 | 9.70 | yes |
| baseline: momentum_6m | 26 | -0.005 | 0.098 | -0.06 | 5.65 | 26.0 | 5.65 | no |
| baseline: reversal_3m | 26 | -0.093 | 0.073 | -1.26 | 9.70 | 26.0 | 9.70 | yes |
| baseline: zero | 26 | 0.000 | 0.000 | n/a | 26.00 | 26.0 | 26.00 | no |
| ridge - momentum_3m (paired) | 26 | 0.181 | 0.064 | 2.80 | 9.93 | 26.0 | 9.93 | yes |
| ridge, embargo=0m | 26 | 0.273 | 0.084 | 3.26 | 8.77 | 26.0 | 8.77 | yes |
| ridge, embargo=1m | 25 | 0.222 | 0.084 | 2.65 | 8.53 | 25.0 | 8.53 | yes |
| oracle (unattainable ceiling) | 26 | 1.000 | 0.000 | n/a | 26.00 | 26.0 | 26.00 | yes |

**Verdict at H=1: evidence of a positive association.**

Fold-wise label permutation (2000 draws): observed mean IC 0.273 against a null centred on -0.000 with SD 0.021; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.265, n_eff 10.96, clears both gates: yes). The fitted model scores 0.273, i.e. it MATCHES its own strongest single input -- every fitted parameter beyond that one feature bought nothing.

### Horizon H = 3 months

22 purged folds, 2024-11-01..2026-08-01; median cross-section 86.0 products.

*Purge audit* (summed over folds): 3718 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1817 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 22 | 0.011 | 0.145 | 0.08 | 5.01 | 8.0 | 5.01 | no |
| ridge / static-ablated | 22 | 0.099 | 0.114 | 0.87 | 5.30 | 8.0 | 5.30 | no |
| ridge / momentum-only | 22 | 0.053 | 0.104 | 0.51 | 6.32 | 8.0 | 6.32 | no |
| ridge / book-ablated | 22 | -0.040 | 0.161 | -0.25 | 4.26 | 8.0 | 4.26 | no |
| baseline: age | 22 | 0.015 | 0.279 | 0.05 | 2.78 | 8.0 | 2.78 | no |
| baseline: cheap | 22 | 0.039 | 0.283 | 0.14 | 1.73 | 8.0 | 1.73 | no |
| baseline: momentum_3m | 22 | -0.073 | 0.122 | -0.60 | 4.97 | 8.0 | 4.97 | no |
| baseline: momentum_6m | 22 | -0.098 | 0.144 | -0.68 | 3.29 | 8.0 | 3.29 | no |
| baseline: reversal_3m | 22 | 0.073 | 0.122 | 0.60 | 4.97 | 8.0 | 4.97 | no |
| baseline: zero | 22 | 0.000 | 0.000 | n/a | 22.00 | 8.0 | 8.00 | no |
| ridge - momentum_3m (paired) | 22 | 0.084 | 0.108 | 0.78 | 8.32 | 8.0 | 8.00 | no |
| ridge, embargo=0m | 22 | 0.011 | 0.145 | 0.08 | 5.01 | 8.0 | 5.01 | no |
| ridge, embargo=1m | 21 | -0.020 | 0.129 | -0.16 | 5.44 | 7.0 | 5.44 | no |
| oracle (unattainable ceiling) | 22 | 1.000 | 0.000 | n/a | 22.00 | 8.0 | 8.00 | yes |

**Verdict at H=3: no signal (does not clear its own one-SE error bar).**

Fold-wise label permutation (2000 draws): observed mean IC 0.011 against a null centred on 0.001 with SD 0.023; two-sided p = 0.634. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.270, n_eff 5.47, clears both gates: yes). The fitted model scores 0.011, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 6 months

16 purged folds, 2025-02-01..2026-05-01; median cross-section 86.0 products.

*Purge audit* (summed over folds): 6559 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 1250 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 16 | -0.122 | 0.117 | -1.04 | 3.70 | 3.0 | 3.00 | no |
| ridge / static-ablated | 16 | -0.018 | 0.110 | -0.17 | 4.33 | 3.0 | 3.00 | no |
| ridge / momentum-only | 16 | -0.089 | 0.122 | -0.73 | 5.49 | 3.0 | 3.00 | no |
| ridge / book-ablated | 16 | -0.169 | 0.122 | -1.38 | 3.56 | 3.0 | 3.00 | no |
| baseline: age | 16 | 0.096 | 0.223 | 0.43 | 1.91 | 3.0 | 1.91 | no |
| baseline: cheap | 16 | -0.108 | 0.453 | -0.24 | 1.00 | 3.0 | 1.00 | no |
| baseline: momentum_3m | 16 | -0.185 | 0.136 | -1.37 | 4.52 | 3.0 | 3.00 | no |
| baseline: momentum_6m | 16 | -0.123 | 0.104 | -1.18 | 3.63 | 3.0 | 3.00 | no |
| baseline: reversal_3m | 16 | 0.185 | 0.136 | 1.37 | 4.52 | 3.0 | 3.00 | no |
| baseline: zero | 16 | 0.000 | 0.000 | n/a | 16.00 | 3.0 | 3.00 | no |
| ridge - momentum_3m (paired) | 16 | 0.063 | 0.228 | 0.28 | 2.37 | 3.0 | 2.37 | no |
| ridge, embargo=0m | 16 | -0.122 | 0.117 | -1.04 | 3.70 | 3.0 | 3.00 | no |
| ridge, embargo=1m | 15 | -0.128 | 0.133 | -0.96 | 3.27 | 3.0 | 3.00 | no |
| oracle (unattainable ceiling) | 16 | 1.000 | 0.000 | n/a | 16.00 | 3.0 | 3.00 | no |

**Verdict at H=6: clears the one-SE bar but on n_eff 3.00 < 4.0 -- INSUFFICIENT EVIDENCE.**

Fold-wise label permutation (2000 draws): observed mean IC -0.122 against a null centred on -0.000 with SD 0.027; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `mid_skew` (mean IC 0.270, n_eff 3.00, clears both gates: no). The fitted model scores -0.122, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

### Horizon H = 12 months

4 purged folds, 2025-08-01..2025-11-01; median cross-section 86.0 products.

*Purge audit* (summed over folds): 3390 training rows whose label window overlapped the test window's interior were EXCLUDED, 0 slipped through (must be 0), 284 boundary rows sharing only the already-observed test-month price were kept.

| scorer | folds | mean IC | SE | t | n_eff (autocorr) | bound (structural) | n_eff used | clears both gates? |
|---|---|---|---|---|---|---|---|---|
| **ridge (pre-registered)** | 4 | -0.314 | 0.225 | -1.39 | 1.00 | 1.0 | 1.00 | no |
| ridge / static-ablated | 4 | -0.105 | 0.186 | -0.57 | 2.55 | 1.0 | 1.00 | no |
| ridge / momentum-only | 4 | -0.170 | 0.242 | -0.70 | 1.88 | 1.0 | 1.00 | no |
| ridge / book-ablated | 4 | -0.396 | 0.188 | -2.11 | 1.00 | 1.0 | 1.00 | no |
| baseline: age | 4 | 0.286 | 0.142 | 2.01 | 1.05 | 1.0 | 1.00 | no |
| baseline: cheap | 4 | 0.032 | 0.117 | 0.27 | 1.00 | 1.0 | 1.00 | no |
| baseline: momentum_3m | 4 | -0.140 | 0.269 | -0.52 | 1.00 | 1.0 | 1.00 | no |
| baseline: momentum_6m | 4 | -0.046 | 0.056 | -0.81 | 4.00 | 1.0 | 1.00 | no |
| baseline: reversal_3m | 4 | 0.140 | 0.269 | 0.52 | 1.00 | 1.0 | 1.00 | no |
| baseline: zero | 4 | 0.000 | 0.000 | n/a | 4.00 | 1.0 | 1.00 | no |
| ridge - momentum_3m (paired) | 4 | -0.174 | 0.064 | -2.70 | 4.00 | 1.0 | 1.00 | no |
| ridge, embargo=0m | 4 | -0.314 | 0.225 | -1.39 | 1.00 | 1.0 | 1.00 | no |
| ridge, embargo=1m | 3 | -0.430 | 0.083 | -5.17 | 3.00 | 1.0 | 1.00 | no |
| oracle (unattainable ceiling) | 4 | 1.000 | 0.000 | n/a | 4.00 | 1.0 | 1.00 | no |

**Verdict at H=12: clears the one-SE bar but on n_eff 1.00 < 4.0 -- INSUFFICIENT EVIDENCE.**

Fold-wise label permutation (2000 draws): observed mean IC -0.314 against a null centred on -0.000 with SD 0.055; two-sided p = 0.000. The permutation null cannot see fold overlap, so it is a floor on the evidence, never a substitute for the structural n_eff bound above.

Best SINGLE feature at this horizon: `months_since_release` (mean IC 0.286, n_eff 1.00, clears both gates: no). The fitted model scores -0.314, i.e. it does WORSE than its own strongest single input -- the signature of fitting more parameters than this panel can pay for.

## The strongest feature is a measurement artefact, not a forecast

`mid_skew` = (mid - market) / market is the best single predictor in this panel at H = 1, 3, 6 (not everywhere: H = 12 `rel_spread`). It has two rival readings, and they disagree about what the listing book does NEXT: if sellers are holding out because demand is real, the book should keep rising; if TCGplayer's trailing `market` average simply has not caught up, the two series should converge. The test is direct.

| H | mid_skew -> forward MARKET return | -> forward change in BOOK MID | -> change in the gap | signature |
|---|---|---|---|---|
| 1 | 0.265 (t 4.57) | -0.233 (t -4.67) | -0.435 (t -16.06) | CONVERGENCE |
| 3 | 0.270 (t 3.05) | -0.285 (t -5.99) | -0.537 (t -12.15) | CONVERGENCE |
| 6 | 0.270 (t 3.06) | -0.321 (t -4.72) | -0.628 (t -9.30) | CONVERGENCE |
| 12 | 0.072 (t 0.44) | -0.349 (t -4.36) | -0.667 (t -7.13) | CONVERGENCE |

Every horizon shows the same pattern: a high `mid_skew` predicts the traded price RISING and the listing midpoint FALLING, with the gap between them closing hard. That is two measurements of the same thing meeting in the middle -- an artefact of `market` being a trailing transaction-weighted average while `mid` is a current quote -- not a forecast that a box is worth more. Half the convergence is the book coming DOWN, so a holder does not capture the full move, and none of it is realisable at the price the index records.

The same defect has a second edge. Because `market` is a trailing transaction-weighted average, a monthly change in it is a change in a SMOOTHED series, and smoothing induces positive autocorrelation in measured returns even when the underlying price is a random walk -- the appraisal-smoothing problem familiar from illiquid asset indices. That is exactly where the second-strongest one-month feature lives: `mom_1m` scores a mean IC of 0.231 at H=1 (n_eff 22.22) and fades at longer horizons. Short-horizon 'momentum' in this panel should therefore be read as a property of the price SERIES, not of the market, until a non-smoothed quote can confirm it -- and no such quote exists in the permitted sources.

## Against the only benchmark that matters: buy the whole basket

A rank correlation is not money. This is the same walk-forward, turned into an equal-weight top-5th portfolio rebalanced every H months and differenced against holding every ETB in the panel. `cost drag` is 15% round-trip (the conservative end of the bid-ask + fees range the data audit found on thin sealed listings) applied at every rebalance, 12/H times a year; buy-and-hold pays it once and amortises it to roughly nothing.

Read the `zero` row first: it scores every product identically, so its 'top quintile' is an ARBITRARY fifth of the basket. Whatever edge it shows is pure partition noise, and it is the floor any real scorer has to clear.

| H | scorer | top-quintile %/yr | basket %/yr | gross edge | cost drag | net edge | t | n_eff | beats buy-and-hold? |
|---|---|---|---|---|---|---|---|---|---|
| 1 | ridge | 152.1 | 88.1 | +64.0pp | -85.8pp | -21.8pp | 2.72 | 14.69 | YES |
| 1 | age | 87.1 | 88.1 | -1.0pp | -85.8pp | -86.8pp | -0.02 | 5.01 | no |
| 1 | cheap | 95.9 | 88.1 | +7.7pp | -85.8pp | -78.0pp | 0.33 | 10.93 | no |
| 1 | momentum_3m | 106.2 | 88.1 | +18.0pp | -85.8pp | -67.7pp | 0.78 | 10.11 | no |
| 1 | momentum_6m | 93.6 | 88.1 | +5.4pp | -85.8pp | -80.4pp | 0.19 | 6.66 | no |
| 1 | reversal_3m | 62.4 | 88.1 | -25.8pp | -85.8pp | -111.6pp | -1.57 | 11.92 | no |
| 1 | zero | 81.1 | 88.1 | -7.0pp | -85.8pp | -92.8pp | -0.23 | 8.06 | no |
| 1 | oracle | 641.2 | 88.1 | +553.0pp | -85.8pp | +467.3pp | 13.97 | 13.46 | YES |
| 3 | ridge | 92.8 | 96.9 | -4.1pp | -47.8pp | -51.9pp | -0.17 | 7.10 | no |
| 3 | age | 100.1 | 96.9 | +3.2pp | -47.8pp | -44.6pp | 0.04 | 2.12 | no |
| 3 | cheap | 109.2 | 96.9 | +12.3pp | -47.8pp | -35.5pp | 0.26 | 1.87 | no |
| 3 | momentum_3m | 80.7 | 96.9 | -16.2pp | -47.8pp | -64.0pp | -0.65 | 3.65 | no |
| 3 | momentum_6m | 79.1 | 96.9 | -17.8pp | -47.8pp | -65.6pp | -0.59 | 2.72 | no |
| 3 | reversal_3m | 108.9 | 96.9 | +12.1pp | -47.8pp | -35.7pp | 0.49 | 6.53 | no |
| 3 | zero | 85.3 | 96.9 | -11.6pp | -47.8pp | -59.4pp | -0.30 | 3.11 | no |
| 3 | oracle | 368.1 | 96.9 | +271.2pp | -47.8pp | +223.4pp | 14.19 | 6.71 | YES |
| 6 | ridge | 72.9 | 81.6 | -8.7pp | -27.8pp | -36.4pp | -0.56 | 3.00 | no |
| 6 | age | 109.7 | 81.6 | +28.1pp | -27.8pp | +0.4pp | 0.77 | 1.66 | no |
| 6 | cheap | 80.9 | 81.6 | -0.7pp | -27.8pp | -28.4pp | -0.01 | 1.00 | no |
| 6 | momentum_3m | 66.4 | 81.6 | -15.2pp | -27.8pp | -43.0pp | -0.67 | 2.34 | no |
| 6 | momentum_6m | 73.0 | 81.6 | -8.6pp | -27.8pp | -36.3pp | -0.44 | 2.25 | no |
| 6 | reversal_3m | 105.4 | 81.6 | +23.8pp | -27.8pp | -4.0pp | 1.40 | 3.00 | no |
| 6 | zero | 63.9 | 81.6 | -17.7pp | -27.8pp | -45.4pp | -0.63 | 1.70 | no |
| 6 | oracle | 206.8 | 81.6 | +125.2pp | -27.8pp | +97.5pp | 12.02 | 3.00 | no |
| 12 | ridge | 26.9 | 50.3 | -23.5pp | -15.0pp | -38.5pp | -1.45 | 1.00 | no |
| 12 | age | 73.5 | 50.3 | +23.1pp | -15.0pp | +8.1pp | 2.99 | 1.00 | no |
| 12 | cheap | 66.8 | 50.3 | +16.4pp | -15.0pp | +1.4pp | 1.63 | 1.00 | no |
| 12 | momentum_3m | 45.3 | 50.3 | -5.0pp | -15.0pp | -20.0pp | -0.48 | 1.00 | no |
| 12 | momentum_6m | 50.0 | 50.3 | -0.3pp | -15.0pp | -15.3pp | -0.07 | 1.00 | no |
| 12 | reversal_3m | 56.0 | 50.3 | +5.6pp | -15.0pp | -9.4pp | 0.37 | 1.00 | no |
| 12 | zero | 34.2 | 50.3 | -16.1pp | -15.0pp | -31.1pp | -2.86 | 1.00 | no |
| 12 | oracle | 101.0 | 50.3 | +50.6pp | -15.0pp | +35.6pp | 18.42 | 1.00 | no |

The model's portfolio beats buy-and-hold GROSS at H = 1 months. Net of the rebalancing cost it beats buy-and-hold at NO horizon. A gross-only edge is not a reason to trade; it is a reason to distrust the gross number.

## The selection protocol (reported, never the headline)

The headline model is PRE-REGISTERED (`ridge`), so every fold above is held out and no selection step touched them. For completeness the full candidate roster was also run through choose-on-selection-folds / score-on-evaluation-folds:

- selection folds: 8 (2025-02-01..2025-09-01)
- evaluation folds: 8 (2025-10-01..2026-05-01)
- selection-fold ranking: rank_linear -0.166; huber -0.166; gbm -0.168; rf -0.170; ridge -0.185; elasticnet -0.209; ensemble -0.212; pls -0.245
- winner `rank_linear` scores -0.046 on the evaluation folds (n_eff 2.00): no signal, and n_eff 2.00 is too thin to have found one

**This split is NOT clean and the number above is contaminated.** With an H=6 label window, the last selection fold's outcome is still being realised during the first 5 evaluation folds, and there are not enough months on this archive to buy that gap back and still have folds on both sides. Stating it is the only available remedy; it is also why the headline does not come from here.

## What would change this answer

- **More history.** The binding constraint is the number of non-overlapping forward windows, and that grows only with calendar time. tcgcsv's archive starts 2024-03; eBay and PriceCharting are excluded on terms-of-service grounds, so there is no legitimate way to extend it backwards.
- **A regime change.** Every fold here is a boom month. A signal that works only in a boom is not distinguishable from no signal until a bust supplies the contrast.
- **A tradeable price.** Even where the model's portfolio beats buy-and-hold gross (H = 1), it does not survive a realistic round-trip cost. Any future version of this study should report net, not gross, or it is measuring the wrong thing.

