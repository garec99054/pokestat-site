# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-09-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6319 |
| coverage_target | 0.80 |
| q_lo | -1.2865 |
| q_hi | 1.3605 |
| band_width | 2.6470 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 50 |
| n_fair | 403 |
| n_undervalued | 50 |
| persistence_rho | 0.9757 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 121.9127 |
| forward_spread_pt | 1.05 |
| spike_pct | 10.3 |
| drop_pct | -19.6 |
| snapshot | 2026-09-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.632**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.287, 1.360]** (width 2.647),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **403**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **85.7%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (72): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.81, fair $20.01, hier $12.31)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $196.14, fair $30.28, hier $101.71)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.69, fair $6.93, hier $4.80)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $955.08, fair $148.17, hier $264.42)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $146.04, fair $14.81, hier $52.15)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $186.93, fair $40.32, hier $93.38)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $75.20, fair $15.09, hier $39.16)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $143.27, fair $14.00, hier $66.74)
- me55-152 Mew ex: OLS overvalued vs hier fair (market $177.80, fair $36.36, hier $79.24)
- me55-155 Jirachi ex: OLS overvalued vs hier fair (market $71.07, fair $15.46, hier $39.35)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.66, fair $11.23, hier $10.05)
- sv1-243 Spidops ex: OLS overvalued vs hier fair (market $8.80, fair $1.75, hier $2.14)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $4.85, fair $18.30, hier $9.35)
- sv10-209 Ethan's Ho-Oh ex: OLS undervalued vs hier fair (market $5.37, fair $19.85, hier $9.99)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.15, fair $4.62, hier $2.83)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.66, fair $18.81, hier $9.90)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $20.03, fair $3.38, hier $5.02)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $6.23, fair $1.56, hier $2.17)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $113.66, fair $23.91, hier $31.27)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $74.50, fair $17.69, hier $24.08)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.82, fair $7.04, hier $5.29)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $26.12, fair $5.19, hier $6.19)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.62, fair $2.15, hier $7.96)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.62, fair $1.23, hier $5.05)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.96, fair $2.78, hier $10.10)
- sv5-191 Iron Crown ex: OLS undervalued vs hier fair (market $1.75, fair $6.34, hier $4.08)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $36.88, fair $8.11, hier $15.94)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.63, fair $1.11, hier $1.62)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $37.46, fair $6.58, hier $18.92)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.31, fair $14.45, hier $8.16)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.20, fair $8.97, hier $5.48)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.96, fair $8.42, hier $4.97)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $39.88, fair $6.47, hier $9.39)
- sv8-241 Archaludon ex: OLS overvalued vs hier fair (market $12.73, fair $2.85, hier $4.55)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $17.89, fair $3.24, hier $5.76)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $3.47, fair $13.09, hier $6.93)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $28.27, fair $10.18, hier $5.66)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.90, fair $25.28, hier $12.12)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.29, fair $9.91, hier $5.54)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.98, fair $12.15, hier $6.37)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $62.15, fair $22.13, hier $10.81)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $16.09, fair $105.15, hier $65.72)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.91, fair $30.85, hier $23.81)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.47, fair $40.27, hier $28.22)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $17.14, fair $83.18, hier $53.68)
- swsh11-172 Hisuian Electrode V: OLS undervalued vs hier fair (market $2.19, fair $8.50, hier $4.59)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.72, fair $10.75, hier $5.73)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $31.00, fair $12.98, hier $6.80)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.39, fair $10.32, hier $5.50)
- swsh11-179 Aerodactyl V: OLS undervalued vs hier fair (market $2.63, fair $10.00, hier $5.38)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.85, fair $7.63, hier $4.23)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.40, fair $38.57, hier $28.11)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.37, fair $205.02, hier $119.00)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.55, fair $32.33, hier $14.38)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.60, fair $12.82, hier $6.67)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.55, fair $28.17, hier $13.32)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.60, fair $36.16, hier $16.25)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $23.62, fair $147.99, hier $76.91)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.46, fair $61.36, hier $37.14)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $39.78, fair $283.56, hier $137.15)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $49.25, fair $10.87, hier $14.83)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $151.29, fair $41.64, hier $28.32)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.97, fair $13.75, hier $10.84)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $240.65, fair $68.70, hier $45.96)
- swsh7-187 Lycanroc V: OLS undervalued vs hier fair (market $4.08, fair $14.83, hier $11.84)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.44, fair $9.42, hier $8.08)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.20, fair $169.74, hier $164.35)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $48.18, fair $214.19, hier $196.53)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.83, fair $162.84, hier $160.26)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $110.84, fair $457.12, hier $397.44)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.34, fair $10.21, hier $8.06)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.24, fair $9.00, hier $7.32)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 121.91** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 4/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+1.1pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+10.3pt**, DROP (20th pctile) = **-19.6pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (6):
- sv4pt5-244 Ting-Lu ex: 3m +14.3pt, market $5.62
- sv8-236 Durant ex: 3m +19.9pt, market $39.88
- swsh10-161 Beedrill V: 3m +12.8pt, market $77.27
- swsh7-182 Golurk V: 3m +25.1pt, market $36.90
- swsh7-194 Rayquaza V: 3m +19.1pt, market $490.35
- swsh7-215 Umbreon VMAX: 3m +12.4pt, market $2283.14
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -37.6pt, market $1.95
- sv10-215 Cynthia's Garchomp ex: 3m -26.4pt, market $4.66
- sv8-218 Black Kyurem ex: 3m -25.2pt, market $2.20

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.9pt (t_eff -1.82, null), 3m -6.4pt (t_eff -1.74, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +1.1pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +1.1pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
