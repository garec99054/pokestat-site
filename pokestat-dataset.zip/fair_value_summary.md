# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-10-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6473 |
| coverage_target | 0.80 |
| q_lo | -1.2533 |
| q_hi | 1.3629 |
| band_width | 2.6162 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7952 |
| n_overvalued | 50 |
| n_fair | 405 |
| n_undervalued | 48 |
| persistence_rho | 0.9758 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.2416 |
| forward_spread_pt | 0.92 |
| spike_pct | 3.3 |
| drop_pct | -26.8 |
| snapshot | 2026-10-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.647**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.253, 1.363]** (width 2.616),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.795** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **405**, undervalued: **48**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.1%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (70): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.56, fair $17.59, hier $11.96)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $164.07, fair $31.37, hier $93.26)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.47, fair $6.59, hier $4.68)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $689.42, fair $137.49, hier $220.35)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $120.66, fair $13.73, hier $43.23)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $138.56, fair $34.21, hier $72.27)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $60.02, fair $13.57, hier $31.55)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $134.99, fair $13.11, hier $51.38)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.45, fair $9.88, hier $9.80)
- sv1-230 Great Tusk ex: OLS undervalued vs hier fair (market $1.00, fair $3.66, hier $3.90)
- sv1-231 Koraidon ex: OLS undervalued vs hier fair (market $1.90, fair $6.94, hier $7.05)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $12.46, fair $3.13, hier $3.61)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.13, fair $4.04, hier $2.37)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.00, fair $16.31, hier $8.71)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $2.84, fair $13.54, hier $7.06)
- sv10-219 Team Rocket's Persian ex: OLS undervalued vs hier fair (market $3.33, fair $12.76, hier $6.82)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $15.26, fair $3.62, hier $4.53)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $5.48, fair $1.26, hier $1.84)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $89.11, fair $20.39, hier $28.47)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $317.64, fair $60.52, hier $74.96)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $82.44, fair $20.62, hier $28.61)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.68, fair $6.28, hier $5.01)
- sv4-230 Aegislash ex: OLS undervalued vs hier fair (market $1.81, fair $6.38, hier $5.12)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $25.73, fair $5.20, hier $6.05)
- sv4-248 Iron Hands ex: OLS overvalued vs hier fair (market $11.97, fair $2.85, hier $3.52)
- sv4pt5-240 Wo-Chien ex: OLS overvalued vs hier fair (market $6.52, fair $1.43, hier $5.45)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.20, fair $2.22, hier $8.12)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.75, fair $1.21, hier $4.71)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.25, fair $2.81, hier $9.91)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $34.68, fair $8.10, hier $15.67)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.20, fair $1.06, hier $1.57)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $37.93, fair $6.57, hier $17.70)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $1.93, fair $11.85, hier $6.78)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $1.94, fair $7.96, hier $4.80)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.51, fair $7.09, hier $4.34)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $14.46, fair $2.64, hier $4.39)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $26.82, fair $9.73, hier $5.40)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.81, fair $23.11, hier $12.18)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.18, fair $9.22, hier $5.29)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.57, fair $10.85, hier $6.05)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $61.61, fair $20.36, hier $10.61)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.29, fair $88.81, hier $60.24)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.96, fair $29.03, hier $22.18)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.32, fair $30.45, hier $23.31)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.91, fair $36.31, hier $26.49)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.44, fair $76.91, hier $52.63)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.76, fair $10.19, hier $5.87)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.42, fair $10.70, hier $6.31)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $8.99, fair $36.18, hier $27.85)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.72, fair $184.24, hier $122.42)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.74, fair $29.78, hier $14.61)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.36, fair $10.80, hier $5.84)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.51, fair $24.54, hier $12.45)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $25.60, fair $7.93, hier $4.42)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.28, fair $32.41, hier $15.64)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $24.36, fair $133.90, hier $75.64)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.69, fair $55.51, hier $34.93)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.63, fair $240.94, hier $128.72)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $38.74, fair $9.06, hier $11.18)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $140.70, fair $39.50, hier $29.44)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.42, fair $38.91, hier $29.52)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $3.01, fair $13.22, hier $11.05)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $238.19, fair $61.35, hier $44.76)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.34, fair $8.51, hier $7.52)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.71, fair $162.23, hier $167.60)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $46.64, fair $191.42, hier $189.85)
- swsh7-210 Dracozolt VMAX: OLS fair vs hier undervalued (market $7.48, fair $25.24, hier $31.64)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $109.07, fair $415.42, hier $389.26)
- swsh7-218 Rayquaza VMAX: OLS overvalued vs hier fair (market $1267.32, fair $316.08, hier $302.81)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.20, fair $9.54, hier $8.08)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.24** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.9pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.3pt**, DROP (20th pctile) = **-26.8pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (3):
- sv4-248 Iron Hands ex: 3m +5.2pt, market $11.97
- sv7-160 Dachsbun ex: 3m +17.7pt, market $4.20
- swsh7-218 Rayquaza VMAX: 3m +12.9pt, market $1267.32
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -41.3pt, market $1.77
- sv1-227 Miraidon ex: 3m -36.5pt, market $2.45
- sv10-212 Electivire ex: 3m -33.1pt, market $1.13

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.5pt (t_eff -1.46, null), 3m -6.4pt (t_eff -1.79, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.9pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.9pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.795) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
