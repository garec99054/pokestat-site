# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-09-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6377 |
| coverage_target | 0.80 |
| q_lo | -1.2517 |
| q_hi | 1.3499 |
| band_width | 2.6016 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 49 |
| n_fair | 405 |
| n_undervalued | 49 |
| persistence_rho | 0.9758 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.2416 |
| forward_spread_pt | 0.92 |
| spike_pct | 10.3 |
| drop_pct | -19.6 |
| snapshot | 2026-09-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.638**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.252, 1.350]** (width 2.602),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **49**, fair: **405**, undervalued: **49**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.1%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (70): a first-class signal, not an error.

- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $192.13, fair $31.75, hier $100.38)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.49, fair $6.56, hier $4.65)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $936.56, fair $146.99, hier $256.00)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $151.33, fair $14.11, hier $45.55)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $165.78, fair $37.20, hier $79.72)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $69.77, fair $14.02, hier $33.93)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $146.52, fair $13.60, hier $57.97)
- me55-152 Mew ex: OLS overvalued vs hier fair (market $149.26, fair $36.50, hier $70.03)
- me55-155 Jirachi ex: OLS overvalued vs hier fair (market $79.23, fair $15.89, hier $33.87)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.28, fair $10.31, hier $9.60)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $11.49, fair $2.73, hier $3.09)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $4.42, fair $16.89, hier $8.68)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.12, fair $4.30, hier $2.62)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $3.94, fair $17.79, hier $9.39)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $3.59, fair $13.72, hier $7.23)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $18.44, fair $3.61, hier $4.97)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $5.50, fair $1.34, hier $1.94)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $98.59, fair $22.87, hier $30.53)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $353.06, fair $68.96, hier $80.14)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $68.14, fair $16.97, hier $23.22)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.31, fair $2.28, hier $8.18)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.90, fair $1.24, hier $4.78)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.51, fair $2.65, hier $9.41)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $35.91, fair $8.06, hier $15.48)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $5.07, fair $1.03, hier $1.51)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $38.95, fair $6.93, hier $19.26)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.31, fair $14.28, hier $8.10)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $1.99, fair $8.69, hier $5.27)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.90, fair $8.81, hier $5.17)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $17.31, fair $3.24, hier $5.64)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $3.61, fair $13.24, hier $6.83)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $27.65, fair $10.34, hier $5.57)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $6.08, fair $24.89, hier $12.03)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.50, fair $10.04, hier $5.54)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.81, fair $13.73, hier $6.91)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $63.21, fair $21.67, hier $10.64)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.84, fair $101.28, hier $63.03)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.94, fair $31.59, hier $23.31)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.39, fair $31.23, hier $22.71)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.39, fair $45.95, hier $30.75)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.83, fair $82.06, hier $52.15)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.57, fair $10.03, hier $5.49)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $30.68, fair $12.08, hier $6.76)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.38, fair $10.41, hier $5.71)
- swsh11-179 Aerodactyl V: OLS undervalued vs hier fair (market $2.82, fair $10.12, hier $5.61)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.74, fair $6.69, hier $3.85)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.57, fair $38.73, hier $28.82)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.76, fair $199.16, hier $123.12)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.29, fair $31.59, hier $14.40)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.24, fair $11.81, hier $6.27)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.40, fair $25.44, hier $12.42)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $26.75, fair $7.39, hier $4.11)
- swsh12-185 Lugia V: OLS undervalued vs hier fair (market $16.86, fair $60.09, hier $26.59)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.64, fair $32.23, hier $15.18)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $24.36, fair $147.16, hier $79.24)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.12, fair $60.61, hier $36.70)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.87, fair $271.08, hier $138.17)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $46.30, fair $10.07, hier $12.90)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $148.60, fair $40.66, hier $28.24)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.51, fair $37.09, hier $26.52)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.87, fair $13.30, hier $10.59)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $238.80, fair $66.77, hier $46.32)
- swsh7-187 Lycanroc V: OLS undervalued vs hier fair (market $3.98, fair $14.84, hier $11.84)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.40, fair $10.54, hier $8.93)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $42.94, fair $167.24, hier $164.64)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $47.69, fair $214.68, hier $194.49)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.19, fair $161.07, hier $160.57)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $108.89, fair $444.98, hier $396.32)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.52, fair $10.13, hier $8.23)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.35, fair $8.97, hier $7.59)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.24** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.9pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+10.3pt**, DROP (20th pctile) = **-19.6pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (7):
- sv1-246 Great Tusk ex: 3m +19.4pt, market $11.49
- sv4pt5-244 Ting-Lu ex: 3m +14.3pt, market $5.90
- sv8-236 Durant ex: 3m +19.9pt, market $40.08
- swsh10-161 Beedrill V: 3m +12.8pt, market $75.63
- swsh7-182 Golurk V: 3m +25.1pt, market $36.53
- swsh7-194 Rayquaza V: 3m +19.1pt, market $488.29
- swsh7-215 Umbreon VMAX: 3m +12.4pt, market $2283.90
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -37.6pt, market $1.76
- sv10-215 Cynthia's Garchomp ex: 3m -26.4pt, market $3.94
- sv8-218 Black Kyurem ex: 3m -25.2pt, market $1.99

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.9pt (t_eff -1.78, null), 3m -6.4pt (t_eff -1.75, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.9pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.9pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
