# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-10-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6408 |
| coverage_target | 0.80 |
| q_lo | -1.2765 |
| q_hi | 1.3316 |
| band_width | 2.6082 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 50 |
| n_fair | 405 |
| n_undervalued | 48 |
| persistence_rho | 0.9758 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.2416 |
| forward_spread_pt | 0.92 |
| spike_pct | 3.3 |
| drop_pct | -26.8 |
| snapshot | 2026-10-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.641**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.277, 1.332]** (width 2.608),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **405**, undervalued: **48**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **85.7%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (72): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.76, fair $18.17, hier $12.16)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $181.91, fair $32.59, hier $97.07)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.78, fair $6.65, hier $4.81)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $885.95, fair $142.96, hier $244.19)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $131.42, fair $13.53, hier $44.07)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $160.63, fair $37.80, hier $76.62)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $64.69, fair $13.54, hier $31.10)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $146.10, fair $14.61, hier $57.04)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.28, fair $9.46, hier $9.39)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $11.95, fair $2.79, hier $3.22)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $4.07, fair $15.70, hier $8.16)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.16, fair $4.19, hier $2.56)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.27, fair $17.80, hier $9.62)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $3.49, fair $13.80, hier $7.45)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $16.46, fair $3.91, hier $5.16)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $92.31, fair $21.59, hier $30.09)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $336.78, fair $63.05, hier $77.70)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $68.65, fair $16.18, hier $23.23)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $83.55, fair $21.09, hier $29.63)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $26.67, fair $5.18, hier $6.18)
- sv4pt5-240 Wo-Chien ex: OLS overvalued vs hier fair (market $6.85, fair $1.73, hier $6.22)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.29, fair $2.37, hier $8.43)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.82, fair $1.28, hier $4.82)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.59, fair $2.79, hier $9.73)
- sv5-188 Gouging Fire ex: OLS undervalued vs hier fair (market $2.41, fair $8.84, hier $5.90)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $35.11, fair $8.18, hier $15.34)
- sv6pt5-95 Pecharunt ex: OLS fair vs hier undervalued (market $21.53, fair $37.82, hier $103.26)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.89, fair $1.07, hier $1.58)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $36.82, fair $6.88, hier $18.62)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $1.98, fair $13.13, hier $7.57)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.17, fair $8.33, hier $5.16)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.89, fair $7.86, hier $4.86)
- sv8pt5-161 Umbreon ex: OLS overvalued vs hier fair (market $1323.45, fair $339.38, hier $398.25)
- sv8pt5-163 Pecharunt ex: OLS fair vs hier undervalued (market $28.50, fair $93.79, hier $125.71)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $16.16, fair $3.08, hier $5.21)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $3.76, fair $13.77, hier $7.20)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $27.52, fair $10.82, hier $5.73)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $6.37, fair $24.31, hier $12.04)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.53, fair $10.59, hier $5.69)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.87, fair $13.45, hier $7.01)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $62.60, fair $20.98, hier $10.36)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $16.11, fair $97.53, hier $62.53)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $8.00, fair $33.23, hier $24.05)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.27, fair $31.95, hier $23.49)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.96, fair $44.81, hier $31.02)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.56, fair $78.89, hier $51.60)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.53, fair $9.99, hier $5.63)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $30.12, fair $11.98, hier $6.76)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.42, fair $10.96, hier $6.19)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.82, fair $6.73, hier $3.94)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.51, fair $37.75, hier $27.99)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.90, fair $187.98, hier $119.96)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.83, fair $30.12, hier $14.54)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.26, fair $12.27, hier $6.53)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.60, fair $24.45, hier $12.42)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $26.54, fair $7.78, hier $4.34)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.67, fair $32.52, hier $15.59)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $24.62, fair $138.08, hier $76.68)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.58, fair $58.65, hier $36.71)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $39.16, fair $252.85, hier $132.31)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $41.53, fair $9.47, hier $11.57)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $146.30, fair $41.08, hier $29.63)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.62, fair $35.09, hier $26.09)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.86, fair $13.52, hier $10.95)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $238.74, fair $64.12, hier $44.99)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.43, fair $9.64, hier $8.16)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $42.94, fair $167.86, hier $165.27)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $47.65, fair $204.09, hier $194.09)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.31, fair $154.61, hier $155.45)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $108.54, fair $427.31, hier $384.37)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.41, fair $10.25, hier $8.77)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.31, fair $8.65, hier $7.53)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.24** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.9pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.3pt**, DROP (20th pctile) = **-26.8pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (2):
- sv7-160 Dachsbun ex: 3m +17.7pt, market $4.89
- swsh7-218 Rayquaza VMAX: 3m +12.9pt, market $1268.66
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -41.3pt, market $1.90
- sv1-227 Miraidon ex: 3m -36.5pt, market $2.28
- sv10-212 Electivire ex: 3m -33.1pt, market $1.16

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.5pt (t_eff -1.46, null), 3m -6.4pt (t_eff -1.79, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.9pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.9pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
