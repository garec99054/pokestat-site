# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-10-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6473 |
| coverage_target | 0.80 |
| q_lo | -1.2190 |
| q_hi | 1.3159 |
| band_width | 2.5349 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 50 |
| n_fair | 403 |
| n_undervalued | 50 |
| persistence_rho | 0.9759 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.3069 |
| forward_spread_pt | 0.85 |
| spike_pct | 3.3 |
| drop_pct | -26.8 |
| snapshot | 2026-10-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.647**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.219, 1.316]** (width 2.535),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **403**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.1%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (70): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.97, fair $17.09, hier $11.70)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $157.78, fair $29.47, hier $80.29)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.60, fair $6.38, hier $4.71)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $639.71, fair $132.29, hier $202.87)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $115.05, fair $12.71, hier $38.73)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $144.41, fair $35.04, hier $68.36)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $56.51, fair $14.57, hier $31.60)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $127.70, fair $13.38, hier $47.76)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.60, fair $10.12, hier $10.02)
- sv1-231 Koraidon ex: OLS undervalued vs hier fair (market $2.05, fair $7.03, hier $7.11)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $3.82, fair $15.53, hier $7.88)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.15, fair $4.23, hier $2.47)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $3.90, fair $16.92, hier $8.86)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $2.84, fair $12.26, hier $6.47)
- sv10-219 Team Rocket's Persian ex: OLS undervalued vs hier fair (market $3.60, fair $12.71, hier $6.74)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $14.39, fair $3.71, hier $4.48)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $5.57, fair $1.41, hier $1.95)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $88.66, fair $20.32, hier $28.75)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $295.70, fair $60.27, hier $75.74)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $78.99, fair $20.14, hier $28.43)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.59, fair $6.04, hier $4.83)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $24.62, fair $5.22, hier $6.03)
- sv4-248 Iron Hands ex: OLS overvalued vs hier fair (market $12.28, fair $2.97, hier $3.60)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.30, fair $2.23, hier $7.65)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.71, fair $1.29, hier $4.65)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.27, fair $2.86, hier $9.68)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $33.80, fair $7.93, hier $15.61)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.15, fair $1.10, hier $1.61)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $37.66, fair $6.40, hier $16.46)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.44, fair $12.54, hier $7.83)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.79, fair $7.07, hier $4.67)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $34.88, fair $6.50, hier $8.78)
- sv8pt5-161 Umbreon ex: OLS overvalued vs hier fair (market $1205.47, fair $313.92, hier $368.08)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $13.94, fair $2.76, hier $4.35)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $26.81, fair $10.85, hier $6.13)
- swsh10-166 Starmie V: OLS undervalued vs hier fair (market $3.85, fair $13.62, hier $7.74)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.70, fair $22.55, hier $12.09)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.16, fair $9.50, hier $5.59)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.63, fair $11.57, hier $6.57)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $61.37, fair $19.37, hier $10.46)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.29, fair $83.86, hier $58.13)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.80, fair $29.42, hier $22.70)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.29, fair $29.40, hier $22.71)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.92, fair $38.05, hier $27.79)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.59, fair $71.85, hier $50.38)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.51, fair $9.47, hier $5.54)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.43, fair $10.25, hier $6.05)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.03, fair $35.57, hier $27.24)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.21, fair $30.05, hier $14.50)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.27, fair $10.91, hier $5.89)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.37, fair $22.50, hier $11.47)
- swsh12-183 Regidrago V: OLS undervalued vs hier fair (market $2.26, fair $7.66, hier $4.23)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $24.15, fair $7.43, hier $4.12)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $7.83, fair $32.33, hier $15.32)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $23.80, fair $129.22, hier $71.81)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.85, fair $53.78, hier $33.23)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.87, fair $234.42, hier $123.04)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $37.63, fair $9.19, hier $10.84)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $139.75, fair $39.42, hier $30.27)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.13, fair $32.65, hier $25.92)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $3.11, fair $12.79, hier $10.90)
- swsh7-187 Lycanroc V: OLS undervalued vs hier fair (market $3.96, fair $13.76, hier $11.60)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.34, fair $8.45, hier $7.62)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.28, fair $158.73, hier $165.24)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $46.49, fair $184.51, hier $186.09)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $37.18, fair $144.02, hier $151.78)
- swsh7-209 Glaceon VMAX: OLS overvalued vs hier fair (market $305.76, fair $76.49, hier $84.75)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $107.46, fair $391.39, hier $371.05)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.22, fair $9.17, hier $7.88)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.23, fair $7.95, hier $6.93)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.31** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 5/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.8pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.3pt**, DROP (20th pctile) = **-26.8pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (3):
- sv4-248 Iron Hands ex: 3m +5.2pt, market $12.28
- sv7-160 Dachsbun ex: 3m +17.7pt, market $4.15
- swsh7-218 Rayquaza VMAX: 3m +12.9pt, market $1241.76
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -41.3pt, market $1.73
- sv1-227 Miraidon ex: 3m -36.5pt, market $2.60
- sv10-212 Electivire ex: 3m -33.1pt, market $1.15

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.5pt (t_eff -1.46, null), 3m -6.4pt (t_eff -1.79, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.8pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.8pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
