# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-10-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6436 |
| coverage_target | 0.80 |
| q_lo | -1.2269 |
| q_hi | 1.3466 |
| band_width | 2.5735 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7952 |
| n_overvalued | 49 |
| n_fair | 404 |
| n_undervalued | 50 |
| persistence_rho | 0.9758 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.2416 |
| forward_spread_pt | 0.92 |
| spike_pct | 3.3 |
| drop_pct | -26.8 |
| snapshot | 2026-10-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.644**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.227, 1.347]** (width 2.574),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.795** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **49**, fair: **404**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.1%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (70): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.94, fair $17.52, hier $11.49)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $176.31, fair $30.99, hier $91.31)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.85, fair $6.50, hier $4.78)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $810.72, fair $140.75, hier $233.93)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $127.40, fair $13.18, hier $43.75)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $145.81, fair $36.90, hier $76.94)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $62.71, fair $13.48, hier $31.47)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $137.88, fair $14.05, hier $55.78)
- me55-155 Jirachi ex: OLS overvalued vs hier fair (market $49.86, fair $12.87, hier $21.32)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.33, fair $9.30, hier $9.35)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $12.46, fair $2.84, hier $3.34)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.07, fair $4.11, hier $2.47)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.16, fair $17.47, hier $9.38)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $3.01, fair $13.43, hier $7.19)
- sv10-219 Team Rocket's Persian ex: OLS undervalued vs hier fair (market $3.42, fair $13.52, hier $7.24)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $15.79, fair $3.61, hier $4.81)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $91.56, fair $21.33, hier $29.75)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $322.94, fair $63.29, hier $78.46)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $83.13, fair $21.30, hier $29.91)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.68, fair $6.35, hier $5.06)
- sv4-230 Aegislash ex: OLS undervalued vs hier fair (market $1.71, fair $6.26, hier $5.12)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $26.94, fair $5.25, hier $6.23)
- sv4pt5-240 Wo-Chien ex: OLS overvalued vs hier fair (market $6.67, fair $1.64, hier $6.06)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.10, fair $2.10, hier $7.65)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.53, fair $1.16, hier $4.45)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.57, fair $2.63, hier $9.34)
- sv5-189 Walking Wake ex: OLS undervalued vs hier fair (market $1.58, fair $5.39, hier $3.67)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $34.62, fair $8.20, hier $15.81)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.22, fair $0.95, hier $1.47)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $37.68, fair $6.12, hier $16.96)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.22, fair $13.49, hier $7.74)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.05, fair $8.05, hier $4.93)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.88, fair $7.83, hier $4.81)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $14.54, fair $2.99, hier $5.00)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $27.53, fair $10.06, hier $5.43)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $6.27, fair $24.15, hier $11.96)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.31, fair $10.38, hier $5.71)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.70, fair $12.54, hier $6.67)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $62.22, fair $20.36, hier $10.20)
- swsh10-178 Garchomp V: OLS undervalued vs hier fair (market $10.13, fair $35.25, hier $16.87)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.79, fair $96.96, hier $63.11)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.99, fair $32.72, hier $24.08)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.14, fair $32.06, hier $23.69)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $9.00, fair $41.99, hier $29.47)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.47, fair $77.02, hier $51.47)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.50, fair $9.91, hier $5.57)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.51, fair $11.02, hier $6.28)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.42, fair $36.54, hier $27.75)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.72, fair $186.45, hier $120.88)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.90, fair $30.31, hier $14.71)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.34, fair $11.78, hier $6.38)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.55, fair $24.13, hier $12.30)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $26.12, fair $7.55, hier $4.26)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.46, fair $32.61, hier $15.70)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $24.39, fair $134.28, hier $76.28)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.44, fair $57.51, hier $36.14)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.89, fair $242.78, hier $131.02)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $41.12, fair $9.30, hier $11.33)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $145.51, fair $40.35, hier $29.60)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.62, fair $37.07, hier $27.62)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.86, fair $13.06, hier $10.61)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $239.71, fair $63.13, hier $44.59)
- swsh7-187 Lycanroc V: OLS undervalued vs hier fair (market $3.98, fair $13.97, hier $11.30)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.43, fair $9.97, hier $8.48)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $42.83, fair $165.91, hier $167.11)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.75, fair $153.35, hier $158.31)
- swsh7-210 Dracozolt VMAX: OLS fair vs hier undervalued (market $7.72, fair $25.84, hier $32.13)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $108.54, fair $424.96, hier $387.93)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.27, fair $9.95, hier $8.49)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.29, fair $8.51, hier $7.36)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.24** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.9pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.3pt**, DROP (20th pctile) = **-26.8pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (2):
- sv7-160 Dachsbun ex: 3m +17.7pt, market $4.22
- swsh7-218 Rayquaza VMAX: 3m +12.9pt, market $1268.52
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -41.3pt, market $1.83
- sv1-227 Miraidon ex: 3m -36.5pt, market $2.33
- sv10-212 Electivire ex: 3m -33.1pt, market $1.07

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.5pt (t_eff -1.46, null), 3m -6.4pt (t_eff -1.79, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.9pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.9pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.795) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
