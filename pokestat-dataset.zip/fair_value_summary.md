# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-10-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6467 |
| coverage_target | 0.80 |
| q_lo | -1.2300 |
| q_hi | 1.3605 |
| band_width | 2.5905 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 49 |
| n_fair | 404 |
| n_undervalued | 50 |
| persistence_rho | 0.9758 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.2416 |
| forward_spread_pt | 0.92 |
| spike_pct | 3.3 |
| drop_pct | -26.8 |
| snapshot | 2026-10-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.647**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.230, 1.361]** (width 2.590),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **49**, fair: **404**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.5%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (68): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.80, fair $17.67, hier $11.61)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $168.86, fair $31.52, hier $88.09)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.55, fair $6.63, hier $4.77)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $740.19, fair $138.42, hier $226.15)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $121.10, fair $13.04, hier $39.88)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $137.11, fair $34.57, hier $71.31)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $61.70, fair $13.38, hier $30.31)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $135.53, fair $13.25, hier $51.00)
- sv1-231 Koraidon ex: OLS undervalued vs hier fair (market $1.97, fair $6.77, hier $6.77)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $12.34, fair $2.71, hier $3.11)
- sv10-209 Ethan's Ho-Oh ex: OLS undervalued vs hier fair (market $5.20, fair $17.85, hier $9.16)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.12, fair $4.06, hier $2.38)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.12, fair $16.71, hier $8.80)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $2.67, fair $13.39, hier $6.96)
- sv10-219 Team Rocket's Persian ex: OLS undervalued vs hier fair (market $3.41, fair $13.06, hier $6.92)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $15.01, fair $3.72, hier $4.66)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $92.57, fair $20.45, hier $28.92)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $325.39, fair $61.60, hier $77.70)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $82.77, fair $20.77, hier $29.41)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.74, fair $6.43, hier $5.02)
- sv4-230 Aegislash ex: OLS undervalued vs hier fair (market $1.70, fair $6.33, hier $5.05)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $25.72, fair $5.33, hier $6.16)
- sv4pt5-240 Wo-Chien ex: OLS overvalued vs hier fair (market $6.62, fair $1.48, hier $5.48)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.03, fair $2.31, hier $8.22)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.65, fair $1.21, hier $4.54)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.35, fair $2.74, hier $9.60)
- sv6-189 Sinistcha ex: OLS undervalued vs hier fair (market $1.50, fair $5.16, hier $3.33)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $34.40, fair $8.11, hier $15.81)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.43, fair $0.95, hier $1.48)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $37.87, fair $6.48, hier $17.92)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.11, fair $12.45, hier $7.23)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $1.90, fair $7.95, hier $4.89)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.68, fair $7.60, hier $4.69)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $14.50, fair $2.80, hier $4.72)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $26.90, fair $9.87, hier $5.49)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $6.02, fair $23.70, hier $12.41)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.38, fair $9.31, hier $5.30)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.71, fair $12.13, hier $6.65)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $62.93, fair $19.91, hier $10.34)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.59, fair $94.47, hier $63.94)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.99, fair $29.31, hier $22.51)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.34, fair $30.96, hier $23.68)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.94, fair $40.59, hier $29.48)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.36, fair $75.22, hier $51.71)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.45, fair $10.04, hier $5.80)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.51, fair $10.37, hier $6.09)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $8.99, fair $36.14, hier $27.97)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.72, fair $182.37, hier $120.91)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.92, fair $30.25, hier $15.11)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.40, fair $11.39, hier $6.29)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.43, fair $23.53, hier $12.22)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $25.85, fair $7.82, hier $4.43)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.42, fair $33.68, hier $16.36)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $24.15, fair $133.08, hier $77.11)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.64, fair $56.25, hier $35.85)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.70, fair $238.44, hier $130.04)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $39.97, fair $9.12, hier $11.03)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $143.22, fair $39.89, hier $29.51)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.55, fair $37.17, hier $28.13)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $3.03, fair $13.37, hier $11.04)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.39, fair $9.79, hier $8.47)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.71, fair $163.86, hier $168.36)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $46.98, fair $194.03, hier $190.30)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.55, fair $150.19, hier $156.46)
- swsh7-210 Dracozolt VMAX: OLS fair vs hier undervalued (market $7.64, fair $25.87, hier $31.87)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $108.38, fair $414.19, hier $381.52)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.29, fair $9.65, hier $8.23)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.29, fair $8.25, hier $7.20)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.24** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.9pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.3pt**, DROP (20th pctile) = **-26.8pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (2):
- sv7-160 Dachsbun ex: 3m +17.7pt, market $4.43
- swsh7-218 Rayquaza VMAX: 3m +12.9pt, market $1268.52
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -41.3pt, market $1.77
- sv1-227 Miraidon ex: 3m -36.5pt, market $2.37
- sv10-212 Electivire ex: 3m -33.1pt, market $1.12

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.5pt (t_eff -1.46, null), 3m -6.4pt (t_eff -1.79, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.9pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.9pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
