# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-10-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6446 |
| coverage_target | 0.80 |
| q_lo | -1.2435 |
| q_hi | 1.3466 |
| band_width | 2.5901 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7952 |
| n_overvalued | 49 |
| n_fair | 404 |
| n_undervalued | 50 |
| persistence_rho | 0.9759 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.3069 |
| forward_spread_pt | 0.85 |
| spike_pct | 3.3 |
| drop_pct | -26.8 |
| snapshot | 2026-10-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.645**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.244, 1.347]** (width 2.590),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.795** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **49**, fair: **404**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.3%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (69): a first-class signal, not an error.

- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $160.22, fair $31.45, hier $89.63)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.59, fair $6.59, hier $4.65)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $671.17, fair $133.42, hier $210.22)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $115.58, fair $12.80, hier $39.82)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $140.50, fair $33.64, hier $69.51)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $59.19, fair $13.81, hier $31.51)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $134.86, fair $12.93, hier $50.48)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.58, fair $9.89, hier $9.72)
- sv1-230 Great Tusk ex: OLS undervalued vs hier fair (market $1.04, fair $3.76, hier $4.04)
- sv1-231 Koraidon ex: OLS undervalued vs hier fair (market $1.93, fair $7.08, hier $7.17)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $4.28, fair $15.59, hier $7.88)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.29, fair $4.50, hier $2.61)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $3.75, fair $16.76, hier $8.82)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $2.69, fair $13.40, hier $7.08)
- sv10-219 Team Rocket's Persian ex: OLS undervalued vs hier fair (market $3.41, fair $13.10, hier $6.93)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $15.19, fair $3.62, hier $4.58)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $5.58, fair $1.34, hier $1.95)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $90.22, fair $20.57, hier $29.51)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $309.65, fair $60.40, hier $76.84)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $83.27, fair $20.20, hier $28.99)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.70, fair $6.24, hier $4.77)
- sv4-248 Iron Hands ex: OLS overvalued vs hier fair (market $12.06, fair $3.12, hier $3.73)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.32, fair $2.19, hier $7.80)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.52, fair $1.19, hier $4.53)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.38, fair $2.88, hier $9.88)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $33.99, fair $8.01, hier $15.53)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.16, fair $1.07, hier $1.60)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $37.35, fair $6.45, hier $17.73)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.05, fair $12.68, hier $7.41)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.17, fair $7.99, hier $4.96)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.57, fair $6.92, hier $4.37)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $13.69, fair $2.83, hier $4.63)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $26.93, fair $10.16, hier $5.57)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.86, fair $23.34, hier $12.10)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.09, fair $9.88, hier $5.57)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.58, fair $11.15, hier $6.16)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $61.43, fair $20.00, hier $10.42)
- swsh10-180 Wyrdeer V: OLS undervalued vs hier fair (market $2.08, fair $7.27, hier $4.17)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.29, fair $85.73, hier $58.39)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.89, fair $30.83, hier $23.31)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.29, fair $29.06, hier $22.37)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.92, fair $36.94, hier $26.86)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.41, fair $74.80, hier $51.02)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.56, fair $10.00, hier $5.71)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.39, fair $10.89, hier $6.28)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.91, fair $7.04, hier $4.18)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.03, fair $35.81, hier $27.10)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $27.93, fair $180.80, hier $117.11)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.89, fair $31.66, hier $15.18)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.35, fair $11.26, hier $6.05)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.49, fair $22.91, hier $11.66)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $24.76, fair $7.58, hier $4.23)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.22, fair $31.59, hier $15.07)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $24.36, fair $133.64, hier $74.50)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $11.00, fair $55.34, hier $34.59)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.56, fair $237.05, hier $125.95)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $39.97, fair $9.02, hier $11.23)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $140.70, fair $38.95, hier $29.55)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.56, fair $35.25, hier $27.45)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $3.08, fair $13.51, hier $11.32)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.31, fair $8.65, hier $7.73)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.68, fair $158.19, hier $162.57)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $46.49, fair $188.88, hier $189.55)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.79, fair $148.21, hier $157.81)
- swsh7-209 Glaceon VMAX: OLS overvalued vs hier fair (market $307.37, fair $78.63, hier $88.06)
- swsh7-210 Dracozolt VMAX: OLS fair vs hier undervalued (market $7.70, fair $25.93, hier $32.70)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $109.07, fair $408.28, hier $383.42)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.24, fair $9.41, hier $8.02)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.27, fair $7.91, hier $6.86)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.31** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 5/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.8pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.3pt**, DROP (20th pctile) = **-26.8pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (3):
- sv4-248 Iron Hands ex: 3m +5.2pt, market $12.06
- sv7-160 Dachsbun ex: 3m +17.7pt, market $4.16
- swsh7-218 Rayquaza VMAX: 3m +12.9pt, market $1267.32
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -41.3pt, market $1.65
- sv1-227 Miraidon ex: 3m -36.5pt, market $2.58
- sv10-212 Electivire ex: 3m -33.1pt, market $1.29

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.5pt (t_eff -1.46, null), 3m -6.4pt (t_eff -1.79, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.8pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.8pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.795) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
