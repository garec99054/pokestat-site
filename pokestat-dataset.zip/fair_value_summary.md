# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot (the same universe `model_results.csv` uses); trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-09-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 491 |
| n_excluded | 0 |
| loocv_r2 | 0.6274 |
| coverage_target | 0.80 |
| q_lo | -1.2770 |
| q_hi | 1.3340 |
| band_width | 2.6111 |
| coverage_naive | 0.8004 |
| coverage_loo | 0.7963 |
| n_overvalued | 49 |
| n_fair | 394 |
| n_undervalued | 48 |
| persistence_rho | 0.9757 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 121.9256 |
| forward_spread_pt | 1.04 |
| spike_pct | 10.3 |
| drop_pct | -19.6 |
| snapshot | 2026-09-01 |

## Universe

- Modeled cards (complete desirability): **491**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.627**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.277, 1.334]** (width 2.611),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.800** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.796** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **49**, fair: **394**, undervalued: **48**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 491 cards present in both): **85.3%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (72): a first-class signal, not an error.

- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $196.51, fair $33.03, hier $100.91)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.58, fair $6.33, hier $5.16)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $957.30, fair $181.83, hier $330.29)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $161.20, fair $17.50, hier $59.61)
- me5-103 Mega Excadrill ex: OLS overvalued vs hier fair (market $7.22, fair $1.61, hier $3.36)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $195.75, fair $37.66, hier $94.07)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $83.52, fair $15.78, hier $44.90)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $153.51, fair $15.13, hier $72.10)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.92, fair $10.81, hier $10.99)
- sv1-231 Koraidon ex: OLS undervalued vs hier fair (market $2.05, fair $8.23, hier $8.28)
- sv1-243 Spidops ex: OLS overvalued vs hier fair (market $9.65, fair $1.86, hier $2.36)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $13.95, fair $2.68, hier $3.19)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.59, fair $18.07, hier $10.42)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $20.74, fair $3.87, hier $5.41)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $119.02, fair $20.47, hier $31.40)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $74.50, fair $16.14, hier $25.52)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $97.29, fair $20.63, hier $31.35)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $25.97, fair $5.66, hier $6.49)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.89, fair $2.11, hier $7.50)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $6.78, fair $1.31, hier $4.85)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $13.35, fair $3.43, hier $11.79)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $38.56, fair $7.92, hier $15.53)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.82, fair $1.13, hier $1.58)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $36.59, fair $7.65, hier $19.55)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.50, fair $13.64, hier $8.04)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.08, fair $8.60, hier $5.30)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.86, fair $9.06, hier $5.70)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $38.56, fair $7.32, hier $9.62)
- sv8pt5-161 Umbreon ex: OLS overvalued vs hier fair (market $1423.30, fair $332.02, hier $391.49)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $19.60, fair $3.41, hier $5.80)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $3.61, fair $13.18, hier $6.86)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $28.17, fair $10.40, hier $5.69)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.94, fair $24.78, hier $11.72)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.05, fair $10.27, hier $5.37)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $3.15, fair $12.30, hier $6.27)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $63.27, fair $22.58, hier $11.29)
- swsh10-178 Garchomp V: OLS undervalued vs hier fair (market $10.00, fair $36.71, hier $17.17)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $16.01, fair $102.11, hier $67.20)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.82, fair $32.04, hier $24.00)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.45, fair $40.69, hier $28.88)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $17.97, fair $84.12, hier $55.48)
- swsh11-172 Hisuian Electrode V: OLS undervalued vs hier fair (market $2.25, fair $8.75, hier $4.58)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.49, fair $11.58, hier $5.77)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $31.49, fair $13.84, hier $7.04)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.41, fair $11.29, hier $5.88)
- swsh11-179 Aerodactyl V: OLS undervalued vs hier fair (market $2.80, fair $10.38, hier $5.23)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $2.08, fair $7.73, hier $4.13)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.02, fair $39.17, hier $27.74)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.66, fair $190.07, hier $113.80)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.24, fair $30.99, hier $14.50)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.75, fair $13.52, hier $6.82)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.38, fair $27.03, hier $13.28)
- swsh12-183 Regidrago V: OLS undervalued vs hier fair (market $2.35, fair $8.43, hier $4.35)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $28.36, fair $8.19, hier $4.31)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.33, fair $31.64, hier $14.97)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $24.55, fair $147.06, hier $78.71)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.63, fair $59.57, hier $35.73)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $40.21, fair $253.38, hier $128.44)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $48.81, fair $11.91, hier $14.94)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $151.56, fair $41.18, hier $28.57)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.21, fair $36.13, hier $25.67)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $3.18, fair $14.47, hier $11.35)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $240.97, fair $64.59, hier $43.63)
- swsh7-187 Lycanroc V: OLS undervalued vs hier fair (market $4.05, fair $15.35, hier $11.65)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.41, fair $10.54, hier $8.58)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.78, fair $166.71, hier $159.55)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $48.05, fair $207.22, hier $196.03)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $37.03, fair $159.66, hier $157.18)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $115.68, fair $424.52, hier $383.38)
- swsh7-218 Rayquaza VMAX: OLS overvalued vs hier fair (market $1255.33, fair $325.17, hier $286.28)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.21, fair $9.69, hier $7.62)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.01, fair $8.82, hier $7.01)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 121.93** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (22):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv8pt5-161 Umbreon ex: in tail 4/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 4/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+1.0pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+10.3pt**, DROP (20th pctile) = **-19.6pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (8):
- sv1-246 Great Tusk ex: 3m +19.4pt, market $13.95
- sv4pt5-244 Ting-Lu ex: 3m +14.3pt, market $6.78
- sv8-236 Durant ex: 3m +19.9pt, market $38.56
- swsh10-161 Beedrill V: 3m +12.8pt, market $78.33
- swsh7-182 Golurk V: 3m +25.1pt, market $38.11
- swsh7-194 Rayquaza V: 3m +19.1pt, market $495.70
- swsh7-215 Umbreon VMAX: 3m +12.4pt, market $2368.34
- swsh7-218 Rayquaza VMAX: 3m +24.5pt, market $1255.33
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -37.6pt, market $2.03
- sv10-215 Cynthia's Garchomp ex: 3m -26.4pt, market $4.59
- sv8-218 Black Kyurem ex: 3m -25.2pt, market $2.08

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.9pt (t_eff -1.82, null), 3m -6.4pt (t_eff -1.74, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +1.0pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +1.0pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.796) is the trustworthy interval coverage;
  the naive number (0.800) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  491 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card `model_results.csv`/`hier_results.csv` vintage is superseded by this
  refresh.

Full per-card table: `fair_value.csv` (same directory).
