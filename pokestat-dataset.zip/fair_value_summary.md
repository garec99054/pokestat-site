# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-09-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6330 |
| coverage_target | 0.80 |
| q_lo | -1.2878 |
| q_hi | 1.3546 |
| band_width | 2.6424 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 49 |
| n_fair | 405 |
| n_undervalued | 49 |
| persistence_rho | 0.9757 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 121.8197 |
| forward_spread_pt | 1.11 |
| spike_pct | 10.3 |
| drop_pct | -19.6 |
| snapshot | 2026-09-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.633**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.288, 1.355]** (width 2.642),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **49**, fair: **405**, undervalued: **49**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **85.5%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (73): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.72, fair $19.66, hier $12.08)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $196.14, fair $30.32, hier $101.10)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.61, fair $6.97, hier $4.72)
- me2-114 Empoleon ex: OLS undervalued vs hier fair (market $1.25, fair $4.92, hier $3.51)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $952.70, fair $147.71, hier $270.43)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $146.04, fair $15.12, hier $54.71)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $185.46, fair $40.66, hier $91.20)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $73.28, fair $14.22, hier $36.22)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $145.88, fair $14.29, hier $65.50)
- me55-152 Mew ex: OLS overvalued vs hier fair (market $161.71, fair $35.85, hier $76.83)
- me55-155 Jirachi ex: OLS overvalued vs hier fair (market $70.33, fair $15.26, hier $38.39)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.66, fair $10.97, hier $10.10)
- sv1-243 Spidops ex: OLS overvalued vs hier fair (market $8.82, fair $1.71, hier $2.10)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $4.74, fair $18.04, hier $9.30)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.02, fair $4.48, hier $2.77)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.48, fair $18.59, hier $9.82)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $19.36, fair $3.39, hier $5.02)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $6.28, fair $1.55, hier $2.16)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $112.17, fair $23.80, hier $31.22)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $354.65, fair $74.02, hier $83.20)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $73.74, fair $17.76, hier $24.37)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.81, fair $6.89, hier $5.16)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $26.20, fair $5.10, hier $6.11)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.62, fair $2.23, hier $8.23)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.66, fair $1.25, hier $5.07)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.97, fair $2.64, hier $9.74)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $36.62, fair $8.22, hier $16.69)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.35, fair $1.07, hier $1.53)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $38.61, fair $7.07, hier $20.19)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.31, fair $14.59, hier $8.27)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.15, fair $8.81, hier $5.34)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.97, fair $8.87, hier $5.24)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $40.20, fair $6.58, hier $9.55)
- sv8-241 Archaludon ex: OLS overvalued vs hier fair (market $12.66, fair $2.82, hier $4.59)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $17.73, fair $3.29, hier $5.77)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $3.56, fair $13.46, hier $7.10)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $27.75, fair $10.48, hier $5.77)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.92, fair $25.19, hier $12.39)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.31, fair $9.70, hier $5.49)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.98, fair $12.28, hier $6.52)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $62.15, fair $22.15, hier $10.94)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $16.09, fair $101.74, hier $65.13)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.91, fair $30.24, hier $23.05)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.47, fair $40.71, hier $28.82)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $17.14, fair $83.27, hier $53.47)
- swsh11-172 Hisuian Electrode V: OLS undervalued vs hier fair (market $2.19, fair $8.48, hier $4.62)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.76, fair $10.54, hier $5.56)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $31.00, fair $12.72, hier $6.90)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.36, fair $10.87, hier $5.75)
- swsh11-179 Aerodactyl V: OLS undervalued vs hier fair (market $2.64, fair $10.03, hier $5.44)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.85, fair $7.45, hier $4.13)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.40, fair $38.13, hier $28.00)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.37, fair $204.02, hier $119.81)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.60, fair $30.94, hier $14.00)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.49, fair $12.97, hier $6.85)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.58, fair $28.11, hier $13.30)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $27.37, fair $7.19, hier $3.97)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.60, fair $34.54, hier $15.84)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $23.73, fair $147.00, hier $77.11)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.34, fair $61.34, hier $37.88)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $39.78, fair $280.51, hier $137.97)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $48.92, fair $10.71, hier $14.31)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $151.29, fair $41.44, hier $28.56)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.97, fair $13.85, hier $10.88)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $240.03, fair $69.39, hier $47.84)
- swsh7-187 Lycanroc V: OLS undervalued vs hier fair (market $4.07, fair $14.98, hier $12.06)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.41, fair $9.70, hier $8.32)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.20, fair $169.00, hier $166.67)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.83, fair $161.81, hier $159.95)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $110.84, fair $453.57, hier $394.87)
- swsh7-218 Rayquaza VMAX: OLS fair vs hier overvalued (market $1255.44, fair $342.33, hier $298.34)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.49, fair $10.22, hier $8.30)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.28, fair $8.71, hier $7.27)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 121.82** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 4/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+1.1pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+10.3pt**, DROP (20th pctile) = **-19.6pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (6):
- sv4pt5-244 Ting-Lu ex: 3m +14.3pt, market $5.66
- sv8-236 Durant ex: 3m +19.9pt, market $40.20
- swsh10-161 Beedrill V: 3m +12.8pt, market $77.27
- swsh7-182 Golurk V: 3m +25.1pt, market $36.90
- swsh7-194 Rayquaza V: 3m +19.1pt, market $490.35
- swsh7-215 Umbreon VMAX: 3m +12.4pt, market $2283.14
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (4):
- me2-114 Empoleon ex: 3m -33.6pt, market $1.25
- me2pt5-251 Sprigatito ex: 3m -37.6pt, market $1.93
- sv10-215 Cynthia's Garchomp ex: 3m -26.4pt, market $4.48
- sv8-218 Black Kyurem ex: 3m -25.2pt, market $2.15

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.9pt (t_eff -1.82, null), 3m -6.4pt (t_eff -1.74, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +1.1pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +1.1pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
