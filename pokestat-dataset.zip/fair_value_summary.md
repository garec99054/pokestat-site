# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-10-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6401 |
| coverage_target | 0.80 |
| q_lo | -1.2673 |
| q_hi | 1.3456 |
| band_width | 2.6129 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 50 |
| n_fair | 403 |
| n_undervalued | 50 |
| persistence_rho | 0.9758 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.2416 |
| forward_spread_pt | 0.92 |
| spike_pct | 3.3 |
| drop_pct | -26.8 |
| snapshot | 2026-10-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.640**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.267, 1.346]** (width 2.613),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **403**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **85.7%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (72): a first-class signal, not an error.

- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $184.51, fair $32.41, hier $96.67)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.58, fair $6.71, hier $4.73)
- me2-114 Empoleon ex: OLS undervalued vs hier fair (market $1.31, fair $4.85, hier $3.61)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $926.12, fair $143.76, hier $247.27)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $130.97, fair $13.35, hier $44.96)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $162.48, fair $37.04, hier $76.02)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $68.95, fair $14.03, hier $32.23)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $146.84, fair $14.34, hier $56.00)
- me55-155 Jirachi ex: OLS overvalued vs hier fair (market $53.53, fair $13.77, hier $22.62)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.27, fair $10.04, hier $9.84)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $11.65, fair $2.95, hier $3.35)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $4.29, fair $16.11, hier $8.53)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.54, fair $17.85, hier $9.68)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $3.75, fair $13.48, hier $7.30)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $16.97, fair $3.81, hier $5.11)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $93.26, fair $21.55, hier $30.23)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $342.73, fair $63.26, hier $78.70)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $69.38, fair $16.28, hier $23.61)
- sv4-230 Aegislash ex: OLS undervalued vs hier fair (market $1.75, fair $6.26, hier $5.12)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $26.80, fair $5.55, hier $6.51)
- sv4pt5-240 Wo-Chien ex: OLS overvalued vs hier fair (market $6.93, fair $1.80, hier $6.43)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.31, fair $2.38, hier $8.28)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.95, fair $1.30, hier $4.89)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.83, fair $2.69, hier $9.38)
- sv5-188 Gouging Fire ex: OLS undervalued vs hier fair (market $2.48, fair $8.95, hier $5.95)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $35.11, fair $8.35, hier $15.52)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.88, fair $1.07, hier $1.59)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $36.46, fair $6.72, hier $18.34)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.01, fair $13.35, hier $7.72)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.19, fair $8.58, hier $5.25)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $2.01, fair $7.84, hier $4.81)
- sv8pt5-161 Umbreon ex: OLS overvalued vs hier fair (market $1326.66, fair $342.24, hier $411.31)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $17.01, fair $3.16, hier $5.46)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $3.77, fair $13.56, hier $7.01)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $27.52, fair $10.65, hier $5.66)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $6.39, fair $24.57, hier $12.05)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.53, fair $10.48, hier $5.69)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.84, fair $13.43, hier $6.99)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $62.85, fair $20.94, hier $10.40)
- swsh10-178 Garchomp V: OLS undervalued vs hier fair (market $10.05, fair $36.08, hier $16.95)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $16.11, fair $98.58, hier $63.71)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $8.00, fair $32.91, hier $23.94)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.30, fair $31.08, hier $22.84)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.96, fair $44.80, hier $30.76)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.56, fair $78.82, hier $51.60)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.50, fair $9.95, hier $5.47)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $30.42, fair $11.93, hier $6.62)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.40, fair $10.97, hier $6.15)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.74, fair $6.91, hier $4.00)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.61, fair $38.98, hier $28.38)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.90, fair $189.75, hier $117.86)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.83, fair $31.05, hier $14.96)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.18, fair $11.63, hier $6.23)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.67, fair $24.49, hier $12.33)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $26.54, fair $7.65, hier $4.27)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.66, fair $32.57, hier $15.38)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $24.62, fair $141.69, hier $78.98)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.58, fair $59.10, hier $36.56)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.00, fair $255.97, hier $134.53)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $43.15, fair $9.48, hier $11.48)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $146.99, fair $40.63, hier $29.23)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.62, fair $35.23, hier $26.10)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.87, fair $14.09, hier $11.21)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $239.00, fair $63.50, hier $44.22)
- swsh7-187 Lycanroc V: OLS undervalued vs hier fair (market $3.96, fair $14.56, hier $11.59)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.43, fair $9.73, hier $8.23)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $42.94, fair $166.19, hier $164.31)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.31, fair $154.49, hier $155.76)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $108.54, fair $429.13, hier $385.29)
- swsh7-218 Rayquaza VMAX: OLS overvalued vs hier fair (market $1256.64, fair $327.01, hier $304.03)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.62, fair $10.50, hier $8.92)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.31, fair $8.67, hier $7.59)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.24** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.9pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.3pt**, DROP (20th pctile) = **-26.8pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (2):
- sv7-160 Dachsbun ex: 3m +17.7pt, market $4.88
- swsh7-218 Rayquaza VMAX: 3m +12.9pt, market $1256.64
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2-114 Empoleon ex: 3m -30.2pt, market $1.31
- me2pt5-251 Sprigatito ex: 3m -41.3pt, market $1.87
- sv1-227 Miraidon ex: 3m -36.5pt, market $2.27

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.5pt (t_eff -1.46, null), 3m -6.4pt (t_eff -1.79, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.9pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.9pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
