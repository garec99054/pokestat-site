# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-09-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6339 |
| coverage_target | 0.80 |
| q_lo | -1.3012 |
| q_hi | 1.3619 |
| band_width | 2.6631 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 50 |
| n_fair | 405 |
| n_undervalued | 48 |
| persistence_rho | 0.9758 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.0223 |
| forward_spread_pt | 1.03 |
| spike_pct | 10.3 |
| drop_pct | -19.6 |
| snapshot | 2026-09-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.634**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.301, 1.362]** (width 2.663),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **405**, undervalued: **48**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.1%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (70): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.88, fair $19.50, hier $12.08)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $194.00, fair $30.86, hier $99.86)
- me2-114 Empoleon ex: OLS undervalued vs hier fair (market $1.29, fair $4.96, hier $3.58)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $944.57, fair $144.96, hier $253.34)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $144.99, fair $13.84, hier $51.03)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $176.78, fair $37.90, hier $86.36)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $70.67, fair $14.74, hier $37.29)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $147.21, fair $13.54, hier $61.37)
- me55-152 Mew ex: OLS overvalued vs hier fair (market $154.79, fair $37.86, hier $77.74)
- me55-155 Jirachi ex: OLS overvalued vs hier fair (market $117.70, fair $15.49, hier $36.40)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.39, fair $10.74, hier $10.06)
- sv1-243 Spidops ex: OLS overvalued vs hier fair (market $8.75, fair $1.59, hier $2.00)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $12.15, fair $2.77, hier $3.25)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $4.10, fair $17.94, hier $9.05)
- sv10-209 Ethan's Ho-Oh ex: OLS undervalued vs hier fair (market $5.01, fair $19.00, hier $9.35)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.12, fair $4.33, hier $2.59)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.09, fair $18.21, hier $9.26)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $3.86, fair $14.64, hier $7.58)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $18.22, fair $3.52, hier $4.90)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $5.80, fair $1.46, hier $2.05)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $104.94, fair $23.73, hier $31.04)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $346.31, fair $72.15, hier $82.05)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $71.43, fair $18.12, hier $24.68)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $8.98, fair $2.03, hier $7.49)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.94, fair $1.30, hier $5.06)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.56, fair $2.45, hier $8.89)
- sv6-192 Hearthflame Mask Ogerpon ex: OLS undervalued vs hier fair (market $2.23, fair $8.24, hier $4.91)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $36.68, fair $8.37, hier $15.94)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.52, fair $1.04, hier $1.53)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $39.56, fair $6.48, hier $18.54)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.41, fair $14.54, hier $8.36)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.11, fair $8.69, hier $5.29)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.91, fair $8.24, hier $4.90)
- sv8-241 Archaludon ex: OLS overvalued vs hier fair (market $12.45, fair $3.10, hier $4.89)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $17.34, fair $3.45, hier $5.83)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $3.60, fair $13.52, hier $7.10)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $27.66, fair $10.55, hier $5.77)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $6.01, fair $25.13, hier $12.32)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.47, fair $10.14, hier $5.66)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.86, fair $11.93, hier $6.28)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $62.69, fair $22.44, hier $10.94)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $16.17, fair $102.04, hier $63.99)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $8.07, fair $31.63, hier $23.82)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.45, fair $39.58, hier $27.82)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.65, fair $84.30, hier $55.07)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.68, fair $10.10, hier $5.49)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $30.77, fair $12.17, hier $6.73)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.39, fair $11.14, hier $6.17)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.74, fair $6.86, hier $3.93)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.49, fair $37.86, hier $27.83)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.76, fair $198.50, hier $121.08)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.36, fair $31.99, hier $14.73)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.37, fair $12.92, hier $6.92)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.50, fair $25.62, hier $12.58)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $26.93, fair $7.24, hier $4.08)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.71, fair $34.93, hier $15.91)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $23.80, fair $144.63, hier $77.53)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.03, fair $60.99, hier $37.50)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.89, fair $266.69, hier $136.50)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $47.30, fair $10.37, hier $13.41)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $150.69, fair $40.88, hier $27.81)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.56, fair $35.70, hier $25.39)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.89, fair $13.47, hier $10.51)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $239.22, fair $67.84, hier $46.29)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.41, fair $10.54, hier $8.96)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $42.94, fair $166.67, hier $164.73)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.52, fair $158.01, hier $156.58)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $108.89, fair $444.36, hier $392.13)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.51, fair $10.05, hier $8.05)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.32, fair $9.16, hier $7.59)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.02** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+1.0pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+10.3pt**, DROP (20th pctile) = **-19.6pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (7):
- sv1-246 Great Tusk ex: 3m +19.4pt, market $12.15
- sv4pt5-244 Ting-Lu ex: 3m +14.3pt, market $5.94
- sv8-236 Durant ex: 3m +19.9pt, market $40.20
- swsh10-161 Beedrill V: 3m +12.8pt, market $76.03
- swsh7-182 Golurk V: 3m +25.1pt, market $36.86
- swsh7-194 Rayquaza V: 3m +19.1pt, market $489.57
- swsh7-215 Umbreon VMAX: 3m +12.4pt, market $2214.79
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (4):
- me2-114 Empoleon ex: 3m -33.6pt, market $1.29
- me2pt5-251 Sprigatito ex: 3m -37.6pt, market $1.87
- sv10-215 Cynthia's Garchomp ex: 3m -26.4pt, market $4.09
- sv8-218 Black Kyurem ex: 3m -25.2pt, market $2.11

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.9pt (t_eff -1.82, null), 3m -6.4pt (t_eff -1.74, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +1.0pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +1.0pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
