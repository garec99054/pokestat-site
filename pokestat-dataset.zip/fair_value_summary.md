# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-11-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6494 |
| coverage_target | 0.80 |
| q_lo | -1.1602 |
| q_hi | 1.2981 |
| band_width | 2.4583 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 49 |
| n_fair | 405 |
| n_undervalued | 49 |
| persistence_rho | 0.9747 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 119.4465 |
| forward_spread_pt | 0.83 |
| spike_pct | 3.7 |
| drop_pct | -28.5 |
| snapshot | 2026-11-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.649**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.160, 1.298]** (width 2.458),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **49**, fair: **405**, undervalued: **49**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **87.1%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (65): a first-class signal, not an error.

- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $149.75, fair $29.80, hier $75.93)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $529.91, fair $121.62, hier $168.25)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $109.33, fair $13.09, hier $33.11)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $132.61, fair $30.77, hier $58.11)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $56.43, fair $13.50, hier $27.19)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $116.54, fair $12.71, hier $41.03)
- sv1-243 Spidops ex: OLS overvalued vs hier fair (market $8.26, fair $1.54, hier $1.99)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $3.49, fair $15.84, hier $8.19)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $0.99, fair $4.21, hier $2.45)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.04, fair $15.03, hier $8.11)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $2.68, fair $11.79, hier $6.38)
- sv10-219 Team Rocket's Persian ex: OLS undervalued vs hier fair (market $3.27, fair $11.59, hier $6.28)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $13.09, fair $3.40, hier $3.88)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $87.34, fair $17.95, hier $25.92)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.94, fair $7.88, hier $6.62)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $23.20, fair $5.19, hier $6.23)
- sv4pt5-240 Wo-Chien ex: OLS overvalued vs hier fair (market $7.30, fair $1.92, hier $7.07)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.55, fair $1.74, hier $6.46)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.47, fair $1.24, hier $4.75)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $13.26, fair $2.25, hier $8.20)
- sv6-189 Sinistcha ex: OLS undervalued vs hier fair (market $1.39, fair $5.52, hier $3.79)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $32.81, fair $8.81, hier $16.51)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $40.64, fair $6.49, hier $15.56)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.09, fair $10.58, hier $6.62)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.17, fair $7.56, hier $4.98)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.70, fair $7.16, hier $4.71)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $27.63, fair $6.17, hier $7.80)
- sv8pt5-161 Umbreon ex: OLS overvalued vs hier fair (market $1186.84, fair $279.78, hier $332.72)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $13.35, fair $2.41, hier $3.68)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $4.56, fair $14.71, hier $8.22)
- swsh10-166 Starmie V: OLS undervalued vs hier fair (market $3.75, fair $13.36, hier $7.65)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.60, fair $23.19, hier $12.60)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.08, fair $9.59, hier $5.63)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.63, fair $10.55, hier $6.11)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $59.26, fair $19.29, hier $10.53)
- swsh10-180 Wyrdeer V: OLS undervalued vs hier fair (market $2.06, fair $7.20, hier $4.26)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.04, fair $84.90, hier $58.81)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.80, fair $29.67, hier $22.68)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.19, fair $30.39, hier $23.05)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.85, fair $34.62, hier $25.44)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $15.66, fair $71.11, hier $49.88)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.51, fair $9.73, hier $5.92)
- swsh11-179 Aerodactyl V: OLS undervalued vs hier fair (market $2.59, fair $8.99, hier $5.54)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.80, fair $6.62, hier $4.20)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.01, fair $34.37, hier $26.89)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $25.46, fair $150.60, hier $104.77)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.89, fair $29.01, hier $14.05)
- swsh12-176 Unown V: OLS undervalued vs hier fair (market $3.84, fair $12.47, hier $6.39)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.54, fair $10.98, hier $5.82)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.19, fair $20.47, hier $10.41)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $21.81, fair $7.20, hier $3.97)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.56, fair $32.02, hier $15.31)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $22.47, fair $117.47, hier $65.84)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $11.20, fair $78.20, hier $45.86)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $39.65, fair $219.65, hier $117.18)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $34.34, fair $7.99, hier $9.55)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $134.98, fair $37.40, hier $30.87)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.88, fair $12.69, hier $11.45)
- swsh7-186 Medicham V: OLS overvalued vs hier fair (market $17.25, fair $4.37, hier $4.38)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.82, fair $149.76, hier $162.94)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.80, fair $135.94, hier $151.76)
- swsh7-209 Glaceon VMAX: OLS overvalued vs hier fair (market $287.34, fair $73.69, hier $85.36)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $101.16, fair $367.47, hier $369.37)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.37, fair $8.78, hier $7.56)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.33, fair $8.18, hier $7.11)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.975** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 119.45** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (20):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 4/5
- sv3pt5-199 Charizard ex: in tail 5/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 5/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 4/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-196 Kleavor VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 4/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-188 Pidgeot V: in tail 4/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-176 Unown V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 4/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 4/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.8pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.7pt**, DROP (20th pctile) = **-28.5pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (1):
- swsh7-196 Noivern V: 3m +4.4pt, market $78.04
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (1):
- sv10-216 Team Rocket's Nidoking ex: 3m -45.4pt, market $2.68

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.2pt (t_eff -1.18, null), 3m -5.8pt (t_eff -1.67, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.8pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.8pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
