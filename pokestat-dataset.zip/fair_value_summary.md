# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot (the same universe `model_results.csv` uses); trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-09-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 491 |
| n_excluded | 0 |
| loocv_r2 | 0.6302 |
| coverage_target | 0.80 |
| q_lo | -1.2812 |
| q_hi | 1.3436 |
| band_width | 2.6248 |
| coverage_naive | 0.8004 |
| coverage_loo | 0.7963 |
| n_overvalued | 49 |
| n_fair | 393 |
| n_undervalued | 49 |
| persistence_rho | 0.9757 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 121.9256 |
| forward_spread_pt | 1.04 |
| spike_pct | 10.3 |
| drop_pct | -19.6 |
| snapshot | 2026-09-01 |

## Universe

- Modeled cards (complete desirability): **491**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.630**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.281, 1.344]** (width 2.625),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.800** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.796** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **49**, fair: **393**, undervalued: **49**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 491 cards present in both): **85.3%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (72): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.79, fair $18.45, hier $12.84)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $199.66, fair $35.33, hier $108.62)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $1049.08, fair $186.56, hier $343.28)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $172.67, fair $18.01, hier $63.92)
- me5-103 Mega Excadrill ex: OLS overvalued vs hier fair (market $7.56, fair $1.68, hier $3.59)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $198.62, fair $38.04, hier $100.91)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $90.13, fair $15.51, hier $45.35)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $165.05, fair $15.39, hier $77.34)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.77, fair $10.13, hier $10.08)
- sv1-231 Koraidon ex: OLS undervalued vs hier fair (market $2.12, fair $7.93, hier $7.90)
- sv1-243 Spidops ex: OLS overvalued vs hier fair (market $9.27, fair $1.74, hier $2.21)
- sv1-246 Great Tusk ex: OLS overvalued vs hier fair (market $13.84, fair $3.06, hier $3.55)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.25, fair $4.93, hier $3.23)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.33, fair $17.74, hier $9.87)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $19.67, fair $3.99, hier $5.42)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $6.66, fair $1.63, hier $2.48)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $118.89, fair $20.41, hier $31.25)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $70.78, fair $16.57, hier $25.93)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $93.39, fair $20.78, hier $30.39)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $2.11, fair $7.80, hier $6.28)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $26.64, fair $6.09, hier $7.16)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $10.61, fair $2.73, hier $9.12)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $6.85, fair $1.61, hier $5.83)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $13.20, fair $3.31, hier $11.05)
- sv6-189 Sinistcha ex: OLS undervalued vs hier fair (market $1.80, fair $6.72, hier $4.14)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $38.98, fair $8.40, hier $15.90)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $37.34, fair $7.11, hier $18.21)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.40, fair $14.22, hier $8.28)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $1.99, fair $8.63, hier $5.27)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.95, fair $8.37, hier $5.28)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $38.96, fair $7.81, hier $10.47)
- sv8-241 Archaludon ex: OLS overvalued vs hier fair (market $12.85, fair $3.12, hier $4.63)
- sv8pt5-161 Umbreon ex: OLS overvalued vs hier fair (market $1451.94, fair $338.73, hier $393.42)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $20.34, fair $3.29, hier $6.08)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $28.01, fair $9.39, hier $5.13)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $6.30, fair $25.96, hier $11.66)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $1.98, fair $10.01, hier $5.24)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $3.12, fair $13.16, hier $6.58)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $65.35, fair $22.64, hier $11.24)
- swsh10-178 Garchomp V: OLS undervalued vs hier fair (market $9.35, fair $36.27, hier $16.75)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.88, fair $105.32, hier $67.16)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.73, fair $31.36, hier $23.39)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.29, fair $30.73, hier $22.16)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.72, fair $43.75, hier $30.49)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $19.12, fair $84.77, hier $55.65)
- swsh11-172 Hisuian Electrode V: OLS undervalued vs hier fair (market $2.38, fair $8.70, hier $4.49)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.57, fair $11.15, hier $5.59)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $31.40, fair $13.31, hier $6.87)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.71, fair $10.63, hier $5.53)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.89, fair $8.22, hier $4.42)
- swsh11-187 Hisuian Goodra V: OLS undervalued vs hier fair (market $2.62, fair $9.46, hier $4.77)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $8.55, fair $39.74, hier $27.97)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.77, fair $195.44, hier $113.57)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $6.66, fair $31.75, hier $14.46)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.85, fair $12.81, hier $6.32)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.47, fair $27.39, hier $13.05)
- swsh12-183 Regidrago V: OLS undervalued vs hier fair (market $2.37, fair $9.10, hier $4.53)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $29.14, fair $8.83, hier $4.49)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.15, fair $35.22, hier $15.81)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $25.42, fair $149.83, hier $80.78)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.93, fair $60.69, hier $35.67)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $42.23, fair $260.83, hier $130.15)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $51.15, fair $11.98, hier $14.55)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $152.92, fair $42.33, hier $29.08)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.19, fair $35.88, hier $25.66)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $3.26, fair $14.53, hier $11.48)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $239.42, fair $65.78, hier $44.57)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.32, fair $10.12, hier $8.41)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.68, fair $172.27, hier $165.07)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $49.13, fair $213.56, hier $203.88)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.33, fair $9.99, hier $7.98)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.16, fair $9.31, hier $7.50)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 121.93** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (22):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv8pt5-161 Umbreon ex: in tail 4/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 4/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+1.0pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+10.3pt**, DROP (20th pctile) = **-19.6pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (7):
- sv1-246 Great Tusk ex: 3m +19.4pt, market $13.84
- sv4pt5-244 Ting-Lu ex: 3m +14.3pt, market $6.85
- sv8-236 Durant ex: 3m +19.9pt, market $38.96
- swsh10-161 Beedrill V: 3m +12.8pt, market $77.83
- swsh7-182 Golurk V: 3m +25.1pt, market $39.54
- swsh7-194 Rayquaza V: 3m +19.1pt, market $489.58
- swsh7-215 Umbreon VMAX: 3m +12.4pt, market $2380.34
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -37.6pt, market $2.15
- sv10-215 Cynthia's Garchomp ex: 3m -26.4pt, market $4.33
- sv8-218 Black Kyurem ex: 3m -25.2pt, market $1.99

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.9pt (t_eff -1.82, null), 3m -6.4pt (t_eff -1.74, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +1.0pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +1.0pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.796) is the trustworthy interval coverage;
  the naive number (0.800) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  491 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card `model_results.csv`/`hier_results.csv` vintage is superseded by this
  refresh.

Full per-card table: `fair_value.csv` (same directory).
