# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-11-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6512 |
| coverage_target | 0.80 |
| q_lo | -1.1989 |
| q_hi | 1.3003 |
| band_width | 2.4992 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 50 |
| n_fair | 403 |
| n_undervalued | 50 |
| persistence_rho | 0.9747 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 119.4465 |
| forward_spread_pt | 0.83 |
| spike_pct | 3.7 |
| drop_pct | -28.5 |
| snapshot | 2026-11-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.651**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.199, 1.300]** (width 2.499),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **403**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.7%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (67): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.55, fair $15.13, hier $10.82)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $146.59, fair $28.88, hier $71.72)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.60, fair $5.95, hier $4.63)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $522.15, fair $120.01, hier $161.29)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $111.08, fair $12.32, hier $32.38)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $126.27, fair $31.37, hier $55.67)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $57.86, fair $14.57, hier $27.88)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $98.29, fair $12.89, hier $39.02)
- sv1-243 Spidops ex: OLS overvalued vs hier fair (market $7.88, fair $1.53, hier $2.04)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $3.34, fair $15.01, hier $7.77)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.05, fair $3.85, hier $2.25)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.24, fair $14.47, hier $7.93)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $2.86, fair $11.63, hier $6.23)
- sv10-219 Team Rocket's Persian ex: OLS undervalued vs hier fair (market $2.79, fair $11.14, hier $6.01)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $13.16, fair $3.24, hier $3.66)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $85.69, fair $17.64, hier $25.50)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $63.55, fair $17.16, hier $24.61)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.76, fair $7.14, hier $5.79)
- sv4pt5-240 Wo-Chien ex: OLS overvalued vs hier fair (market $7.47, fair $1.97, hier $6.91)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.19, fair $1.91, hier $6.84)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.23, fair $1.28, hier $4.69)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $13.80, fair $2.45, hier $8.52)
- sv6-189 Sinistcha ex: OLS undervalued vs hier fair (market $1.48, fair $5.17, hier $3.50)
- sv6-192 Hearthflame Mask Ogerpon ex: OLS undervalued vs hier fair (market $1.81, fair $6.35, hier $4.18)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $30.13, fair $7.97, hier $14.42)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $42.94, fair $6.35, hier $15.49)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $1.90, fair $10.52, hier $6.88)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.11, fair $7.03, hier $4.82)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.83, fair $8.13, hier $5.50)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $25.50, fair $5.58, hier $7.25)
- sv8pt5-161 Umbreon ex: OLS overvalued vs hier fair (market $1130.37, fair $275.66, hier $312.46)
- sv9-176 Hop's Zacian ex: OLS undervalued vs hier fair (market $1.28, fair $4.36, hier $3.14)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $12.41, fair $2.49, hier $3.69)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $27.22, fair $10.94, hier $6.40)
- swsh10-166 Starmie V: OLS undervalued vs hier fair (market $3.52, fair $13.35, hier $7.87)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.83, fair $22.91, hier $12.81)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.07, fair $9.30, hier $5.60)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.58, fair $10.16, hier $6.01)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $58.18, fair $18.35, hier $10.31)
- swsh10-180 Wyrdeer V: OLS undervalued vs hier fair (market $2.06, fair $6.94, hier $4.23)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $14.93, fair $85.36, hier $60.43)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.59, fair $28.71, hier $22.48)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.07, fair $28.91, hier $22.56)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.72, fair $33.24, hier $25.06)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $15.46, fair $67.49, hier $48.42)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.33, fair $8.91, hier $5.58)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.35, fair $10.82, hier $6.82)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.83, fair $6.39, hier $4.20)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $8.78, fair $31.77, hier $25.67)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $8.51, fair $28.89, hier $14.62)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.38, fair $10.48, hier $5.80)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.11, fair $19.58, hier $10.40)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $20.76, fair $7.26, hier $4.15)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $22.31, fair $116.09, hier $66.73)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $11.21, fair $75.94, hier $46.77)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $40.42, fair $216.64, hier $119.95)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $34.48, fair $7.97, hier $9.31)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $134.03, fair $36.63, hier $30.87)
- swsh7-186 Medicham V: OLS overvalued vs hier fair (market $17.20, fair $4.43, hier $4.49)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.90, fair $146.32, hier $160.21)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.64, fair $130.66, hier $147.69)
- swsh7-209 Glaceon VMAX: OLS overvalued vs hier fair (market $285.92, fair $70.78, hier $84.09)
- swsh7-210 Dracozolt VMAX: OLS fair vs hier undervalued (market $7.42, fair $24.10, hier $31.38)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $99.18, fair $357.53, hier $363.73)
- swsh9-156 Lumineon V: OLS overvalued vs hier fair (market $13.79, fair $3.67, hier $3.56)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.25, fair $8.30, hier $7.46)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.30, fair $7.69, hier $6.91)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.975** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 119.45** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (20):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 4/5
- sv3pt5-199 Charizard ex: in tail 5/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 5/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 4/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-196 Kleavor VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 4/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-188 Pidgeot V: in tail 4/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-176 Unown V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 4/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 4/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.8pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.7pt**, DROP (20th pctile) = **-28.5pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (1):
- swsh7-196 Noivern V: 3m +4.4pt, market $76.07
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (1):
- sv10-216 Team Rocket's Nidoking ex: 3m -45.4pt, market $2.86

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.2pt (t_eff -1.18, null), 3m -5.8pt (t_eff -1.67, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.8pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.8pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
