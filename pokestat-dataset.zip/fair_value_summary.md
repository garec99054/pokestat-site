# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-10-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6457 |
| coverage_target | 0.80 |
| q_lo | -1.2444 |
| q_hi | 1.3376 |
| band_width | 2.5820 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 50 |
| n_fair | 403 |
| n_undervalued | 50 |
| persistence_rho | 0.9759 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.3069 |
| forward_spread_pt | 0.85 |
| spike_pct | 3.3 |
| drop_pct | -26.8 |
| snapshot | 2026-10-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.646**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.244, 1.338]** (width 2.582),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **403**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **86.1%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (70): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.84, fair $17.34, hier $11.54)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $159.10, fair $30.17, hier $85.54)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.53, fair $6.50, hier $4.60)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $654.69, fair $134.20, hier $210.31)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $115.29, fair $12.72, hier $40.33)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $142.82, fair $34.93, hier $70.74)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $57.22, fair $14.68, hier $32.74)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $132.43, fair $13.38, hier $50.59)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.58, fair $10.73, hier $10.56)
- sv1-231 Koraidon ex: OLS undervalued vs hier fair (market $1.99, fair $7.03, hier $7.15)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $3.89, fair $15.83, hier $7.78)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.19, fair $4.17, hier $2.35)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $3.43, fair $16.92, hier $8.67)
- sv10-216 Team Rocket's Nidoking ex: OLS undervalued vs hier fair (market $2.56, fair $13.14, hier $6.67)
- sv10-219 Team Rocket's Persian ex: OLS undervalued vs hier fair (market $3.58, fair $13.06, hier $6.71)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $14.90, fair $3.71, hier $4.45)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $5.75, fair $1.47, hier $2.05)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $90.26, fair $20.70, hier $29.38)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $305.08, fair $60.34, hier $76.73)
- sv3pt5-202 Zapdos ex: OLS overvalued vs hier fair (market $81.88, fair $20.77, hier $29.67)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.64, fair $6.14, hier $4.85)
- sv4-246 Golisopod ex: OLS overvalued vs hier fair (market $25.43, fair $5.30, hier $6.08)
- sv4-248 Iron Hands ex: OLS overvalued vs hier fair (market $12.15, fair $3.16, hier $3.82)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.36, fair $2.21, hier $7.76)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.67, fair $1.26, hier $4.63)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.41, fair $2.86, hier $9.72)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $34.04, fair $8.04, hier $15.89)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.14, fair $1.08, hier $1.61)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $37.32, fair $6.33, hier $16.87)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.24, fair $12.86, hier $7.54)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.13, fair $8.09, hier $5.04)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.84, fair $7.39, hier $4.66)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $35.55, fair $6.60, hier $8.72)
- sv8pt5-161 Umbreon ex: OLS overvalued vs hier fair (market $1215.47, fair $316.78, hier $375.19)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $13.62, fair $2.81, hier $4.59)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $26.78, fair $10.76, hier $6.04)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.83, fair $23.04, hier $12.19)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.14, fair $9.08, hier $5.28)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.63, fair $11.58, hier $6.47)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $61.43, fair $19.53, hier $10.30)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $15.29, fair $83.85, hier $57.61)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $7.82, fair $28.20, hier $21.64)
- swsh10-196 Kleavor VSTAR: OLS undervalued vs hier fair (market $8.29, fair $29.15, hier $22.57)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.92, fair $38.21, hier $28.31)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.59, fair $72.67, hier $50.47)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.62, fair $9.85, hier $5.63)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.43, fair $10.58, hier $6.17)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.91, fair $7.08, hier $4.26)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $8.94, fair $35.95, hier $27.23)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.84, fair $30.02, hier $14.45)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.40, fair $10.81, hier $5.79)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.57, fair $22.40, hier $11.24)
- swsh12-183 Regidrago V: OLS undervalued vs hier fair (market $2.32, fair $8.34, hier $4.48)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $24.29, fair $8.09, hier $4.43)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.04, fair $32.45, hier $15.28)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $23.92, fair $132.54, hier $73.03)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.86, fair $54.60, hier $33.63)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $38.87, fair $235.32, hier $124.08)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $38.77, fair $9.22, hier $11.08)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $139.79, fair $39.34, hier $29.85)
- swsh7-173 Suicune V: OLS undervalued vs hier fair (market $9.26, fair $34.28, hier $26.40)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $3.00, fair $13.08, hier $10.99)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.35, fair $8.59, hier $7.66)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.73, fair $158.96, hier $164.14)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.75, fair $147.11, hier $155.54)
- swsh7-209 Glaceon VMAX: OLS overvalued vs hier fair (market $307.37, fair $78.11, hier $86.48)
- swsh7-210 Dracozolt VMAX: OLS fair vs hier undervalued (market $7.65, fair $24.86, hier $31.26)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $108.15, fair $399.12, hier $375.82)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.22, fair $9.26, hier $7.87)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.27, fair $8.00, hier $6.95)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.31** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 5/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+0.8pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+3.3pt**, DROP (20th pctile) = **-26.8pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (3):
- sv4-248 Iron Hands ex: 3m +5.2pt, market $12.15
- sv7-160 Dachsbun ex: 3m +17.7pt, market $4.14
- swsh7-218 Rayquaza VMAX: 3m +12.9pt, market $1267.32
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (3):
- me2pt5-251 Sprigatito ex: 3m -41.3pt, market $1.76
- sv1-227 Miraidon ex: 3m -36.5pt, market $2.58
- sv10-212 Electivire ex: 3m -33.1pt, market $1.19

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.5pt (t_eff -1.46, null), 3m -6.4pt (t_eff -1.79, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +0.8pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +0.8pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
