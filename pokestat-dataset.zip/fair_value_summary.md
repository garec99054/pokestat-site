# Hedonic fair-value + persistence

One row per modeled card: the hedonic point estimate, an 80% conformal-style
interval, an interval-aware over/under-valued verdict, a Bayesian-hierarchical
cross-check, residual-rank persistence from the historical backtest, and a
combined mispricing+momentum signal. Prices for the fit are the live `prices`
snapshot; trailing returns use the
canonical monthly `price_history` panel (snapshot 2026-09-01), so the two
price sources deliberately differ.

## Key metrics (machine-readable)

| metric | value |
| --- | --- |
| n_modeled | 503 |
| n_excluded | 0 |
| loocv_r2 | 0.6334 |
| coverage_target | 0.80 |
| q_lo | -1.2822 |
| q_hi | 1.3572 |
| band_width | 2.6394 |
| coverage_naive | 0.7972 |
| coverage_loo | 0.7972 |
| n_overvalued | 50 |
| n_fair | 403 |
| n_undervalued | 50 |
| persistence_rho | 0.9758 |
| persistence_n_pairs | 4683 |
| persistence_n_eff | 751 |
| persistence_t_eff | 122.0223 |
| forward_spread_pt | 1.03 |
| spike_pct | 10.3 |
| drop_pct | -19.6 |
| snapshot | 2026-09-01 |

## Universe

- Modeled cards (complete desirability): **503**.
- Excluded (modelable but missing static premium/appeal): **0** -- none.
- Hedonic: `log(price) ~ log(pull_cost) + desirability` (45/45/10 premium/artwork/appeal),
  HC3 robust SEs, **LOOCV R2 = 0.633**.

## Interval (A2)

The band mirrors the forward model's 80% leave-one-out conformal band: COVERAGE =
0.80, ALPHA = 0.20. LOO prediction errors (the PRESS
shortcut `e_i/(1-h_ii)`, log scale) give asymmetric empirical quantiles
**[q_lo, q_hi] = [-1.282, 1.357]** (width 2.639),
applied globally: `fair_lo = exp(pred_log + q_lo)`, `fair_hi = exp(pred_log + q_hi)`.

Verdict is interval-aware: overvalued iff market > fair_hi, undervalued iff market
< fair_lo, else fair.

Two coverage numbers, honest one published:
- `coverage_naive` = **0.797** -- CIRCULAR (the same residuals
  built the band; ~exactly COVERAGE by construction).
- `coverage_loo` = **0.797** -- the PUBLISHED figure: a jackknife
  over the quantile estimate (each point's band rebuilt excluding it). `press` is
  already leave-one-out for the point prediction, so this is the second-order
  correction over the quantile and sits near but not exactly at 0.80.

## Verdict counts (interval-aware)

- overvalued: **50**, fair: **403**, undervalued: **50**.

## OLS hedonic vs Bayesian hierarchical (A3)

Both fit on the same deterministic `build_dataset(conn)` in the same refresh.
- Agreement rate (over 503 cards present in both): **85.1%**.
- Hier-missing fit-set cards: none (id sets match).
- Disagreements (75): a first-class signal, not an error.

- me1-159 Mega Gardevoir ex: OLS undervalued vs hier fair (market $4.70, fair $19.20, hier $11.93)
- me1-187 Mega Gardevoir ex: OLS overvalued vs hier fair (market $195.55, fair $30.86, hier $100.68)
- me2-108 Mega Heracross ex: OLS undervalued vs hier fair (market $1.62, fair $6.81, hier $4.61)
- me2-114 Empoleon ex: OLS undervalued vs hier fair (market $1.25, fair $5.07, hier $3.53)
- me2pt5-276 Pikachu ex: OLS overvalued vs hier fair (market $952.70, fair $146.57, hier $263.67)
- me4-122 Mega Greninja ex: OLS overvalued vs hier fair (market $145.94, fair $14.81, hier $51.23)
- me5-116 Mega Darkrai ex: OLS overvalued vs hier fair (market $183.55, fair $39.75, hier $89.64)
- me5-117 Morpeko ex: OLS overvalued vs hier fair (market $73.42, fair $14.00, hier $36.18)
- me5-120 Mega Darkrai ex: OLS overvalued vs hier fair (market $146.69, fair $14.34, hier $65.43)
- me55-152 Mew ex: OLS overvalued vs hier fair (market $158.09, fair $37.90, hier $77.73)
- me55-155 Jirachi ex: OLS overvalued vs hier fair (market $83.33, fair $15.69, hier $36.69)
- sv1-227 Miraidon ex: OLS undervalued vs hier fair (market $2.59, fair $9.58, hier $9.14)
- sv1-243 Spidops ex: OLS overvalued vs hier fair (market $8.97, fair $1.68, hier $2.14)
- sv1-247 Koraidon ex: OLS overvalued vs hier fair (market $23.48, fair $5.94, hier $6.36)
- sv10-208 Team Rocket's Moltres ex: OLS undervalued vs hier fair (market $4.63, fair $17.65, hier $9.14)
- sv10-212 Electivire ex: OLS undervalued vs hier fair (market $1.05, fair $4.55, hier $2.79)
- sv10-215 Cynthia's Garchomp ex: OLS undervalued vs hier fair (market $4.33, fair $19.04, hier $9.94)
- sv10-228 Yanmega ex: OLS overvalued vs hier fair (market $18.98, fair $3.59, hier $5.09)
- sv3-222 Eiscue ex: OLS overvalued vs hier fair (market $6.12, fair $1.53, hier $2.13)
- sv3pt5-198 Venusaur ex: OLS overvalued vs hier fair (market $109.57, fair $23.78, hier $31.30)
- sv3pt5-199 Charizard ex: OLS overvalued vs hier fair (market $353.46, fair $72.04, hier $82.11)
- sv3pt5-201 Alakazam ex: OLS overvalued vs hier fair (market $73.85, fair $17.34, hier $23.78)
- sv4-224 Cofagrigus ex: OLS undervalued vs hier fair (market $1.89, fair $6.98, hier $5.23)
- sv4pt5-242 Chien-Pao ex: OLS overvalued vs hier fair (market $9.25, fair $2.13, hier $7.82)
- sv4pt5-244 Ting-Lu ex: OLS overvalued vs hier fair (market $5.88, fair $1.25, hier $5.03)
- sv4pt5-245 Koraidon ex: OLS overvalued vs hier fair (market $12.60, fair $2.43, hier $9.02)
- sv6pt5-92 Fezandipiti ex: OLS overvalued vs hier fair (market $36.60, fair $8.20, hier $16.68)
- sv7-160 Dachsbun ex: OLS overvalued vs hier fair (market $4.30, fair $1.04, hier $1.53)
- sv7-167 Hydrapple ex: OLS overvalued vs hier fair (market $38.61, fair $7.14, hier $19.86)
- sv8-217 Milotic ex: OLS undervalued vs hier fair (market $2.37, fair $14.38, hier $8.31)
- sv8-218 Black Kyurem ex: OLS undervalued vs hier fair (market $2.17, fair $8.83, hier $5.44)
- sv8-226 Tatsugiri ex: OLS undervalued vs hier fair (market $1.97, fair $8.96, hier $5.32)
- sv8-236 Durant ex: OLS overvalued vs hier fair (market $40.24, fair $6.65, hier $9.52)
- sv8-241 Archaludon ex: OLS overvalued vs hier fair (market $12.62, fair $2.94, hier $4.67)
- sv9-182 Volcanion ex: OLS overvalued vs hier fair (market $17.21, fair $3.41, hier $5.86)
- swsh10-162 Hisuian Lilligant V: OLS undervalued vs hier fair (market $3.60, fair $13.97, hier $7.21)
- swsh10-163 Hisuian Lilligant V: OLS fair vs hier overvalued (market $27.75, fair $10.90, hier $5.81)
- swsh10-169 Hisuian Typhlosion V: OLS undervalued vs hier fair (market $5.82, fair $25.28, hier $12.21)
- swsh10-173 Hisuian Decidueye V: OLS undervalued vs hier fair (market $2.32, fair $9.79, hier $5.43)
- swsh10-176 Hisuian Samurott V: OLS undervalued vs hier fair (market $2.89, fair $12.13, hier $6.34)
- swsh10-177 Origin Forme Dialga V: OLS fair vs hier overvalued (market $61.83, fair $21.88, hier $10.68)
- swsh10-178 Garchomp V: OLS undervalued vs hier fair (market $10.08, fair $37.49, hier $17.26)
- swsh10-192 Origin Forme Palkia VSTAR: OLS undervalued vs hier fair (market $16.09, fair $102.45, hier $63.91)
- swsh10-195 Hisuian Decidueye VSTAR: OLS undervalued vs hier fair (market $8.01, fair $30.55, hier $22.83)
- swsh10-197 Hisuian Samurott VSTAR: OLS undervalued vs hier fair (market $8.47, fair $40.28, hier $27.74)
- swsh10-198 Origin Forme Dialga VSTAR: OLS undervalued vs hier fair (market $16.98, fair $82.22, hier $52.74)
- swsh11-172 Hisuian Electrode V: OLS undervalued vs hier fair (market $2.20, fair $8.51, hier $4.67)
- swsh11-176 Rotom V: OLS undervalued vs hier fair (market $2.73, fair $10.33, hier $5.58)
- swsh11-177 Rotom V: OLS fair vs hier overvalued (market $31.00, fair $12.44, hier $6.80)
- swsh11-178 Enamorus V: OLS undervalued vs hier fair (market $2.39, fair $11.10, hier $5.97)
- swsh11-179 Aerodactyl V: OLS undervalued vs hier fair (market $2.72, fair $10.09, hier $5.41)
- swsh11-183 Galarian Perrserker V: OLS undervalued vs hier fair (market $1.85, fair $7.15, hier $4.00)
- swsh11-197 Kyurem VMAX: OLS undervalued vs hier fair (market $9.43, fair $38.68, hier $28.43)
- swsh11-201 Giratina VSTAR: OLS undervalued vs hier fair (market $28.19, fair $200.34, hier $119.74)
- swsh12-172 Reshiram V: OLS undervalued vs hier fair (market $7.52, fair $31.46, hier $14.60)
- swsh12-178 Mawile V: OLS undervalued vs hier fair (market $2.57, fair $12.95, hier $6.86)
- swsh12-179 Hisuian Arcanine V: OLS undervalued vs hier fair (market $5.48, fair $27.99, hier $13.41)
- swsh12-184 Regidrago V: OLS fair vs hier overvalued (market $26.96, fair $7.09, hier $4.01)
- swsh12-187 Ho-Oh V: OLS undervalued vs hier fair (market $8.64, fair $35.50, hier $16.25)
- swsh12-197 Alolan Vulpix VSTAR: OLS undervalued vs hier fair (market $23.62, fair $146.10, hier $77.61)
- swsh12-199 Unown VSTAR: OLS undervalued vs hier fair (market $10.27, fair $61.74, hier $37.67)
- swsh12-202 Lugia VSTAR: OLS undervalued vs hier fair (market $39.39, fair $274.89, hier $138.80)
- swsh12pt5-160 Pikachu: OLS overvalued vs hier fair (market $48.78, fair $10.38, hier $13.64)
- swsh7-167 Leafeon V: OLS fair vs hier overvalued (market $150.69, fair $41.45, hier $28.75)
- swsh7-176 Arctovish V: OLS undervalued vs hier fair (market $2.97, fair $13.51, hier $10.72)
- swsh7-180 Espeon V: OLS fair vs hier overvalued (market $238.50, fair $68.69, hier $46.85)
- swsh7-187 Lycanroc V: OLS undervalued vs hier fair (market $4.07, fair $14.78, hier $11.78)
- swsh7-197 Duraludon V: OLS undervalued vs hier fair (market $2.41, fair $10.30, hier $8.59)
- swsh7-204 Leafeon VMAX: OLS undervalued vs hier fair (market $43.20, fair $169.04, hier $166.20)
- swsh7-207 Gyarados VMAX: OLS undervalued vs hier fair (market $48.18, fair $214.51, hier $196.18)
- swsh7-208 Glaceon VMAX: OLS undervalued vs hier fair (market $36.91, fair $163.48, hier $162.27)
- swsh7-210 Dracozolt VMAX: OLS fair vs hier undervalued (market $7.84, fair $26.51, hier $32.55)
- swsh7-217 Rayquaza VMAX: OLS undervalued vs hier fair (market $111.53, fair $446.63, hier $391.48)
- swsh9-163 Zamazenta V: OLS undervalued vs hier fair (market $2.50, fair $10.71, hier $8.54)
- swsh9-164 Flygon V: OLS undervalued vs hier fair (market $2.34, fair $9.04, hier $7.49)

## Residual-rank persistence (A4)

From `backtest_results.csv` (studentized residuals already stored, no backtest
change). Within each snapshot, cards are ranked by studentized residual into
`snap_pctile in [0,100]` (higher = more overvalued). Pooled over every
consecutive-snapshot pair:
- Spearman **rho = 0.976** over **n_pairs = 4683** pairs.
- **n_eff = 751** (distinct cards; conservative -- overlapping pairs from
  one card are dependent and all cards within a snapshot share one fit, so n_eff
  under-counts within-snapshot dependence).
- **t_eff = 122.02** -- an UPPER BOUND on significance.

`chronic_flag` = in the same tail (`flag` or `snap_pctile >= 90` / `<= 10`) in >=
4 of the last 5 snapshots (eligible: present in >=
4 snapshots).

- Chronically overvalued (21):
- sv10-228 Yanmega ex: in tail 4/5
- sv3-225 Pidgeot ex: in tail 5/5
- sv3pt5-199 Charizard ex: in tail 4/5
- sv4pt5-232 Mew ex: in tail 5/5
- sv6pt5-92 Fezandipiti ex: in tail 5/5
- sv7-167 Hydrapple ex: in tail 5/5
- sv7-169 Dachsbun ex: in tail 5/5
- sv9-182 Volcanion ex: in tail 5/5
- sv9-183 Iono's Bellibolt ex: in tail 4/5
- swsh10-167 Origin Forme Palkia V: in tail 5/5
- swsh10-172 Machamp V: in tail 5/5
- swsh11-180 Aerodactyl V: in tail 5/5
- swsh11-186 Giratina V: in tail 5/5
- swsh12-186 Lugia V: in tail 5/5
- swsh7-189 Umbreon V: in tail 5/5
- swsh7-192 Dragonite V: in tail 5/5
- swsh7-194 Rayquaza V: in tail 5/5
- swsh7-196 Noivern V: in tail 5/5
- swsh7-205 Leafeon VMAX: in tail 5/5
- swsh7-215 Umbreon VMAX: in tail 5/5
- swsh9-154 Charizard V: in tail 5/5
- Chronically undervalued (58):
- sv1-228 Gardevoir ex: in tail 4/5
- sv1-231 Koraidon ex: in tail 5/5
- sv4-224 Cofagrigus ex: in tail 5/5
- sv4-230 Aegislash ex: in tail 5/5
- sv6-192 Hearthflame Mask Ogerpon ex: in tail 5/5
- sv6-212 Hearthflame Mask Ogerpon ex: in tail 4/5
- sv8-217 Milotic ex: in tail 5/5
- sv8-218 Black Kyurem ex: in tail 4/5
- sv8-226 Tatsugiri ex: in tail 4/5
- swsh10-162 Hisuian Lilligant V: in tail 5/5
- swsh10-164 Virizion V: in tail 5/5
- swsh10-169 Hisuian Typhlosion V: in tail 4/5
- swsh10-173 Hisuian Decidueye V: in tail 5/5
- swsh10-176 Hisuian Samurott V: in tail 5/5
- swsh10-178 Garchomp V: in tail 5/5
- swsh10-192 Origin Forme Palkia VSTAR: in tail 5/5
- swsh10-193 Hisuian Typhlosion VSTAR: in tail 5/5
- swsh10-195 Hisuian Decidueye VSTAR: in tail 5/5
- swsh10-197 Hisuian Samurott VSTAR: in tail 5/5
- swsh10-198 Origin Forme Dialga VSTAR: in tail 5/5
- swsh11-172 Hisuian Electrode V: in tail 5/5
- swsh11-176 Rotom V: in tail 5/5
- swsh11-178 Enamorus V: in tail 5/5
- swsh11-179 Aerodactyl V: in tail 5/5
- swsh11-181 Gallade V: in tail 4/5
- swsh11-183 Galarian Perrserker V: in tail 5/5
- swsh11-197 Kyurem VMAX: in tail 5/5
- swsh11-199 Aerodactyl VSTAR: in tail 4/5
- swsh11-201 Giratina VSTAR: in tail 5/5
- swsh11-203 Hisuian Zoroark VSTAR: in tail 5/5
- swsh12-170 Serperior V: in tail 5/5
- swsh12-172 Reshiram V: in tail 5/5
- swsh12-173 Alolan Vulpix V: in tail 5/5
- swsh12-178 Mawile V: in tail 5/5
- swsh12-179 Hisuian Arcanine V: in tail 5/5
- swsh12-183 Regidrago V: in tail 4/5
- swsh12-185 Lugia V: in tail 5/5
- swsh12-187 Ho-Oh V: in tail 5/5
- swsh12-197 Alolan Vulpix VSTAR: in tail 5/5
- swsh12-199 Unown VSTAR: in tail 5/5
- swsh12-202 Lugia VSTAR: in tail 5/5
- swsh7-168 Trevenant V: in tail 5/5
- swsh7-170 Volcarona V: in tail 5/5
- swsh7-173 Suicune V: in tail 5/5
- swsh7-176 Arctovish V: in tail 5/5
- swsh7-178 Dracozolt V: in tail 5/5
- swsh7-187 Lycanroc V: in tail 4/5
- swsh7-195 Noivern V: in tail 5/5
- swsh7-197 Duraludon V: in tail 5/5
- swsh7-204 Leafeon VMAX: in tail 5/5
- swsh7-207 Gyarados VMAX: in tail 5/5
- swsh7-208 Glaceon VMAX: in tail 5/5
- swsh7-211 Sylveon VMAX: in tail 5/5
- swsh7-213 Lycanroc VMAX: in tail 5/5
- swsh7-214 Umbreon VMAX: in tail 5/5
- swsh7-217 Rayquaza VMAX: in tail 5/5
- swsh9-163 Zamazenta V: in tail 5/5
- swsh9-176 Arceus VSTAR: in tail 5/5

**Rank persistence is NOT return persistence.** The pooled undervalued-minus-
overvalued forward spread is only **+1.0pt** (live from
the backtest), regime-dependent (2025 negative, 2026 positive). A "chronically
overvalued" card has NOT been shown to underperform.

## Combined signals (A5)

Thresholds from the universe's own trailing-3m distribution: SPIKE (80th pctile)
= **+10.3pt**, DROP (20th pctile) = **-19.6pt**.
- `double_caution` = overvalued verdict AND trailing_3m >= SPIKE
  (6):
- sv4pt5-244 Ting-Lu ex: 3m +14.3pt, market $5.88
- sv8-236 Durant ex: 3m +19.9pt, market $40.24
- swsh10-161 Beedrill V: 3m +12.8pt, market $76.36
- swsh7-182 Golurk V: 3m +25.1pt, market $36.90
- swsh7-194 Rayquaza V: 3m +19.1pt, market $490.35
- swsh7-215 Umbreon VMAX: 3m +12.4pt, market $2368.94
- `contrarian_watch` = undervalued verdict AND trailing_3m <= DROP
  (4):
- me2-114 Empoleon ex: 3m -33.6pt, market $1.25
- me2pt5-251 Sprigatito ex: 3m -37.6pt, market $1.76
- sv10-215 Cynthia's Garchomp ex: 3m -26.4pt, market $4.33
- sv8-218 Black Kyurem ex: 3m -25.2pt, market $2.17

Descriptive only. "double caution" pairs overvaluation with a recent run-up, where
the pooled momentum study measures NO significant continuation and NO significant reversion at these horizons (1m -2.9pt (t_eff -1.82, null), 3m -6.4pt (t_eff -1.74, null), live from `momentum_strata.csv`), so the pairing leans neither way; "contrarian watch" is the mirror.
Neither list is a per-card return prediction, and the interval verdict itself has a
pooled forward spread of only +1.0pt and is regime-dependent.

## Honest caveats (loud)

- The flags DESCRIBE mispricing vs fundamentals at a leakage-free as-of-T fit; they
  have NOT predicted returns out-of-sample. Pooled undervalued-minus-overvalued
  forward spread +1.0pt; regime-dependent (2025 bad, 2026
  positive).
- `coverage_loo` (0.797) is the trustworthy interval coverage;
  the naive number (0.797) is circular and labeled so.
- Disagreement between the OLS and hierarchical verdicts is surfaced, not hidden.
- Published-number disclosure: the hedonic universe now covers all
  503 modelable cards (complete desirability), so the fair-value fit,
  the hierarchical cross-check, and the backtest share one coherent universe; the
  stale 135-card vintage is superseded by this refresh.

Full per-card table: `fair_value.csv` (same directory).
