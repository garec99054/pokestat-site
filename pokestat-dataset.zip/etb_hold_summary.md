# Is an Elite Trainer Box Worth Holding?

Turning the ETB price series into the money a person would actually have kept.
Everything here is computed live from `data/output/etb_panel.csv` and the cost
constants in `pokestat/model/etb_hold.py`; no number in this document is
hardcoded.

Window **2024-03 .. 2026-11** (33 monthly observations, one regime) |
**111 products** | **42,334 realised holding periods**
| gross index **66.7%/yr** | net at 12 months
**29.3%/yr**

## Bottom line, in plain language

**Over 2024-03 to 2026-11, Elite Trainer Boxes
went up a lot -- about 66.7% a year as a price index. A person who bought one and sold it did not keep that.** After sales tax on the way in, the marketplace's cut on the way
out, and shipping a heavy box, a 12-month hold at that rate netted about
29.3% a year and a 24-month hold about 48.0% a year. The gap is
roughly 37 points a year at one year and 19 at two,
and it shrinks with time only because the costs are charged once.

Five things this archive showed, in order of how confident the data lets us be.
They describe what happened in the sample; none of them is a recommendation:

1. **Short holds lost money even in a rising market.** The costs are a one-time
   toll of roughly
   20% plus about
   $12.
   In this archive 81% of 3-month holds lost money *while
   prices were rising*. You need roughly **7 months** just to clear the fees and beat cash. The cost model is
   regime-independent; the floor it implies is not, because the floor
   compounds an assumed forward growth rate against those costs. See the
   growth sensitivity in section 7.
2. **New releases underperformed retired product here.** Boxes bought within 6 months of release and held a year lost money 21% of the time in this sample, against 10% for product already retired 1-3 years. That is what the archive contains, not a rule: it is a pattern observed inside one boom, and the out-of-print mechanism behind it is not separately testable with this data (etb_summary.md section 4.5).
3. **One box is not the index.** The middle 50% of single-box 12-month outcomes
   spans about 70 annualised points, and 12% of
   one-year holds still lost money. The index number tells you nothing about
   which box you own.
4. **Flat is not break-even.** If ETB prices simply stop rising, a 12-month hold
   returns 0.75x -- a real loss, because the frictions are charged
   anyway. Prices have to keep rising for this to work.
5. **Everything above happened in one market.** Prices falling 48.7%
   from here would erase the entire edge over a savings account for someone two
   years in. Nothing in this data says whether that will happen; the archive has
   never observed a down market.

**So: was an ETB worth holding over this window? On the realised numbers, yes -- for holds longer than about 7 months, on retired rather than newly released product, in a market that kept rising, which it did throughout. Is that a reason to expect the same from here? This data cannot say. It contains no falling market at all, and section 6 quantifies exactly what size of fall would erase the edge.**

*This is measurement, not investment advice.*

---

## 1. What comes out before you see a dollar

Every number is a named constant in `pokestat/model/etb_hold.py`, not a value
inlined into a formula, and every one is swept in section 8.

| Friction | Assumption | Charged |
| --- | --- | --- |
| TCGplayer commission | 10.25% of sale | once, on sale |
| Payment processing | 2.5% + $0.30 | once, on sale |
| Sales tax at purchase | 7.5% | once, on purchase |
| Outbound shipping (2.5 lb, 12x10x4 in) | $12.00 | once, on sale |
| Storage | $0.10/month | monthly |
| Seller undercut below cheapest ask | 0.0% | once, on sale |
| Risk-free alternative (the hurdle) | 4.5%/yr | continuous |
| Collectibles capital gains | 28.0% | shown separately |

The marketplace take is **12.75% + $0.30**
and the purchase tax is **7.5%**, so the round trip carries a
one-time toll of roughly **20.2% of the
box price plus $12.30 of fixed
cost** before a single day of holding. The risk-free rate is a *stated
assumption*, not fetched: this project's permitted sources carry card prices and
FX rates, not Treasury yields.

Capital gains is shown as its own layer rather than folded into the headline.
At 28.0% it is larger than every transaction cost here
combined: a 24-month hold nets 48.0%/yr
before it and 36.3%/yr after.

## 2. The bid-ask assumption does not survive contact with the data

**This study was commissioned on the premise of a "~15-20% bid-ask on thin
sealed listings". The archive does not support that number, and the obvious way
of computing it is badly wrong.**

`price_history` carries a *listing* book -- `low` is the cheapest ask, `high` is
the dearest ask, `mid` is the midpoint of those two. There is no bid anywhere in
it. Treating `high - low` as a spread gives a median of
**211% of the market price** for
ETBs, because `high` is whatever the most optimistic listing on the site says --
its median is **3.13x** the market price and its
99th percentile is **64x**. Any friction model
built on that column would be fiction.

What is measurable is the cheapest ask against TCGplayer's market price, which
is an average of recent *actual sales*:

* median `low / market` = **0.977**
  (10th-90th percentile 0.87-1.28);
* that ratio drifted from **0.960** in
  2024-03 to **0.965** in
  2026-11, i.e. it is close to stationary;
* across 111 products, a round trip executed at `low` on
  **both** ends returned a median **1.028x**
  what the same round trip at `market` returned, and only
  **33%** of products did worse that way.

So the measurable part of the spread very nearly cancels over a round trip. The default `SELLER_UNDERCUT_PCT` is therefore set to the value the
book supports -- zero -- and swept to 15% in section 8, because "not measurable"
is not "zero". What the data says the holder actually loses is **fees, sales tax
and shipping**, not spread.

## 3. Gross versus net -- the gap is the point

The ETB price index over 2024-03..2026-11 grew
**66.7%/yr** gross (HAC 95% CI
25.5% to 121.4%, t = 3.52). Nobody
earns that. Holding one box at that same gross rate, on the median
2026-11 ETB price of **$211.22**:

| Hold | Gross x | Net x | Gross %/yr | Net %/yr | Drag pp | Gross %/yr needed to beat cash | In archive? |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3m | 1.14x | 0.87x | 66.7% | -43.6% | 110.2 | 198.2% | yes |
| 6m | 1.29x | 0.99x | 66.7% | -1.8% | 68.5 | 76.8% | yes |
| 12m | 1.67x | 1.29x | 66.7% | 29.3% | 37.3 | 36.1% | yes |
| 18m | 2.15x | 1.68x | 66.7% | 41.6% | 25.1 | 24.7% | yes |
| 24m | 2.78x | 2.19x | 66.7% | 48.0% | 18.7 | 19.4% | yes |
| 36m | 4.63x | 3.69x | 66.7% | 54.5% | 12.2 | 14.3% | extrapolated |
| 60m | 12.86x | 10.36x | 66.7% | 59.6% | 7.1 | 10.3% | extrapolated |

Read the last column first. To merely beat cash, a box bought and flipped in
3 months has to appreciate **198.2%/yr**
gross. Over 12 months the bar falls to 36.1%/yr
and over 24 months to 19.4%/yr. Nothing about
the market changed between those rows -- only the number of months the same
one-time toll is spread across.

That is why the drag column collapses from **110.2 points
a year** at 3 months to **18.7 points** at 24. The
friction is a toll, not a tax rate. It is the strongest argument in this entire
study for holding rather than flipping -- and, unlike everything downstream of
it, it is arithmetic and does not depend on the boom continuing.

## 4. What one buyer actually faced

42,334 realised holding periods across 111 products.
**These are overlapping windows and must not be read as 42,334
observations** -- the archive spans 32 months, so the
`indep.` column counts how many genuinely non-overlapping holds of that length
exist in it. All figures are net of the section 1 frictions.

| Hold | Products | Indep. windows | Net x p05 | Net x median | Net x p95 | Net %/yr median | Net %/yr (equal-wt) | P(lose money) | P(worse than cash) | %/yr usable? |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 3m | 109 | 10 | 0.55x | 0.82x | 1.23x | -54.0% | -57.6% | 81% | 82% | **no** |
| 6m | 105 | 5 | 0.61x | 0.98x | 1.62x | -3.8% | -7.8% | 52% | 55% | **no** |
| 12m | 98 | 2 | 0.85x | 1.39x | 2.76x | 39.4% | 38.4% | 12% | 16% | yes |
| 18m | 86 | 1 | 1.24x | 2.09x | 4.47x | 63.4% | 60.2% | 2% | 2% | yes |
| 24m | 79 | 1 | 1.63x | 2.73x | 6.36x | 65.4% | 63.9% | 0% | 0% | yes |

Where the last column says no, the hold is shorter than
12 months and the `%/yr` figures are exponentiation
artefacts (a 3-month -17% becomes "-52%/yr"). For those rows read the multiple
columns; this is the same gate `etb_core` applies to per-product trends.

A 3-month flip lost money **81% of the time** and had a median net outcome of 0.82x -- against a median 3-month GROSS move of 1.12x. At 6 months 52% of holds still ended below cost. By 12 months the median hold returned 1.39x net with 12% losing, and the product-clustered bootstrap puts the median 12-month net rate at 39.4%/yr, 95% CI 34.2% to 47.1% across 98 products.

**Every one of those probabilities is a frequency inside a rising market.** The
reason short holds lost money is arithmetic and will repeat in any regime; the
reason long holds did not is that prices rose, and that will not.

### Why this table disagrees with section 3

Section 3 says a 12-month hold nets 29.3%/yr; this one says
39.4%/yr. Both are right and they measure different things. Section 3
applies the chained index's 66.7%/yr uniformly. The
realised 12-month holds in this table had a median GROSS move of
1.92x, i.e. 91.8%. Two construction
differences separate them: pooling every (product, month, month) triple
over-weights products with long histories, and a uniform index rate spreads the
growth evenly over a window that did not grow evenly. **Take section 3's number
as the one attached to a defensible index and this section's spread as the one
attached to a real buyer's experience.** The disagreement is a composition
effect, not a defect. The gap, 10.0 points, is 27% of the 37.3-point twelve-month friction drag -- a warning about how much of any of these numbers is a construction choice.

### The concentration you take on by buying one box

| Hold | One box net x p10 | median | p90 | Whole-basket net x | One box IQR (pp/yr) | P(one box < basket) | P(one box loses money) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3m | 0.62x | 0.82x | 1.10x | 0.83x | 56 | 51% | 81% |
| 6m | 0.69x | 0.98x | 1.44x | 1.00x | 74 | 48% | 52% |
| 12m | 0.97x | 1.39x | 2.42x | 1.44x | 70 | 49% | 12% |
| 18m | 1.36x | 2.09x | 3.80x | 2.11x | 58 | 49% | 2% |
| 24m | 1.86x | 2.73x | 5.24x | 2.78x | 46 | 49% | 0% |

A single box carries a 70-point interquartile range at 12 months where the basket has one outcome per (buy, sell) pair. The median single box also trailed the basket, so concentration cost the median holder outright and not merely in variance. The decision-relevant number is that 49% of single-box picks did worse than simply owning the average.

| Product | Bought | Sold | Held | Gross x | Net x |
| --- | --- | --- | --- | --- | --- |
| Mega Evolution Pokemon Center Elite Trainer Box (Exclusive) [Mega Lucario] | 2025-10 | 2026-10 | 12m | 0.76x | 0.57x |
| Mega Evolution Pokemon Center Elite Trainer Box (Exclusive) [Mega Lucario] | 2025-10 | 2026-11 | 13m | 0.77x | 0.58x |
| Surging Sparks Elite Trainer Box | 2025-01 | 2026-01 | 12m | 0.94x | 0.59x |
| Surging Sparks Elite Trainer Box | 2025-02 | 2026-02 | 12m | 0.92x | 0.59x |
| Shrouded Fable Pokemon Center Elite Trainer Box (Exclusive) | 2024-09 | 2026-02 | 17m | 0.86x | 0.61x |
| Shrouded Fable Pokemon Center Elite Trainer Box (Exclusive) | 2024-09 | 2025-09 | 12m | 0.86x | 0.61x |

## 5. When you buy -- what the age cut does and does not establish

**The index study does NOT establish that the gains belong to out-of-print product.** Of the 2 cohort contrasts against the "0-12m old at entry" reference, 0 clears the study's bar of t = 2.0. The one a buyer of out-of-print product would quote -- the "1-3y old at entry" cohort's chained index running **12.5pp/yr** above the reference -- carries **t = 1.36**, which does not clear it. This was published here as an established finding after it had been retracted; see `etb_corrections.csv`. What follows repeats the cut on NET HOLDER OUTCOMES, which is a different question from the index contrast and is a description of this window, not an age effect.

Split by how old the set was **at purchase**:

| Bought | Held | Products | Net x median | Net %/yr | P(lose money) |
| --- | --- | --- | --- | --- | --- |
| bought 0-6m after release | 12m | 32 | 1.27x | 26.6% | 21% |
| bought 0-6m after release | 24m | 16 | 2.16x | 46.9% | 2% |
| bought 6-12m after release | 12m | 30 | 1.47x | 47.2% | 16% |
| bought 6-12m after release | 24m | 18 | 3.36x | 83.2% | 0% |
| bought 1-3y after release | 12m | 50 | 1.51x | 50.7% | 10% |
| bought 1-3y after release | 24m | 36 | 3.44x | 85.5% | 0% |
| bought 3y+ after release | 12m | 55 | 1.35x | 35.2% | 12% |
| bought 3y+ after release | 24m | 43 | 2.37x | 53.9% | 0% |

A box bought within 6 months of its set's release and held a year lost money **21%** of the time and returned a median 26.6%/yr net. The same hold on a box already 1-3 years past release lost money **10%** of the time at 50.7%/yr net.

This is the cut a prospective buyer is actually in. Current-release ETBs sit in the 0-6m bucket, and at a 12-month hold it is the worst one in the table -- during a boom.

The mechanism is measurable, and the baseline it is measured from is the whole
finding. Of the 38 products with an observed first
ON-SALE price -- the first monthly snapshot dated on or after street date -- the
median trough over the following 6 months sat
**13.6% below** it
(IQR 4.3% to 24.0%),
reached a median 2 months later, and
**24%** of them fell at least
25%. Because a trough is a minimum, that
statistic is selection-prone; the drop measured at a fixed
6-month endpoint instead, which is not, has a
median of **0.4%** -- so
the typical box was 0.4% below its first on-sale price at that endpoint.

**This corrects a figure this study previously published.** The same statistic measured from each product's first LISTED quote gives 49.9% at the trough and 46.0% at the endpoint, across 40 products -- a gap of 36.3 points on the median (product-bootstrap 95% CI 19.8 to 43.4). That is the number this report used to carry. It was wrong: `price_history` is snapshotted on the 1st and essentially no set ships on the 1st, so a product's first listed quote is normally a pre-order ask on a box that has not shipped -- no longer part of the panel, and read back from `presale_quotes.csv` for this comparison only -- and the old figure was largely that ask deflating rather than a box losing value. Both arms are computed (first on-sale price vs first listed price) so the comparison is auditable rather than asserted. A buyer who paid the pre-order price ate the difference either way.

## 6. What a different regime does to all of it

Nothing above observes a falling market. The archive is
33 monthly points inside one boom. What can be computed is how
much of the observed gain has to be given back before the answer flips.

| Hold | Fall that erases the edge over cash | Fall that turns it into a loss | Net x if prices go flat | Net %/yr if flat |
| --- | --- | --- | --- | --- |
| 3m | n/a | n/a | 0.76x | -67.3% |
| 6m | n/a | n/a | 0.75x | -43.0% |
| 12m | 18.3% | 21.7% | 0.75x | -24.8% |
| 18m | 35.3% | 39.2% | 0.75x | -17.5% |
| 24m | 48.7% | 52.8% | 0.75x | -13.6% |
| 36m | 67.8% | 71.5% | 0.74x | -9.5% |
| 60m | 87.3% | 89.6% | 0.73x | -6.1% |

Two readings, both uncomfortable:

* A holder who bought 24 months ago and rode the observed rate is ahead of cash
  only until prices fall **48.7%** from
  here, and ahead of their own cost basis only until they fall
  **52.8%**. For scale: the index rose
  **3.90x** over the 32 months measured, so
  the erasing fall is roughly
  65% of the gain -- it does
  not require prices to return to where they started. Whether a fall of that
  size is likely is not a question this archive can answer; it has never
  observed one.
* If prices merely stop rising -- no crash, just flat -- the frictions are still
  charged. A flat 12-month hold returns
  **0.75x**, i.e.
  -24.8%/yr. Flat is not break-even. Flat is a
  25% loss.

The HAC confidence interval on the gross trend
(25.5% to 121.4%)
is *sampling* uncertainty within the boom. It is not, and must not be read as, a
range of outcomes for the next two years.

## 7. How long to hold -- what the data can and cannot support

The answer splits in two, and the halves have very different evidential status.

**Supportable, but conditional on a growth assumption.** There is a *minimum*
hold below which the one-time toll cannot be recovered. At the observed gross rate and the median box price, net proceeds first clear the cash hurdle at **7 months**; at 6 months and below the position still loses to cash even while the price rises.

This figure was previously published as regime-independent arithmetic. That was
wrong. The floor is computed by compounding an ASSUMED forward growth rate
against the fee schedule, and the rate used is the one this window happened to
deliver, which is a boom rate. The fee schedule is regime-independent; the floor
it implies is not. Across assumed rates, on the same median box:

| Assumed growth %/yr | Minimum hold (months) | This window's rate? |
| --- | --- | --- |
| 0.0 | never |  |
| 5.0 | never |  |
| 10.0 | 64 |  |
| 20.0 | 24 |  |
| 40.0 | 11 |  |
| 66.7 | 7 | yes |

Read that as the honest form of the claim: at the observed rate the floor is
short, at a tenth of that rate it is years, and below roughly the hurdle rate no
holding period clears the costs at all. Nothing in this archive observes a
non-boom regime, so no row below the observed rate is evidence about the future
either. It is arithmetic under an assumption, shown across assumptions.

The floor is not the same for every box, because shipping and the flat
processing charge do not scale with price:

| Box price percentile | Price | Minimum hold |
| --- | --- | --- |
| p10 | $120.09 | 8 months |
| p50 | $211.22 | 7 months |
| p90 | $1,181.10 | 6 months |

**Not supportable (regime-dependent).** The best observed horizon was 24 months at 65.4%/yr net, but 1 non-overlapping window(s) of that length exist in a 32-month archive. **That is one draw. It is an anecdote, not an estimate, and this study declines to turn it into a holding-period recommendation.**

A 32-month archive holds at most
2 non-overlapping one-year windows and
1 non-overlapping two-year window. Any statement of the
form "hold N years" therefore requires either a longer history than exists or an
assumption about the regime that this project has no grounds to make. **The
honest answer to "how long should I hold?" is: at least 7 months for fee reasons, and beyond that the data does not know.**

## 8. Which assumption owns the answer

Each knob moved alone, at a 24-month hold, 66.7%/yr gross,
$211.22 box. The range column is how many annualised
percentage points that one assumption is worth.

| Assumption | Worst | Best | Range (pp) |
| --- | --- | --- | --- |
| marketplace take rate % | 41.5% | 58.7% | 17.2 |
| seller undercut % | 36.1% | 48.0% | 11.9 |
| capital gains % | 36.3% | 48.0% | 11.7 |
| sales tax % | 46.3% | 53.4% | 7.1 |
| outbound shipping $ | 46.0% | 49.7% | 3.7 |
| storage $/month | 44.7% | 48.3% | 3.6 |
| risk-free %/yr | 48.0% | 48.0% | 0.0 |

The headline net rate keeps its sign under every one of these at a 24-month hold -- the worst cell is still 36.1%/yr. At a 6-month hold the same knobs move the answer across zero (-30.5% to 30.9%/yr), so at short horizons the verdict is an assumption, not a measurement. Note that the risk-free rate moves the net return by
exactly zero points -- it is the hurdle, not a cost, so it changes the verdict
without changing the return.

## 9. Limits

1. **33 monthly observations, one regime**
   (2024-03..2026-11). The archive starts where tcgcsv's
   does. eBay and PriceCharting could extend it and are excluded on
   terms-of-service grounds, so there is no legitimate way to see a bust here.
   Every probability in section 4 is conditional on a boom.
2. **Overlapping windows.** 42,334 holding periods, but at most
   2 non-overlapping years. Intervals are
   product-clustered bootstraps, which handle the within-product dependence and
   do nothing at all about the shared-regime dependence.
3. **Market price is not a fill.** TCGplayer's market price is an average of
   recent sales, not a quote you can hit. Section 2 shows the listing book does
   not support a large spread assumption, but it also cannot prove one is absent.
4. **No liquidity or time-to-sale modelling.** A box that takes four months to
   sell has a longer real holding period than the one priced here, and the
   archive carries no volume data to estimate that.
5. **No condition risk.** Shelf wear, crushed corners, humidity and the
   possibility that a "sealed" box is not are all real and all unpriced.
6. **Taxes are jurisdictional.** 7.5% purchase tax
   and 28.0% collectibles gains are US assumptions.
7. **Survivorship in the panel itself.** Products delisted mid-window leave the
   sample. Which way that biases these rates depends on what those products were
   doing when they left, which the index study measures (etb_summary.md
   section 3.3) rather than this one assuming it.
8. **This is measurement, not investment advice.** It describes what happened to
   a set of prices in a 32-month window and what a stated cost model would have
   done to a holder of them. It is not a recommendation to buy, hold or sell
   anything.
