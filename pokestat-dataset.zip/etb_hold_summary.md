# Is an Elite Trainer Box Worth Holding?

Turning the ETB price series into the money a person would actually have kept.
Everything here is computed live from `data/output/etb_panel.csv` and the cost
constants in `pokestat/model/etb_hold.py`; no number in this document is
hardcoded.

Window **2024-03 .. 2026-09** (31 monthly observations, one regime) |
**109 products** | **36,913 realised holding periods**
| gross index **74.4%/yr** | net at 12 months
**35.8%/yr**

## Bottom line, in plain language

**Over 2024-03 to 2026-09, Elite Trainer Boxes
went up a lot -- about 74.4% a year as a price index. A person who bought one and sold it did not keep that.** After sales tax on the way in, the marketplace's cut on the way
out, and shipping a heavy box, a 12-month hold at that rate netted about
35.8% a year and a 24-month hold about 55.1% a year. The gap is
roughly 39 points a year at one year and 19 at two,
and it shrinks with time only because the costs are charged once.

Five things this archive showed, in order of how confident the data lets us be.
They describe what happened in the sample; none of them is a recommendation:

1. **Short holds lost money even in a rising market.** The costs are a one-time
   toll of roughly
   20% plus about
   $12.
   In this archive 80% of 3-month holds lost money *while
   prices were rising*. You need roughly **7 months** just to clear the fees and beat cash. The cost model is
   regime-independent; the floor it implies is not, because the floor
   compounds an assumed forward growth rate against those costs. See the
   growth sensitivity in section 7.
2. **New releases underperformed retired product here.** Boxes bought within 6 months of release and held a year lost money 14% of the time in this sample, against 5% for product already retired 1-3 years. That is what the archive contains, not a rule: it is a pattern observed inside one boom, and the out-of-print mechanism behind it is not separately testable with this data (etb_summary.md section 4.5).
3. **One box is not the index.** The middle 50% of single-box 12-month outcomes
   spans about 70 annualised points, and 9% of
   one-year holds still lost money. The index number tells you nothing about
   which box you own.
4. **Flat is not break-even.** If ETB prices simply stop rising, a 12-month hold
   returns 0.75x -- a real loss, because the frictions are charged
   anyway. Prices have to keep rising for this to work.
5. **Everything above happened in one market.** Prices falling 53.2%
   from here would erase the entire edge over a savings account for someone two
   years in. Nothing in this data says whether that will happen; the archive has
   never observed a down market.

**So: was an ETB worth holding over this window? On the realised numbers, yes -- for holds longer than about 7 months, on retired rather than newly released product, in a market that kept rising, which it did throughout. Is that a reason to expect the same from here? This data cannot say. It contains no falling market at all, and section 6 quantifies exactly what size of fall would erase the edge.**

*This is measurement, not investment advice.*

---

## 1. What comes out before you see a dollar

Every number is a named constant in `pokestat/model/etb_hold.py`, not a value
inlined into a formula, and every one is swept in section 8.

| Friction | Assumption | Charged |
| --- | --- | --- |
| TCGplayer commission | 10.25% of sale | once, on sale |
| Payment processing | 2.5% + $0.30 | once, on sale |
| Sales tax at purchase | 7.5% | once, on purchase |
| Outbound shipping (2.5 lb, 12x10x4 in) | $12.00 | once, on sale |
| Storage | $0.10/month | monthly |
| Seller undercut below cheapest ask | 0.0% | once, on sale |
| Risk-free alternative (the hurdle) | 4.5%/yr | continuous |
| Collectibles capital gains | 28.0% | shown separately |

The marketplace take is **12.75% + $0.30**
and the purchase tax is **7.5%**, so the round trip carries a
one-time toll of roughly **20.2% of the
box price plus $12.30 of fixed
cost** before a single day of holding. The risk-free rate is a *stated
assumption*, not fetched: this project's permitted sources carry card prices and
FX rates, not Treasury yields.

Capital gains is shown as its own layer rather than folded into the headline.
At 28.0% it is larger than every transaction cost here
combined: a 24-month hold nets 55.1%/yr
before it and 41.9%/yr after.

## 2. The bid-ask assumption does not survive contact with the data

**This study was commissioned on the premise of a "~15-20% bid-ask on thin
sealed listings". The archive does not support that number, and the obvious way
of computing it is badly wrong.**

`price_history` carries a *listing* book -- `low` is the cheapest ask, `high` is
the dearest ask, `mid` is the midpoint of those two. There is no bid anywhere in
it. Treating `high - low` as a spread gives a median of
**206% of the market price** for
ETBs, because `high` is whatever the most optimistic listing on the site says --
its median is **3.07x** the market price and its
99th percentile is **59x**. Any friction model
built on that column would be fiction.

What is measurable is the cheapest ask against TCGplayer's market price, which
is an average of recent *actual sales*:

* median `low / market` = **0.979**
  (10th-90th percentile 0.87-1.29);
* that ratio drifted from **0.960** in
  2024-03 to **0.966** in
  2026-09, i.e. it is close to stationary;
* across 109 products, a round trip executed at `low` on
  **both** ends returned a median **1.049x**
  what the same round trip at `market` returned, and only
  **33%** of products did worse that way.

So the measurable part of the spread very nearly cancels over a round trip. The default `SELLER_UNDERCUT_PCT` is therefore set to the value the
book supports -- zero -- and swept to 15% in section 8, because "not measurable"
is not "zero". What the data says the holder actually loses is **fees, sales tax
and shipping**, not spread.

## 3. Gross versus net -- the gap is the point

The ETB price index over 2024-03..2026-09 grew
**74.4%/yr** gross (HAC 95% CI
32.6% to 129.4%, t = 3.98). Nobody
earns that. Holding one box at that same gross rate, on the median
2026-09 ETB price of **$218.32**:

| Hold | Gross x | Net x | Gross %/yr | Net %/yr | Drag pp | Gross %/yr needed to beat cash | In archive? |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3m | 1.15x | 0.88x | 74.4% | -40.3% | 114.7 | 196.2% | yes |
| 6m | 1.32x | 1.02x | 74.4% | 3.4% | 71.0 | 76.2% | yes |
| 12m | 1.74x | 1.36x | 74.4% | 35.8% | 38.6 | 35.8% | yes |
| 18m | 2.30x | 1.81x | 74.4% | 48.5% | 25.9 | 24.6% | yes |
| 24m | 3.04x | 2.41x | 74.4% | 55.1% | 19.3 | 19.3% | yes |
| 36m | 5.31x | 4.24x | 74.4% | 61.8% | 12.6 | 14.2% | extrapolated |
| 60m | 16.15x | 13.03x | 74.4% | 67.1% | 7.3 | 10.3% | extrapolated |

Read the last column first. To merely beat cash, a box bought and flipped in
3 months has to appreciate **196.2%/yr**
gross. Over 12 months the bar falls to 35.8%/yr
and over 24 months to 19.3%/yr. Nothing about
the market changed between those rows -- only the number of months the same
one-time toll is spread across.

That is why the drag column collapses from **114.7 points
a year** at 3 months to **19.3 points** at 24. The
friction is a toll, not a tax rate. It is the strongest argument in this entire
study for holding rather than flipping -- and, unlike everything downstream of
it, it is arithmetic and does not depend on the boom continuing.

## 4. What one buyer actually faced

36,913 realised holding periods across 109 products.
**These are overlapping windows and must not be read as 36,913
observations** -- the archive spans 30 months, so the
`indep.` column counts how many genuinely non-overlapping holds of that length
exist in it. All figures are net of the section 1 frictions.

| Hold | Products | Indep. windows | Net x p05 | Net x median | Net x p95 | Net %/yr median | Net %/yr (equal-wt) | P(lose money) | P(worse than cash) | %/yr usable? |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 3m | 107 | 10 | 0.54x | 0.83x | 1.25x | -51.9% | -52.8% | 80% | 81% | **no** |
| 6m | 103 | 5 | 0.61x | 1.01x | 1.64x | 1.9% | 1.2% | 49% | 52% | **no** |
| 12m | 93 | 2 | 0.91x | 1.46x | 2.84x | 45.5% | 47.3% | 9% | 12% | yes |
| 18m | 84 | 1 | 1.34x | 2.17x | 4.75x | 67.5% | 65.1% | 0% | 1% | yes |
| 24m | 76 | 1 | 1.61x | 2.72x | 6.91x | 64.9% | 63.0% | 0% | 0% | yes |

Where the last column says no, the hold is shorter than
12 months and the `%/yr` figures are exponentiation
artefacts (a 3-month -17% becomes "-52%/yr"). For those rows read the multiple
columns; this is the same gate `etb_core` applies to per-product trends.

A 3-month flip lost money **80% of the time** and had a median net outcome of 0.83x -- against a median 3-month GROSS move of 1.14x. At 6 months 49% of holds still ended below cost. By 12 months the median hold returned 1.46x net with 9% losing, and the product-clustered bootstrap puts the median 12-month net rate at 45.5%/yr, 95% CI 38.8% to 54.6% across 93 products.

**Every one of those probabilities is a frequency inside a rising market.** The
reason short holds lost money is arithmetic and will repeat in any regime; the
reason long holds did not is that prices rose, and that will not.

### Why this table disagrees with section 3

Section 3 says a 12-month hold nets 35.8%/yr; this one says
45.5%/yr. Both are right and they measure different things. Section 3
applies the chained index's 74.4%/yr uniformly. The
realised 12-month holds in this table had a median GROSS move of
1.99x, i.e. 99.4%. Two construction
differences separate them: pooling every (product, month, month) triple
over-weights products with long histories, and a uniform index rate spreads the
growth evenly over a window that did not grow evenly. **Take section 3's number
as the one attached to a defensible index and this section's spread as the one
attached to a real buyer's experience.** The disagreement is a composition
effect, not a defect. The gap, 9.7 points, is 25% of the 38.6-point twelve-month friction drag -- a warning about how much of any of these numbers is a construction choice.

### The concentration you take on by buying one box

| Hold | One box net x p10 | median | p90 | Whole-basket net x | One box IQR (pp/yr) | P(one box < basket) | P(one box loses money) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 3m | 0.62x | 0.83x | 1.11x | 0.85x | 57 | 51% | 80% |
| 6m | 0.69x | 1.01x | 1.47x | 1.02x | 78 | 49% | 49% |
| 12m | 1.02x | 1.46x | 2.46x | 1.46x | 70 | 50% | 9% |
| 18m | 1.45x | 2.17x | 3.92x | 2.17x | 59 | 49% | 0% |
| 24m | 1.81x | 2.72x | 5.51x | 2.81x | 48 | 51% | 0% |

A single box carries a 70-point interquartile range at 12 months where the basket has one outcome per (buy, sell) pair. The median single box also trailed the basket, so concentration cost the median holder outright and not merely in variance. The decision-relevant number is that 50% of single-box picks did worse than simply owning the average.

| Product | Bought | Sold | Held | Gross x | Net x |
| --- | --- | --- | --- | --- | --- |
| Surging Sparks Elite Trainer Box | 2025-01 | 2026-01 | 12m | 0.94x | 0.59x |
| Surging Sparks Elite Trainer Box | 2025-02 | 2026-02 | 12m | 0.92x | 0.59x |
| Shrouded Fable Pokemon Center Elite Trainer Box (Exclusive) | 2024-09 | 2026-02 | 17m | 0.86x | 0.61x |
| Shrouded Fable Pokemon Center Elite Trainer Box (Exclusive) | 2024-09 | 2025-09 | 12m | 0.86x | 0.61x |
| Shrouded Fable Pokemon Center Elite Trainer Box (Exclusive) | 2024-09 | 2026-01 | 16m | 0.87x | 0.62x |
| Surging Sparks Elite Trainer Box | 2024-12 | 2026-01 | 13m | 1.00x | 0.63x |

## 5. When you buy -- what the age cut does and does not establish

**The index study does NOT establish that the gains belong to out-of-print product.** Of the 2 cohort contrasts against the "0-12m old at entry" reference, 0 clears the study's bar of t = 2.0. The one a buyer of out-of-print product would quote -- the "1-3y old at entry" cohort's chained index running **12.0pp/yr** above the reference -- carries **t = 1.22**, which does not clear it. This was published here as an established finding after it had been retracted; see `etb_corrections.csv`. What follows repeats the cut on NET HOLDER OUTCOMES, which is a different question from the index contrast and is a description of this window, not an age effect.

Split by how old the set was **at purchase**:

| Bought | Held | Products | Net x median | Net %/yr | P(lose money) |
| --- | --- | --- | --- | --- | --- |
| bought 0-6m after release | 12m | 28 | 1.29x | 29.2% | 14% |
| bought 0-6m after release | 24m | 14 | 2.19x | 47.8% | 2% |
| bought 6-12m after release | 12m | 28 | 1.52x | 52.0% | 11% |
| bought 6-12m after release | 24m | 16 | 4.83x | 119.8% | 0% |
| bought 1-3y after release | 12m | 48 | 1.59x | 59.1% | 5% |
| bought 1-3y after release | 24m | 32 | 3.47x | 86.3% | 0% |
| bought 3y+ after release | 12m | 52 | 1.40x | 39.7% | 10% |
| bought 3y+ after release | 24m | 38 | 2.32x | 52.2% | 0% |

A box bought within 6 months of its set's release and held a year lost money **14%** of the time and returned a median 29.2%/yr net. The same hold on a box already 1-3 years past release lost money **5%** of the time at 59.1%/yr net.

This is the cut a prospective buyer is actually in. Current-release ETBs sit in the 0-6m bucket, and at a 12-month hold it is the worst one in the table -- during a boom.

The mechanism is measurable, and the baseline it is measured from is the whole
finding. Of the 36 products with an observed first
ON-SALE price -- the first monthly snapshot dated on or after street date -- the
median trough over the following 6 months sat
**13.3% below** it
(IQR 3.4% to 22.0%),
reached a median 2 months later, and
**22%** of them fell at least
25%. Because a trough is a minimum, that
statistic is selection-prone; the drop measured at a fixed
6-month endpoint instead, which is not, has a
median of **-0.8%** -- so
the typical box was above its first on-sale price at that endpoint.

**This corrects a figure this study previously published.** The same statistic measured from each product's first LISTED quote gives 49.0% at the trough and 44.7% at the endpoint, across 38 products -- a gap of 35.6 points on the median (product-bootstrap 95% CI 16.4 to 43.6), and a change of SIGN at the endpoint. That is the number this report used to carry. It was wrong: `price_history` is snapshotted on the 1st and essentially no set ships on the 1st, so a product's first listed quote is normally a pre-order ask on a box that has not shipped -- no longer part of the panel, and read back from `presale_quotes.csv` for this comparison only -- and the old figure was largely that ask deflating rather than a box losing value. Both arms are computed (first on-sale price vs first listed price) so the comparison is auditable rather than asserted. A buyer who paid the pre-order price ate the difference either way.

## 6. What a different regime does to all of it

Nothing above observes a falling market. The archive is
31 monthly points inside one boom. What can be computed is how
much of the observed gain has to be given back before the answer flips.

| Hold | Fall that erases the edge over cash | Fall that turns it into a loss | Net x if prices go flat | Net %/yr if flat |
| --- | --- | --- | --- | --- |
| 3m | n/a | n/a | 0.76x | -67.0% |
| 6m | n/a | 1.6% | 0.76x | -42.7% |
| 12m | 22.1% | 25.3% | 0.75x | -24.6% |
| 18m | 39.7% | 43.3% | 0.75x | -17.3% |
| 24m | 53.2% | 57.0% | 0.75x | -13.5% |
| 36m | 71.9% | 75.2% | 0.74x | -9.4% |
| 60m | 89.9% | 91.8% | 0.73x | -6.0% |

Two readings, both uncomfortable:

* A holder who bought 24 months ago and rode the observed rate is ahead of cash
  only until prices fall **53.2%** from
  here, and ahead of their own cost basis only until they fall
  **57.0%**. For scale: the index rose
  **4.02x** over the 30 months measured, so
  the erasing fall is roughly
  71% of the gain -- it does
  not require prices to return to where they started. Whether a fall of that
  size is likely is not a question this archive can answer; it has never
  observed one.
* If prices merely stop rising -- no crash, just flat -- the frictions are still
  charged. A flat 12-month hold returns
  **0.75x**, i.e.
  -24.6%/yr. Flat is not break-even. Flat is a
  25% loss.

The HAC confidence interval on the gross trend
(32.6% to 129.4%)
is *sampling* uncertainty within the boom. It is not, and must not be read as, a
range of outcomes for the next two years.

## 7. How long to hold -- what the data can and cannot support

The answer splits in two, and the halves have very different evidential status.

**Supportable, but conditional on a growth assumption.** There is a *minimum*
hold below which the one-time toll cannot be recovered. At the observed gross rate and the median box price, net proceeds first clear the cash hurdle at **7 months**; at 6 months and below the position still loses to cash even while the price rises.

This figure was previously published as regime-independent arithmetic. That was
wrong. The floor is computed by compounding an ASSUMED forward growth rate
against the fee schedule, and the rate used is the one this window happened to
deliver, which is a boom rate. The fee schedule is regime-independent; the floor
it implies is not. Across assumed rates, on the same median box:

| Assumed growth %/yr | Minimum hold (months) | This window's rate? |
| --- | --- | --- |
| 0.0 | never |  |
| 5.0 | never |  |
| 10.0 | 64 |  |
| 20.0 | 23 |  |
| 40.0 | 11 |  |
| 74.4 | 7 | yes |

Read that as the honest form of the claim: at the observed rate the floor is
short, at a tenth of that rate it is years, and below roughly the hurdle rate no
holding period clears the costs at all. Nothing in this archive observes a
non-boom regime, so no row below the observed rate is evidence about the future
either. It is arithmetic under an assumption, shown across assumptions.

The floor is not the same for every box, because shipping and the flat
processing charge do not scale with price:

| Box price percentile | Price | Minimum hold |
| --- | --- | --- |
| p10 | $124.58 | 8 months |
| p50 | $218.32 | 7 months |
| p90 | $1,078.66 | 6 months |

**Not supportable (regime-dependent).** The best observed horizon was 18 months at 67.5%/yr net, but 1 non-overlapping window(s) of that length exist in a 30-month archive. **That is one draw. It is an anecdote, not an estimate, and this study declines to turn it into a holding-period recommendation.**

A 30-month archive holds at most
2 non-overlapping one-year windows and
1 non-overlapping two-year window. Any statement of the
form "hold N years" therefore requires either a longer history than exists or an
assumption about the regime that this project has no grounds to make. **The
honest answer to "how long should I hold?" is: at least 7 months for fee reasons, and beyond that the data does not know.**

## 8. Which assumption owns the answer

Each knob moved alone, at a 24-month hold, 74.4%/yr gross,
$218.32 box. The range column is how many annualised
percentage points that one assumption is worth.

| Assumption | Worst | Best | Range (pp) |
| --- | --- | --- | --- |
| marketplace take rate % | 48.4% | 66.4% | 18.0 |
| capital gains % | 41.9% | 55.1% | 13.3 |
| seller undercut % | 42.7% | 55.1% | 12.4 |
| sales tax % | 53.4% | 60.9% | 7.5 |
| outbound shipping $ | 53.3% | 56.8% | 3.4 |
| storage $/month | 52.1% | 55.5% | 3.3 |
| risk-free %/yr | 55.1% | 55.1% | 0.0 |

The headline net rate keeps its sign under every one of these at a 24-month hold -- the worst cell is still 41.9%/yr. At a 6-month hold the same knobs move the answer across zero (-26.7% to 37.7%/yr), so at short horizons the verdict is an assumption, not a measurement. Note that the risk-free rate moves the net return by
exactly zero points -- it is the hurdle, not a cost, so it changes the verdict
without changing the return.

## 9. Limits

1. **31 monthly observations, one regime**
   (2024-03..2026-09). The archive starts where tcgcsv's
   does. eBay and PriceCharting could extend it and are excluded on
   terms-of-service grounds, so there is no legitimate way to see a bust here.
   Every probability in section 4 is conditional on a boom.
2. **Overlapping windows.** 36,913 holding periods, but at most
   2 non-overlapping years. Intervals are
   product-clustered bootstraps, which handle the within-product dependence and
   do nothing at all about the shared-regime dependence.
3. **Market price is not a fill.** TCGplayer's market price is an average of
   recent sales, not a quote you can hit. Section 2 shows the listing book does
   not support a large spread assumption, but it also cannot prove one is absent.
4. **No liquidity or time-to-sale modelling.** A box that takes four months to
   sell has a longer real holding period than the one priced here, and the
   archive carries no volume data to estimate that.
5. **No condition risk.** Shelf wear, crushed corners, humidity and the
   possibility that a "sealed" box is not are all real and all unpriced.
6. **Taxes are jurisdictional.** 7.5% purchase tax
   and 28.0% collectibles gains are US assumptions.
7. **Survivorship in the panel itself.** Products delisted mid-window leave the
   sample. Which way that biases these rates depends on what those products were
   doing when they left, which the index study measures (etb_summary.md
   section 3.3) rather than this one assuming it.
8. **This is measurement, not investment advice.** It describes what happened to
   a set of prices in a 30-month window and what a stated cost model would have
   done to a holder of them. It is not a recommendation to buy, hold or sell
   anything.
