# Model comparison: does anything beat the OLS log-log baseline?

n = 441 chase cards. All models predict log(price). Every
model below is scored on identical repeated K-fold splits (5 folds x
20 repeats, seeded once and shared across every row).

## Caveats

- n=441: tree-model hyperparameters are fixed a priori (shallow trees, min_samples_leaf>=5) rather than tuned, since a search on 441 points would overfit the CV itself.
- The '+set_id' tree variants add 20 per-set dummies/leaves and can leak set-level price levels into the score; compare them against the no-set_id row before trusting any lift.

## Comparison table

| model | features | cv_r2_mean | cv_r2_std | loocv_r2 |
| --- | --- | --- | --- | --- |
| OLS baseline (2 features) | log_pull_cost, desirability | 0.597 | 0.003 | 0.598 |
| OLS extended | log_pull_cost, premium_10, artwork, appeal_10, set_age_days, rarity_Mega Hyper Rare, rarity_Rare Rainbow, rarity_Rare Secret, rarity_Rare Ultra, rarity_Special Illustration Rare, rarity_Ultra Rare, gen_gen2, gen_gen3, gen_gen4, gen_gen5, gen_gen6, gen_gen7, gen_gen8, gen_gen9 | 0.774 | 0.004 | 0.776 |
| RidgeCV extended | log_pull_cost, premium_10, artwork, appeal_10, set_age_days, rarity_Mega Hyper Rare, rarity_Rare Rainbow, rarity_Rare Secret, rarity_Rare Ultra, rarity_Special Illustration Rare, rarity_Ultra Rare, gen_gen2, gen_gen3, gen_gen4, gen_gen5, gen_gen6, gen_gen7, gen_gen8, gen_gen9 | 0.774 | 0.004 | n/a |
| LassoCV extended | log_pull_cost, premium_10, artwork, appeal_10, set_age_days, rarity_Mega Hyper Rare, rarity_Rare Rainbow, rarity_Rare Secret, rarity_Rare Ultra, rarity_Special Illustration Rare, rarity_Ultra Rare, gen_gen2, gen_gen3, gen_gen4, gen_gen5, gen_gen6, gen_gen7, gen_gen8, gen_gen9 | 0.771 | 0.003 | n/a |
| HistGradientBoosting extended (no set_id) | log_pull_cost, premium_10, artwork, appeal_10, set_age_days, rarity_Mega Hyper Rare, rarity_Rare Rainbow, rarity_Rare Secret, rarity_Rare Ultra, rarity_Special Illustration Rare, rarity_Ultra Rare, gen_gen2, gen_gen3, gen_gen4, gen_gen5, gen_gen6, gen_gen7, gen_gen8, gen_gen9 | 0.777 | 0.007 | n/a |
| HistGradientBoosting extended (+set_id, leakage risk) | log_pull_cost, premium_10, artwork, appeal_10, set_age_days, rarity_Mega Hyper Rare, rarity_Rare Rainbow, rarity_Rare Secret, rarity_Rare Ultra, rarity_Special Illustration Rare, rarity_Ultra Rare, gen_gen2, gen_gen3, gen_gen4, gen_gen5, gen_gen6, gen_gen7, gen_gen8, gen_gen9, set_id_me2, set_id_sv1, set_id_sv10, set_id_sv3, set_id_sv3pt5, set_id_sv4, set_id_sv4pt5, set_id_sv5, set_id_sv6, set_id_sv6pt5, set_id_sv7, set_id_sv8, set_id_sv8pt5, set_id_sv9, set_id_swsh10, set_id_swsh11, set_id_swsh12, set_id_swsh12pt5, set_id_swsh7, set_id_swsh9 | 0.777 | 0.007 | n/a |
| RandomForest extended (no set_id) | log_pull_cost, premium_10, artwork, appeal_10, set_age_days, rarity_Mega Hyper Rare, rarity_Rare Rainbow, rarity_Rare Secret, rarity_Rare Ultra, rarity_Special Illustration Rare, rarity_Ultra Rare, gen_gen2, gen_gen3, gen_gen4, gen_gen5, gen_gen6, gen_gen7, gen_gen8, gen_gen9 | 0.759 | 0.007 | n/a |
| RandomForest extended (+set_id, leakage risk) | log_pull_cost, premium_10, artwork, appeal_10, set_age_days, rarity_Mega Hyper Rare, rarity_Rare Rainbow, rarity_Rare Secret, rarity_Rare Ultra, rarity_Special Illustration Rare, rarity_Ultra Rare, gen_gen2, gen_gen3, gen_gen4, gen_gen5, gen_gen6, gen_gen7, gen_gen8, gen_gen9, set_id_me2, set_id_sv1, set_id_sv10, set_id_sv3, set_id_sv3pt5, set_id_sv4, set_id_sv4pt5, set_id_sv5, set_id_sv6, set_id_sv6pt5, set_id_sv7, set_id_sv8, set_id_sv8pt5, set_id_sv9, set_id_swsh10, set_id_swsh11, set_id_swsh12, set_id_swsh12pt5, set_id_swsh7, set_id_swsh9 | 0.758 | 0.007 | n/a |

cv_r2_mean/cv_r2_std: mean/std of out-of-fold R2 across the 20 repeats
(each repeat's R2 is computed on that repeat's full out-of-fold prediction
vector). loocv_r2: leave-one-out CV R2, reported only for the two OLS
variants ("n/a" otherwise).

## Best model: HistGradientBoosting extended (+set_id, leakage risk)

Permutation importance (full-fit, not out-of-fold -- see interpretation below):

- premium_10: 0.5606 +/- 0.0382
- rarity_Special Illustration Rare: 0.1726 +/- 0.0130
- rarity_Ultra Rare: 0.1393 +/- 0.0111
- log_pull_cost: 0.0759 +/- 0.0071
- artwork: 0.0358 +/- 0.0047
- appeal_10: 0.0205 +/- 0.0029
- set_age_days: 0.0180 +/- 0.0029
- rarity_Rare Ultra: 0.0068 +/- 0.0009

## Lasso coefficients (standardized extended features)

- log_pull_cost: 0.2659
- premium_10: 0.8339
- artwork: 0.0792
- appeal_10: 0.0707
- set_age_days: 0.0000
- rarity_Mega Hyper Rare: 0.1043
- rarity_Rare Rainbow: -0.0000
- rarity_Rare Secret: -0.0271
- rarity_Rare Ultra: -0.0777
- rarity_Special Illustration Rare: 0.5330
- rarity_Ultra Rare: -0.3686
- gen_gen2: -0.0000
- gen_gen3: -0.0019
- gen_gen4: -0.0000
- gen_gen5: -0.0704
- gen_gen6: 0.0000
- gen_gen7: -0.0000
- gen_gen8: -0.0000
- gen_gen9: 0.0000

## Quantile regression (tau=0.5) robustness check

Baseline 2-feature spec, median regression pseudo-R2 (Koenker-Machado):
0.3630. Not directly comparable to the OLS R2
above; reported separately as requested.

## Interpretation

1. Baseline OLS (log_pull_cost, desirability) scores 0.597 +/- 0.003 out-of-fold R2 across 5x20 repeated folds, close to its 0.598 LOOCV figure.
2. HistGradientBoosting extended (+set_id, leakage risk) beats baseline by +0.181 cv_r2_mean, larger than either model's own fold-to-fold standard deviation, a real if modest edge.
3. Lasso keeps 11 of 19 extended features nonzero and zeroes out set_age_days, rarity_Rare Rainbow, gen_gen2, gen_gen4, gen_gen6, gen_gen7, gen_gen8, gen_gen9.
4. Permutation importance on the full-fit best model ranks premium_10, rarity_Special Illustration Rare, rarity_Ultra Rare, log_pull_cost, artwork highest; this is a full-data fit, not out-of-fold, so treat the ranking as directional.
5. Ridge and Lasso pick their penalty strength via their own built-in CV only; no external hyperparameter search was run given n=135.
6. Tree models (HistGradientBoosting, RandomForest) use fixed shallow hyperparameters; 135 rows is not enough to tune them without overfitting the validation split itself.
7. The '+set_id' tree variants add per-set dummies/codes and can leak set-level price levels into the score; their rows should be read as an upper bound, not a fair model.
8. The 3 sub-components of desirability (character premium, artwork, appeal) replace the fixed 45/45/10 composite in every extended model, to let the data reweight them.
9. Median (tau=0.5) quantile regression on the baseline spec gives a pseudo-R2 of 0.363, a separate robustness check, not comparable directly to the OLS R2 above.
10. Overall: HistGradientBoosting extended (+set_id, leakage risk) reliably beats the two-feature baseline here, but the gain traces to the added features (rarity, character premium) rather than to nonlinearity, since plain extended OLS scores within noise of Ridge/Lasso/trees.
