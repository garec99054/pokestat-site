# Prediction scorecard

Forecast history scored at the three-calendar-month endpoint using market-relative log returns. The history can include later revisions and does not establish a record of first-issued predictions.

| outlook date | n | n realized | Spearman IC | band coverage | scored on |
| --- | --- | --- | --- | --- | --- |
| 2026-07-01 | 441 | 441 | 0.309 | 77.3% | 2026-10-01 |
| 2026-08-01 | 465 | 465 | 0.382 | 72.0% | 2026-11-01 |
| 2026-09-01 | 478 | 0 | pending | pending | not yet, eligible 2026-12-01 |
| 2026-10-01 | 478 | 0 | pending | pending | not yet, eligible 2027-01-01 |

As of 2026-11-09, 2 outlook date(s) have been scored against realized prices. 956 more forecasts across 2 outlook dates are waiting for prices at their three-month endpoint; the next eligible date is 2026-12-01.
