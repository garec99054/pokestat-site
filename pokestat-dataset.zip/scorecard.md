# Prediction scorecard

Every 90 day forward return prediction this site has published, scored once its window actually closes against realized prices.

| outlook date | n | n realized | Spearman IC | band coverage | scored on |
| --- | --- | --- | --- | --- | --- |
| 2026-07-01 | 441 | 0 | pending | pending | not yet, eligible 2026-10-01 |
| 2026-08-01 | 465 | 0 | pending | pending | not yet, eligible 2026-11-01 |
| 2026-09-01 | 478 | 0 | pending | pending | not yet, eligible 2026-12-01 |

As of 2026-09-08, none of the predictions this site has published have reached their 90 day forward window yet. 1384 forecasts across 3 outlook dates are waiting, and the earliest is scored on 2026-10-01.
