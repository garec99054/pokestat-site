# Prediction scorecard

Every 90 day forward return prediction this site has published, scored once its window actually closes against realized prices.

| outlook date | n | n realized | Spearman IC | band coverage | scored on |
| --- | --- | --- | --- | --- | --- |
| 2026-07-01 | 441 | 441 | 0.314 | 82.5% | 2026-10-01 |
| 2026-08-01 | 465 | 0 | pending | pending | not yet, eligible 2026-11-01 |
| 2026-09-01 | 478 | 0 | pending | pending | not yet, eligible 2026-12-01 |

As of 2026-10-03, 1 outlook date(s) have been scored against realized prices. 943 more forecasts across 2 outlook dates have not reached 90 days yet; the next is scored on 2026-11-01.
