# Are ETB prices still going up, and is it broad?

_Window: 2024-03 to 2026-11 (33 monthly observations, one regime). Index construction: chained / geometric / survivorship "all". This is MEASUREMENT, not investment advice._

**Short answer.** Over the trailing 12 months 87.1% of the ETBs priced at both ends of the window rose and the index compounded at 32.0%/yr, but the rise is concentrated rather than broad-based. There is **no detectable stall** -- the last 12 months ran -3.11pp/month against the earlier window (t = -1.36), and the deepest fall inside the window was -4.1% across 6 negative month(s). That rules out a collapse, not a mild slowdown. **ETBs differ from 1 of 6 judgeable benchmark comparisons**, so part of this is ETB-specific.

## 1. Breadth -- how many boxes actually went up

Over the trailing 12 months (2025-11 to 2026-11),
**81 of 93 ETBs priced at both ends of the window rose** (87.1%). The
median box multiplied by 1.38x and the geometric mean by
1.36x; the 10th percentile managed 0.95x and
the worst was 0.84x.

Most products rose, but the bottom decile did not (0.95x at the 10th percentile), so the tail of this distribution is doing something different from its middle.

| Window | From | To | n | Share up | Geo-mean | Median | p10 | p90 | Min | Max |
|---|---|---|---|---|---|---|---|---|---|---|
| trailing 3m | 2026-08 | 2026-11 | 104 | 32.7% | 0.97x | 0.97x | 0.82x | 1.13x | 0.71x | 1.51x |
| trailing 6m | 2026-05 | 2026-11 | 100 | 75.0% | 1.08x | 1.10x | 0.87x | 1.31x | 0.47x | 1.64x |
| trailing 9m | 2026-02 | 2026-11 | 97 | 92.8% | 1.35x | 1.38x | 1.07x | 1.66x | 0.68x | 2.14x |
| trailing 12m | 2025-11 | 2026-11 | 93 | 87.1% | 1.36x | 1.38x | 0.95x | 1.76x | 0.84x | 2.87x |
| full window (32m) | 2024-03 | 2026-11 | 66 | 100.0% | 4.57x | 4.18x | 3.12x | 7.77x | 1.95x | 12.39x |

Each row above uses its own balanced set -- a product only enters a window if it
was priced at BOTH ends of it -- so `n` grows as the window shortens and part of
any difference down the table is composition, not behaviour. Holding membership
exactly fixed instead:

| Window | From | To | n | Share up | Geo-mean | p10 | Min |
|---|---|---|---|---|---|---|---|
| first 12m | 2024-03 | 2025-03 | 63 | 100.0% | 1.80x | 1.14x | 1.04x |
| last 12m | 2025-11 | 2026-11 | 63 | 95.2% | 1.38x | 1.04x | 0.84x |

On the same 63 products, the share rising narrowed from 100.0% to 95.2% -- a change of -4.8pp, which on 63 products is about 3 product(s). Breadth **narrowed** on a fixed cohort -- read it with the product count, since a few boxes move a share on a cohort this size.

**Is the rise concentrated?** Under a perfectly even rise, the top 10% of
products by size of move would account for 10% of the summed log rise.

| Top share of products | n | Share of the summed log rise | Evenness (1.00 = perfectly even) |
|---|---|---|---|
| 10% | 9 | 22.5% | 2.25 |
| 25% | 23 | 47.8% | 1.91 |
| 50% | 46 | 79.9% | 1.60 |

The 12 that did not rise:

| Product | Channel | Start | End | Multiple |
|---|---|---|---|---|
| Scarlet & Violet Pokemon Center Elite Trainer Box (Exclusive) [Koraidon] | Pokemon Center exclusive | $343.92 | $287.26 | 0.84x |
| Mega Evolution Pokemon Center Elite Trainer Box (Exclusive) [Mega Gardevoir] | Pokemon Center exclusive | $219.73 | $191.63 | 0.87x |
| Temporal Forces Pokemon Center Elite Trainer Box (Exclusive) [Walking Wake] | Pokemon Center exclusive | $242.96 | $212.25 | 0.87x |
| Mega Evolution Pokemon Center Elite Trainer Box (Exclusive) [Mega Lucario] | Pokemon Center exclusive | $228.60 | $201.14 | 0.88x |
| Destined Rivals Elite Trainer Box | Mass-retail | $120.37 | $107.31 | 0.89x |
| Surging Sparks Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $271.74 | $245.36 | 0.90x |
| Obsidian Flames Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $679.90 | $614.08 | 0.90x |
| Prismatic Evolutions Elite Trainer Box | Mass-retail | $133.01 | $120.72 | 0.91x |
| Twilight Masquerade Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $196.89 | $185.52 | 0.94x |
| Stellar Crown Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $190.87 | $180.74 | 0.95x |
| Scarlet & Violet Pokemon Center Elite Trainer Box (Exclusive) [Miraidon] | Pokemon Center exclusive | $328.70 | $315.77 | 0.96x |
| Temporal Forces Pokemon Center Elite Trainer Box (Exclusive) [Iron Leaves] | Pokemon Center exclusive | $202.96 | $197.48 | 0.97x |


## 2. Recency -- is it still going, or has it stalled?

This is the section that matters most to someone buying today, because a
whole-window growth rate is mostly made of yesterdays and would hide a recent
stall.

| Window | From | To | Returns | Total | Annualised | 95% lo | 95% hi | t | Interval usable? |
|---|---|---|---|---|---|---|---|---|---|
| trailing 3m | 2026-08 | 2026-11 | 3 | -3.7% | -14.1% | -17.1% | -10.9% | -8.20 | NO -- too few returns |
| trailing 6m | 2026-05 | 2026-11 | 6 | 5.9% | 12.1% | -24.8% | 67.2% | 0.56 | NO -- too few returns |
| trailing 9m | 2026-02 | 2026-11 | 9 | 30.8% | 43.1% | -13.4% | 136.6% | 1.40 | NO -- too few returns |
| trailing 12m | 2025-11 | 2026-11 | 12 | 32.0% | 32.0% | -11.1% | 96.1% | 1.37 | yes |
| full window | 2024-03 | 2026-11 | 32 | 290.4% | 66.7% | 25.5% | 121.4% | 3.52 | yes |

The 3 shortest window(s) above carry a HAC interval computed from fewer than 12 returns. Those intervals are printed because hiding them would be its own distortion, but they are **not usable**: a Newey-West covariance fitted to 3 or 6 observations produces t-statistics that look decisive and are not. Read the trailing-12m and full-window rows; treat the rest as texture.

Formally: regressing the monthly log return on a dummy for the last 12 months, with a Newey-West covariance at 3 lags, the recent months ran 2.34%/month against 5.57%/month before -- a difference of -3.11pp/month with a standard error of 2.28pp (t = -1.36, p = 0.17). That is **no detectable change**. On 12 recent and 20 prior returns this test could only have found a large change, so it is much better evidence against a collapse than against a mild slowdown.

Month by month over the last 12 months (the same matched-model
links the index multiplies up, opened out; "disp." is the spread ACROSS
PRODUCTS within the month, not a confidence interval for the market -- ETBs move
together, so it is far too narrow for that):

| Month | n | Move | disp. lo | disp. hi | Share up |
|---|---|---|---|---|---|
| 2025-12 | 94 | -0.74% | -2.96% | 1.54% | 50% |
| 2026-01 | 97 | -1.12% | -2.42% | 0.21% | 43% |
| 2026-02 | 96 | 2.79% | 1.60% | 3.99% | 68% |
| 2026-03 | 98 | 4.38% | 2.54% | 6.25% | 80% |
| 2026-04 | 100 | 11.49% | 9.39% | 13.63% | 88% |
| 2026-05 | 102 | 6.19% | 4.80% | 7.60% | 82% |
| 2026-06 | 102 | 7.92% | 6.19% | 9.68% | 85% |
| 2026-07 | 103 | 2.29% | 0.95% | 3.65% | 64% |
| 2026-08 | 102 | -0.38% | -1.67% | 0.93% | 48% |
| 2026-09 | 104 | -0.91% | -2.36% | 0.56% | 39% |
| 2026-10 | 104 | -1.46% | -2.36% | -0.55% | 34% |
| 2026-11 | 106 | -1.40% | -2.57% | -0.22% | 37% |

Months the cross-section fell:

| Month | n | Move | Share up |
|---|---|---|---|
| 2024-05 | 72 | -0.14% | 58% |
| 2025-12 | 94 | -0.74% | 50% |
| 2026-01 | 97 | -1.12% | 43% |
| 2026-08 | 102 | -0.38% | 48% |
| 2026-09 | 104 | -0.91% | 39% |
| 2026-10 | 104 | -1.46% | 34% |
| 2026-11 | 106 | -1.40% | 37% |

**Drawdowns.** Over the whole window the worst peak-to-trough fall was
-4.1% (peak 2026-07, trough
2026-11), with 7 negative months out of
32. Inside the trailing 12 months the worst fall was
-4.1% across 6 negative months of
12. The worst single month in the archive was
2026-10 at -1.46%.

A maximum drawdown this shallow after a rise this large is itself a warning: the archive contains no example of this category falling meaningfully, so nothing here estimates how far it can fall.


## 3. Is it ETB-specific, or market-wide?

Same window, same construction (chained / geometric /
survivorship "all"), applied to booster boxes, booster
bundles and singles. The statistic is the PAIRED monthly log-return difference,
so the common market tide cancels before the standard error is formed.

| Window | Benchmark | n | ETB | Benchmark | ETB minus benchmark | t | Reading |
|---|---|---|---|---|---|---|---|
| trailing 3m | Booster boxes | 54 | -14.1% | -5.2% | -9.3pp | -1.05 | window too short to judge |
| trailing 3m | Booster bundles | 27 | -14.1% | -17.2% | +3.7pp | 0.20 | window too short to judge |
| trailing 3m | Singles | 6913 | -14.1% | 16.0% | -25.9pp | -6.05 | window too short to judge |
| trailing 6m | Booster boxes | 54 | 12.1% | 5.5% | +6.2pp | 0.56 | window too short to judge |
| trailing 6m | Booster bundles | 27 | 12.1% | 18.4% | -5.3pp | -0.60 | window too short to judge |
| trailing 6m | Singles | 6913 | 12.1% | 40.0% | -19.9pp | -3.91 | window too short to judge |
| trailing 9m | Booster boxes | 54 | 43.1% | 10.0% | +30.1pp | 1.50 | window too short to judge |
| trailing 9m | Booster bundles | 27 | 43.1% | 53.7% | -6.9pp | -0.99 | window too short to judge |
| trailing 9m | Singles | 6913 | 43.1% | 53.6% | -6.8pp | -0.52 | window too short to judge |
| trailing 12m | Booster boxes | 54 | 32.0% | 18.0% | +11.9pp | 0.68 | no detectable difference |
| trailing 12m | Booster bundles | 27 | 32.0% | 45.4% | -9.2pp | -1.80 | no detectable difference |
| trailing 12m | Singles | 6913 | 32.0% | 44.1% | -8.4pp | -0.86 | no detectable difference |
| full window (32m) | Booster boxes | 54 | 66.7% | 57.2% | +6.0pp | 0.71 | no detectable difference |
| full window (32m) | Booster bundles | 27 | 66.7% | 57.0% | +6.1pp | 0.73 | no detectable difference |
| full window (32m) | Singles | 6913 | 66.7% | 32.4% | +25.9pp | 2.16 | differs |

On the windows long enough to judge, ETBs differ from: Singles on full window (32m) (+25.9pp, t = 2.16). Every other comparison is a null.

Note how freely the sign moves across the short windows for Booster boxes, Booster bundles. That is the reason those rows read 'window too short to judge' rather than being reported: a difference that changes sign as the window lengthens is noise being read as news.

This is the honest counterweight to section 1. "ETB prices are going up" is true; whether it is ETB-specific is read row by row above, not asserted.


## 4. What is driving it

Every attribute below is measured **as of the start of the window** -- the age
is the age at 2025-11 and the tier is the quartile of the price at
2025-11. Sorting products by where they ENDED would manufacture a
gradient out of the sorting.

`Share of the rise` is exact under the equal-weighted geometric index: the
index's total log rise is the mean log relative, so each group contributes its
share of products times its own mean log move, and the shares sum to 100%. Read
it against `Share of products` -- a group at its own weight is riding the move,
a group well above it is driving.

**By channel**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| Mass-retail | 62 | 67% | 1.52x | 1.44x | 1.59x | 97% | 90.8% |
| Pokemon Center exclusive | 31 | 33% | 1.09x | 1.03x | 1.15x | 68% | 9.2% |

**By age at the start of the window**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| <1yr | 14 | 15% | 1.21x | 1.06x | 1.39x | 71% | 9.6% |
| 1-2yr | 14 | 15% | 1.26x | 1.09x | 1.45x | 64% | 11.3% |
| 2-3yr | 15 | 16% | 1.23x | 1.09x | 1.39x | 80% | 10.9% |
| 3-5yr | 24 | 26% | 1.36x | 1.28x | 1.43x | 100% | 25.7% |
| 5-8yr | 16 | 17% | 1.45x | 1.35x | 1.56x | 100% | 21.0% |
| 8yr+ | 10 | 11% | 1.84x | 1.56x | 2.17x | 100% | 21.5% |

**By price tier (quartile of the price at 2025-11)**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| Q1 | 24 | 26% | 1.55x | 1.50x | 1.61x | 100% | 37.2% |
| Q2 | 23 | 25% | 1.19x | 1.10x | 1.29x | 78% | 14.1% |
| Q3 | 23 | 25% | 1.19x | 1.09x | 1.29x | 74% | 13.8% |
| Q4 | 23 | 25% | 1.54x | 1.37x | 1.73x | 96% | 34.8% |

**Reading.** The rise is **not** evenly spread. The top 10% of movers account for 2.25x their even share, and these groups sit more than 10pp from their own weight: Mass-retail (+24.2pp), Pokemon Center exclusive (-24.2pp), 8yr+ (+10.8pp), Q1 (+11.4pp). Every group had a majority of its products rise.

**The channel split.** Mass-retail boxes rose 39.4% more than Pokemon Center exclusive boxes (1.39x on the ratio of geometric means, t = 8.65, n = 62 vs 31), and that **is** significant at |t| >= 2 -- but read that t with care, because it is the weakest inferential claim in this study. Differencing the two groups does cancel the market-wide factor that makes each group's OWN interval far too narrow, which is why the comparison is worth making at all. It does not cancel a factor specific to one channel, and a Pokemon Center release calendar or a single restock decision is exactly such a factor. Products inside a channel are therefore still positively correlated, the standard error is still too small, and this t is an upper bound on the evidence rather than a measurement of it.

**Age: rate is not level.** Across age bands the geometric mean ranges from 1.21x to 1.84x -- a large, non-monotonic gradient in which older boxes rose faster (1.84x for 8yr+ against 1.21x for <1yr). That is worth keeping separate from the CROSS-SECTIONAL fact that older ETBs sell for more today. That fact is real, and it is NOT an ageing curve, for two reasons that cannot be dropped when it is quoted. First, age = calendar_month - release_month, so within one calendar month age and release cohort are the SAME variable (R^2 = 1.0): this gradient is a vintage ranking as much as an ageing curve, and the cross-section cannot separate them. Second, a cross-sectional median at one calendar month is taken over the boxes still LISTED rather than over the boxes made, so the oldest band's level is a survivor median. The gradient in LEVELS is measured with both of those bounds, product by product, in `etb_agevalue_bands.csv` / `etb_agevalue_survivorship.csv` and section 4.6 of `etb_summary.md`; nothing in THIS section measures it. What this section measures is the RATE, and over the last 12 months the bands appreciated at markedly different ones, though the intervals on the youngest and oldest bands do NOT overlap, so the two ends of the age range did move differently.


## 5. What this cannot tell you

1. **One regime, 33 monthly observations** (2024-03 to
   2026-11), and the trailing window is 12 returns of
   32. Every interval here is SAMPLING uncertainty inside a
   single regime. It says nothing about a regime change, and the regime is the
   dominant risk.
2. **The recent window is short by construction.** A 12-month sub-window cannot
   resolve a mild slowdown; section 2 says so explicitly rather than reporting
   its point estimate as though it settled the question.
3. **No down market has ever been observed here.** The worst drawdown in the
   archive is -4.1%. Nothing in this data
   estimates how far ETBs fall when they fall.
4. **Cross-sectional intervals are dispersion, not confidence.** Products in a
   month share one market factor, so any interval built by treating them as
   independent draws is too narrow for the LEVEL. They are used inferentially
   in exactly one place, the between-group difference in section 4, and even
   there differencing only removes the MARKET-wide factor -- a channel-specific
   shock survives it, so that comparison's t is an upper bound on the evidence.
5. **Balanced endpoints discard products.** The trailing-12m
   cross-section is 93 of
   111 panel products -- the rest were not priced at both
   ends of the window. Inventing a return for them would date different
   products' returns to different spans.
6. **This is measurement, not advice.** It describes what these prices did. It
   does not tell anyone to buy, hold or sell anything, and a rise this broad and
   this fast is exactly the shape that mean-reverts in other collectibles
   markets.

