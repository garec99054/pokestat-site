# Are ETB prices still going up, and is it broad?

_Window: 2024-03 to 2026-09 (31 monthly observations, one regime). Index construction: chained / geometric / survivorship "all". This is MEASUREMENT, not investment advice._

**Short answer.** Over the trailing 12 months 96.7% of the ETBs priced at both ends of the window rose and the index compounded at 40.8%/yr, and the rise is spread across every channel, age band and price tier rather than concentrated in a few products. There is **no detectable stall** -- the last 12 months ran -1.65pp/month against the earlier window (t = -0.80), and the deepest fall inside the window was -4.0% across 4 negative month(s). That rules out a collapse, not a mild slowdown. **But the same rise shows up in booster boxes, booster bundles and singles, and on every window long enough to judge, ETBs cannot be distinguished from them.** The category is going up because the market is going up.

## 1. Breadth -- how many boxes actually went up

Over the trailing 12 months (2025-09 to 2026-09),
**89 of 92 ETBs priced at both ends of the window rose** (96.7%). The
median box multiplied by 1.56x and the geometric mean by
1.54x; the 10th percentile managed 1.17x and
the worst was 0.54x.

That is not an average carried by outliers: the product at the 10th percentile of the distribution still rose (1.17x), so the move is close to the whole cross-section shifting together.

| Window | From | To | n | Share up | Geo-mean | Median | p10 | p90 | Min | Max |
|---|---|---|---|---|---|---|---|---|---|---|
| trailing 3m | 2026-06 | 2026-09 | 104 | 50.0% | 0.99x | 1.00x | 0.84x | 1.18x | 0.20x | 1.59x |
| trailing 6m | 2026-03 | 2026-09 | 99 | 93.9% | 1.30x | 1.32x | 1.10x | 1.59x | 0.54x | 1.78x |
| trailing 9m | 2025-12 | 2026-09 | 94 | 90.4% | 1.39x | 1.42x | 1.02x | 1.72x | 0.82x | 2.11x |
| trailing 12m | 2025-09 | 2026-09 | 92 | 96.7% | 1.54x | 1.56x | 1.17x | 1.99x | 0.54x | 2.91x |
| full window (30m) | 2024-03 | 2026-09 | 69 | 100.0% | 4.38x | 4.17x | 2.98x | 7.92x | 1.32x | 13.96x |

Each row above uses its own balanced set -- a product only enters a window if it
was priced at BOTH ends of it -- so `n` grows as the window shortens and part of
any difference down the table is composition, not behaviour. Holding membership
exactly fixed instead:

| Window | From | To | n | Share up | Geo-mean | p10 | Min |
|---|---|---|---|---|---|---|---|
| first 12m | 2024-03 | 2025-03 | 67 | 97.0% | 1.75x | 1.13x | 0.78x |
| last 12m | 2025-09 | 2026-09 | 67 | 98.5% | 1.59x | 1.23x | 0.95x |

On the same 67 products, the share rising widened from 97.0% to 98.5% -- a change of +1.5pp, which on 67 products is about 1 product(s). That is a difference of a handful of boxes, not a regime: the honest reading is that breadth is **not narrowing**, and that it was already close to its ceiling in both windows, which leaves little room for it to widen and none of this evidence able to detect a small change.

**Is the rise concentrated?** Under a perfectly even rise, the top 10% of
products by size of move would account for 10% of the summed log rise.

| Top share of products | n | Share of the summed log rise | Evenness (1.00 = perfectly even) |
|---|---|---|---|
| 10% | 9 | 19.3% | 1.93 |
| 25% | 23 | 41.2% | 1.65 |
| 50% | 46 | 71.0% | 1.42 |

The 3 that did not rise:

| Product | Channel | Start | End | Multiple |
|---|---|---|---|---|
| Mega Evolution Pokemon Center Elite Trainer Box (Exclusive) [Mega Gardevoir] | Pokemon Center exclusive | $369.32 | $200.09 | 0.54x |
| Mega Evolution Pokemon Center Elite Trainer Box (Exclusive) [Mega Lucario] | Pokemon Center exclusive | $371.50 | $231.35 | 0.62x |
| Temporal Forces Pokemon Center Elite Trainer Box (Exclusive) [Walking Wake] | Pokemon Center exclusive | $216.76 | $205.64 | 0.95x |


## 2. Recency -- is it still going, or has it stalled?

This is the section that matters most to someone buying today, because a
whole-window growth rate is mostly made of yesterdays and would hide a recent
stall.

| Window | From | To | Returns | Total | Annualised | 95% lo | 95% hi | t | Interval usable? |
|---|---|---|---|---|---|---|---|---|---|
| trailing 3m | 2026-06 | 2026-09 | 3 | -2.1% | -8.0% | -29.0% | 19.1% | -0.63 | NO -- too few returns |
| trailing 6m | 2026-03 | 2026-09 | 6 | 22.0% | 48.9% | -18.2% | 171.3% | 1.30 | NO -- too few returns |
| trailing 9m | 2025-12 | 2026-09 | 9 | 28.3% | 39.4% | -7.5% | 110.2% | 1.59 | NO -- too few returns |
| trailing 12m | 2025-09 | 2026-09 | 12 | 40.8% | 40.8% | -1.3% | 100.9% | 1.89 | yes |
| full window | 2024-03 | 2026-09 | 30 | 216.7% | 58.6% | 21.4% | 107.1% | 3.39 | yes |

The 3 shortest window(s) above carry a HAC interval computed from fewer than 12 returns. Those intervals are printed because hiding them would be its own distortion, but they are **not usable**: a Newey-West covariance fitted to 3 or 6 observations produces t-statistics that look decisive and are not. Read the trailing-12m and full-window rows; treat the rest as texture.

Formally: regressing the monthly log return on a dummy for the last 12 months, with a Newey-West covariance at 3 lags, the recent months ran 2.89%/month against 4.60%/month before -- a difference of -1.65pp/month with a standard error of 2.07pp (t = -0.80, p = 0.43). That is **no detectable change**. On 12 recent and 18 prior returns this test could only have found a large change, so it is much better evidence against a collapse than against a mild slowdown.

Month by month over the last 12 months (the same matched-model
links the index multiplies up, opened out; "disp." is the spread ACROSS
PRODUCTS within the month, not a confidence interval for the market -- ETBs move
together, so it is far too narrow for that):

| Month | n | Move | disp. lo | disp. hi | Share up |
|---|---|---|---|---|---|
| 2025-10 | 96 | 10.57% | 7.78% | 13.44% | 85% |
| 2025-11 | 96 | 1.63% | -0.04% | 3.33% | 62% |
| 2025-12 | 96 | -2.31% | -5.45% | 0.93% | 49% |
| 2026-01 | 97 | -1.12% | -2.42% | 0.21% | 43% |
| 2026-02 | 98 | 2.82% | 1.57% | 4.09% | 67% |
| 2026-03 | 100 | 3.39% | 1.14% | 5.70% | 78% |
| 2026-04 | 102 | 10.38% | 7.78% | 13.04% | 86% |
| 2026-05 | 103 | 5.87% | 4.37% | 7.40% | 82% |
| 2026-06 | 104 | 6.64% | 4.08% | 9.27% | 84% |
| 2026-07 | 105 | 1.98% | 0.61% | 3.38% | 63% |
| 2026-08 | 105 | -2.90% | -6.23% | 0.54% | 47% |
| 2026-09 | 106 | -1.10% | -2.56% | 0.37% | 39% |

Months the cross-section fell:

| Month | n | Move | Share up |
|---|---|---|---|
| 2024-04 | 72 | -1.11% | 56% |
| 2024-05 | 73 | -0.59% | 58% |
| 2025-12 | 96 | -2.31% | 49% |
| 2026-01 | 97 | -1.12% | 43% |
| 2026-08 | 105 | -2.90% | 47% |
| 2026-09 | 106 | -1.10% | 39% |

**Drawdowns.** Over the whole window the worst peak-to-trough fall was
-4.0% (peak 2026-07, trough
2026-09), with 6 negative months out of
30. Inside the trailing 12 months the worst fall was
-4.0% across 4 negative months of
12. The worst single month in the archive was
2026-08 at -2.90%.

A maximum drawdown this shallow after a rise this large is itself a warning:
the archive contains no example of this category falling meaningfully, so
nothing here estimates how far it can fall.


## 3. Is it ETB-specific, or market-wide?

Same window, same construction (chained / geometric /
survivorship "all"), applied to booster boxes, booster
bundles and singles. The statistic is the PAIRED monthly log-return difference,
so the common market tide cancels before the standard error is formed.

| Window | Benchmark | n | ETB | Benchmark | ETB minus benchmark | t | Reading |
|---|---|---|---|---|---|---|---|
| trailing 3m | Booster boxes | 54 | -8.0% | -11.3% | +3.7pp | 2.78 | window too short to judge |
| trailing 3m | Booster bundles | 27 | -8.0% | 7.4% | -14.3pp | -2.17 | window too short to judge |
| trailing 3m | Singles | 9332 | -8.0% | 69.2% | -45.6pp | -7.94 | window too short to judge |
| trailing 6m | Booster boxes | 54 | 48.9% | 8.4% | +37.4pp | 1.59 | window too short to judge |
| trailing 6m | Booster bundles | 27 | 48.9% | 63.4% | -8.8pp | -1.14 | window too short to judge |
| trailing 6m | Singles | 9332 | 48.9% | 104.2% | -27.0pp | -1.51 | window too short to judge |
| trailing 9m | Booster boxes | 54 | 39.4% | 17.6% | +18.6pp | 1.04 | window too short to judge |
| trailing 9m | Booster bundles | 27 | 39.4% | 49.5% | -6.7pp | -1.23 | window too short to judge |
| trailing 9m | Singles | 9332 | 39.4% | 86.0% | -25.0pp | -1.96 | window too short to judge |
| trailing 12m | Booster boxes | 54 | 40.8% | 26.1% | +11.7pp | 0.74 | no detectable difference |
| trailing 12m | Booster bundles | 27 | 40.8% | 44.3% | -2.4pp | -0.35 | no detectable difference |
| trailing 12m | Singles | 9332 | 40.8% | 73.1% | -18.6pp | -1.53 | no detectable difference |
| full window (30m) | Booster boxes | 54 | 58.6% | 59.6% | -0.6pp | -0.07 | no detectable difference |
| full window (30m) | Booster bundles | 27 | 58.6% | 54.0% | +3.0pp | 0.32 | no detectable difference |
| full window (30m) | Singles | 9332 | 58.6% | 39.8% | +13.4pp | 1.00 | no detectable difference |

**On every window long enough to judge (full window (30m), trailing 12m), no benchmark differs from ETBs at |t| >= 2.** The prior study's finding -- that ETBs did not significantly beat booster boxes over the full window -- survives into the recent sub-window unchanged. ETB prices went up; so did everything else, by an amount this data cannot distinguish.

This is the honest counterweight to section 1. "ETB prices are going up" is
true and broad, and it is not an ETB fact -- it is a Pokemon-sealed-and-singles
fact that ETBs participate in.


## 4. What is driving it

Every attribute below is measured **as of the start of the window** -- the age
is the age at 2025-09 and the tier is the quartile of the price at
2025-09. Sorting products by where they ENDED would manufacture a
gradient out of the sorting.

`Share of the rise` is exact under the equal-weighted geometric index: the
index's total log rise is the mean log relative, so each group contributes its
share of products times its own mean log move, and the shares sum to 100%. Read
it against `Share of products` -- a group at its own weight is riding the move,
a group well above it is driving.

**By channel**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| Mass-retail | 61 | 66% | 1.69x | 1.61x | 1.77x | 100% | 80.6% |
| Pokemon Center exclusive | 31 | 34% | 1.28x | 1.17x | 1.41x | 90% | 19.4% |

**By age at the start of the window**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| <1yr | 16 | 17% | 1.31x | 1.10x | 1.57x | 88% | 11.0% |
| 1-2yr | 16 | 17% | 1.44x | 1.29x | 1.59x | 94% | 14.6% |
| 2-3yr | 13 | 14% | 1.61x | 1.46x | 1.77x | 100% | 15.6% |
| 3-5yr | 23 | 25% | 1.54x | 1.46x | 1.63x | 100% | 25.1% |
| 5-8yr | 17 | 18% | 1.66x | 1.48x | 1.87x | 100% | 21.7% |
| 8yr+ | 7 | 8% | 1.98x | 1.64x | 2.39x | 100% | 12.0% |

**By price tier (quartile of the price at 2025-09)**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| Q1 | 23 | 25% | 1.69x | 1.63x | 1.76x | 100% | 30.6% |
| Q2 | 23 | 25% | 1.43x | 1.33x | 1.54x | 100% | 20.7% |
| Q3 | 23 | 25% | 1.41x | 1.25x | 1.59x | 91% | 19.8% |
| Q4 | 23 | 25% | 1.64x | 1.43x | 1.89x | 96% | 28.8% |

**Reading.** The rise is **not** evenly spread. The top 10% of movers account for 1.93x their even share, and these groups sit more than 10pp from their own weight: Mass-retail (+14.3pp), Pokemon Center exclusive (-14.3pp). Every group had a majority of its products rise.

**The channel split.** Mass-retail boxes rose 31.8% more than Pokemon Center exclusive boxes (1.32x on the ratio of geometric means, t = 5.18, n = 61 vs 31), and that **is** significant at |t| >= 2 -- but read that t with care, because it is the weakest inferential claim in this study. Differencing the two groups does cancel the market-wide factor that makes each group's OWN interval far too narrow, which is why the comparison is worth making at all. It does not cancel a factor specific to one channel, and a Pokemon Center release calendar or a single restock decision is exactly such a factor. Products inside a channel are therefore still positively correlated, the standard error is still too small, and this t is an upper bound on the evidence rather than a measurement of it.

**Age: rate is not level.** Across age bands the geometric mean ranges from 1.31x to 1.98x -- a large, non-monotonic gradient in which older boxes rose faster (1.98x for 8yr+ against 1.31x for <1yr). That is worth keeping separate from the CROSS-SECTIONAL fact that older ETBs sell for more today. That fact is real, and it is NOT an ageing curve, for two reasons that cannot be dropped when it is quoted. First, age = calendar_month - release_month, so within one calendar month age and release cohort are the SAME variable (R^2 = 1.0): this gradient is a vintage ranking as much as an ageing curve, and the cross-section cannot separate them. Second, a cross-sectional median at one calendar month is taken over the boxes still LISTED rather than over the boxes made, so the oldest band's level is a survivor median. The gradient in LEVELS is measured with both of those bounds, product by product, in `etb_agevalue_bands.csv` / `etb_agevalue_survivorship.csv` and section 4.6 of `etb_summary.md`; nothing in THIS section measures it. What this section measures is the RATE, and over the last 12 months every band appreciated at a broadly similar one, though the intervals on the youngest and oldest bands do NOT overlap, so the two ends of the age range did move differently.


## 5. What this cannot tell you

1. **One regime, 31 monthly observations** (2024-03 to
   2026-09), and the trailing window is 12 returns of
   30. Every interval here is SAMPLING uncertainty inside a
   single regime. It says nothing about a regime change, and the regime is the
   dominant risk.
2. **The recent window is short by construction.** A 12-month sub-window cannot
   resolve a mild slowdown; section 2 says so explicitly rather than reporting
   its point estimate as though it settled the question.
3. **No down market has ever been observed here.** The worst drawdown in the
   archive is -4.0%. Nothing in this data
   estimates how far ETBs fall when they fall.
4. **Cross-sectional intervals are dispersion, not confidence.** Products in a
   month share one market factor, so any interval built by treating them as
   independent draws is too narrow for the LEVEL. They are used inferentially
   in exactly one place, the between-group difference in section 4, and even
   there differencing only removes the MARKET-wide factor -- a channel-specific
   shock survives it, so that comparison's t is an upper bound on the evidence.
5. **Balanced endpoints discard products.** The trailing-12m
   cross-section is 92 of
   111 panel products -- the rest were not priced at both
   ends of the window. Inventing a return for them would date different
   products' returns to different spans.
6. **This is measurement, not advice.** It describes what these prices did. It
   does not tell anyone to buy, hold or sell anything, and a rise this broad and
   this fast is exactly the shape that mean-reverts in other collectibles
   markets.

