# Are ETB prices still going up, and is it broad?

_Window: 2024-03 to 2026-09 (31 monthly observations, one regime). Index construction: chained / geometric / survivorship "all". This is MEASUREMENT, not investment advice._

**Short answer.** Over the trailing 12 months 98.9% of the ETBs priced at both ends of the window rose and the index compounded at 55.4%/yr, and the rise is spread across every channel, age band and price tier rather than concentrated in a few products. There is **no detectable stall** -- the last 12 months ran -1.60pp/month against the earlier window (t = -0.77), and the deepest fall inside the window was -1.8% across 4 negative month(s). That rules out a collapse, not a mild slowdown. **But the same rise shows up in booster boxes, booster bundles and singles, and on every window long enough to judge, ETBs cannot be distinguished from them.** The category is going up because the market is going up.

## 1. Breadth -- how many boxes actually went up

Over the trailing 12 months (2025-09 to 2026-09),
**87 of 88 ETBs priced at both ends of the window rose** (98.9%). The
median box multiplied by 1.59x and the geometric mean by
1.58x; the 10th percentile managed 1.20x and
the worst was 0.95x.

That is not an average carried by outliers: the product at the 10th percentile of the distribution still rose (1.20x), so the move is close to the whole cross-section shifting together.

| Window | From | To | n | Share up | Geo-mean | Median | p10 | p90 | Min | Max |
|---|---|---|---|---|---|---|---|---|---|---|
| trailing 3m | 2026-06 | 2026-09 | 102 | 51.0% | 1.01x | 1.00x | 0.86x | 1.18x | 0.58x | 1.59x |
| trailing 6m | 2026-03 | 2026-09 | 97 | 95.9% | 1.32x | 1.32x | 1.11x | 1.59x | 0.63x | 1.78x |
| trailing 9m | 2025-12 | 2026-09 | 94 | 90.4% | 1.39x | 1.42x | 1.02x | 1.72x | 0.82x | 2.11x |
| trailing 12m | 2025-09 | 2026-09 | 88 | 98.9% | 1.58x | 1.59x | 1.20x | 2.01x | 0.95x | 2.91x |
| full window (30m) | 2024-03 | 2026-09 | 65 | 100.0% | 4.59x | 4.23x | 3.09x | 7.98x | 2.03x | 13.96x |

Each row above uses its own balanced set -- a product only enters a window if it
was priced at BOTH ends of it -- so `n` grows as the window shortens and part of
any difference down the table is composition, not behaviour. Holding membership
exactly fixed instead:

| Window | From | To | n | Share up | Geo-mean | p10 | Min |
|---|---|---|---|---|---|---|---|
| first 12m | 2024-03 | 2025-03 | 63 | 100.0% | 1.80x | 1.14x | 1.04x |
| last 12m | 2025-09 | 2026-09 | 63 | 100.0% | 1.60x | 1.30x | 1.08x |

On the same 63 products, the share rising held from 100.0% to 100.0% -- a change of +0.0pp, which on 63 products is about 0 product(s). That is a difference of a handful of boxes, not a regime: the honest reading is that breadth is **not narrowing**, and that it was already close to its ceiling in both windows, which leaves little room for it to widen and none of this evidence able to detect a small change.

**Is the rise concentrated?** Under a perfectly even rise, the top 10% of
products by size of move would account for 10% of the summed log rise.

| Top share of products | n | Share of the summed log rise | Evenness (1.00 = perfectly even) |
|---|---|---|---|
| 10% | 9 | 18.9% | 1.89 |
| 25% | 22 | 39.0% | 1.56 |
| 50% | 44 | 67.4% | 1.35 |

The 1 that did not rise:

| Product | Channel | Start | End | Multiple |
|---|---|---|---|---|
| Temporal Forces Pokemon Center Elite Trainer Box (Exclusive) [Walking Wake] | Pokemon Center exclusive | $216.76 | $205.64 | 0.95x |


## 2. Recency -- is it still going, or has it stalled?

This is the section that matters most to someone buying today, because a
whole-window growth rate is mostly made of yesterdays and would hide a recent
stall.

| Window | From | To | Returns | Total | Annualised | 95% lo | 95% hi | t | Interval usable? |
|---|---|---|---|---|---|---|---|---|---|
| trailing 3m | 2026-06 | 2026-09 | 3 | 1.0% | 4.0% | -16.6% | 29.6% | 0.34 | NO -- too few returns |
| trailing 6m | 2026-03 | 2026-09 | 6 | 29.0% | 66.4% | -6.1% | 195.1% | 1.74 | NO -- too few returns |
| trailing 9m | 2025-12 | 2026-09 | 9 | 36.9% | 52.0% | 1.2% | 128.2% | 2.02 | NO -- too few returns |
| trailing 12m | 2025-09 | 2026-09 | 12 | 55.4% | 55.4% | 8.9% | 121.9% | 2.43 | yes |
| full window | 2024-03 | 2026-09 | 30 | 301.8% | 74.4% | 32.6% | 129.4% | 3.98 | yes |

The 3 shortest window(s) above carry a HAC interval computed from fewer than 12 returns. Those intervals are printed because hiding them would be its own distortion, but they are **not usable**: a Newey-West covariance fitted to 3 or 6 observations produces t-statistics that look decisive and are not. Read the trailing-12m and full-window rows; treat the rest as texture.

Formally: regressing the monthly log return on a dummy for the last 12 months, with a Newey-West covariance at 3 lags, the recent months ran 3.74%/month against 5.42%/month before -- a difference of -1.60pp/month with a standard error of 2.08pp (t = -0.77, p = 0.44). That is **no detectable change**. On 12 recent and 18 prior returns this test could only have found a large change, so it is much better evidence against a collapse than against a mild slowdown.

Month by month over the last 12 months (the same matched-model
links the index multiplies up, opened out; "disp." is the spread ACROSS
PRODUCTS within the month, not a confidence interval for the market -- ETBs move
together, so it is far too narrow for that):

| Month | n | Move | disp. lo | disp. hi | Share up |
|---|---|---|---|---|---|
| 2025-10 | 92 | 12.25% | 9.95% | 14.59% | 89% |
| 2025-11 | 94 | 1.93% | 0.30% | 3.58% | 64% |
| 2025-12 | 94 | -0.74% | -2.96% | 1.54% | 50% |
| 2026-01 | 97 | -1.12% | -2.42% | 0.21% | 43% |
| 2026-02 | 96 | 2.79% | 1.60% | 3.99% | 68% |
| 2026-03 | 98 | 4.38% | 2.54% | 6.25% | 80% |
| 2026-04 | 100 | 11.49% | 9.39% | 13.63% | 88% |
| 2026-05 | 102 | 6.19% | 4.80% | 7.60% | 82% |
| 2026-06 | 102 | 7.92% | 6.19% | 9.68% | 85% |
| 2026-07 | 103 | 2.29% | 0.95% | 3.65% | 64% |
| 2026-08 | 102 | -0.38% | -1.67% | 0.93% | 48% |
| 2026-09 | 104 | -0.91% | -2.36% | 0.56% | 39% |

Months the cross-section fell:

| Month | n | Move | Share up |
|---|---|---|---|
| 2024-05 | 72 | -0.14% | 58% |
| 2025-12 | 94 | -0.74% | 50% |
| 2026-01 | 97 | -1.12% | 43% |
| 2026-08 | 102 | -0.38% | 48% |
| 2026-09 | 104 | -0.91% | 39% |

**Drawdowns.** Over the whole window the worst peak-to-trough fall was
-1.8% (peak 2025-11, trough
2026-01), with 5 negative months out of
30. Inside the trailing 12 months the worst fall was
-1.8% across 4 negative months of
12. The worst single month in the archive was
2026-01 at -1.12%.

A maximum drawdown this shallow after a rise this large is itself a warning: the archive contains no example of this category falling meaningfully, so nothing here estimates how far it can fall.


## 3. Is it ETB-specific, or market-wide?

Same window, same construction (chained / geometric /
survivorship "all"), applied to booster boxes, booster
bundles and singles. The statistic is the PAIRED monthly log-return difference,
so the common market tide cancels before the standard error is formed.

| Window | Benchmark | n | ETB | Benchmark | ETB minus benchmark | t | Reading |
|---|---|---|---|---|---|---|---|
| trailing 3m | Booster boxes | 54 | 4.0% | -8.8% | +14.0pp | 7.17 | window too short to judge |
| trailing 3m | Booster bundles | 26 | 4.0% | 16.0% | -10.4pp | -2.46 | window too short to judge |
| trailing 3m | Singles | 9223 | 4.0% | 69.2% | -38.6pp | -7.11 | window too short to judge |
| trailing 6m | Booster boxes | 54 | 66.4% | 11.4% | +49.4pp | 2.15 | window too short to judge |
| trailing 6m | Booster bundles | 26 | 66.4% | 93.0% | -13.8pp | -2.96 | window too short to judge |
| trailing 6m | Singles | 9223 | 66.4% | 104.4% | -18.6pp | -1.05 | window too short to judge |
| trailing 9m | Booster boxes | 54 | 52.0% | 20.0% | +26.7pp | 1.39 | window too short to judge |
| trailing 9m | Booster bundles | 26 | 52.0% | 71.3% | -11.3pp | -2.88 | window too short to judge |
| trailing 9m | Singles | 9223 | 52.0% | 86.1% | -18.3pp | -1.47 | window too short to judge |
| trailing 12m | Booster boxes | 54 | 55.4% | 29.0% | +20.5pp | 1.24 | no detectable difference |
| trailing 12m | Booster bundles | 26 | 55.4% | 64.5% | -5.5pp | -0.77 | no detectable difference |
| trailing 12m | Singles | 9223 | 55.4% | 73.6% | -10.4pp | -0.83 | no detectable difference |
| full window (30m) | Booster boxes | 54 | 74.4% | 61.8% | +7.8pp | 0.86 | no detectable difference |
| full window (30m) | Booster bundles | 26 | 74.4% | 65.1% | +5.6pp | 0.63 | no detectable difference |
| full window (30m) | Singles | 9223 | 74.4% | 41.4% | +23.4pp | 1.69 | no detectable difference |

**On every window long enough to judge (full window (30m), trailing 12m), no benchmark differs from ETBs at |t| >= 2.** The prior study's finding -- that ETBs did not significantly beat booster boxes over the full window -- survives into the recent sub-window unchanged. ETB prices went up; so did everything else, by an amount this data cannot distinguish.

This is the honest counterweight to section 1. "ETB prices are going up" is true and broad, and it is not an ETB fact -- it is a Pokemon-sealed-and-singles fact that ETBs participate in.


## 4. What is driving it

Every attribute below is measured **as of the start of the window** -- the age
is the age at 2025-09 and the tier is the quartile of the price at
2025-09. Sorting products by where they ENDED would manufacture a
gradient out of the sorting.

`Share of the rise` is exact under the equal-weighted geometric index: the
index's total log rise is the mean log relative, so each group contributes its
share of products times its own mean log move, and the shares sum to 100%. Read
it against `Share of products` -- a group at its own weight is riding the move,
a group well above it is driving.

**By channel**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| Mass-retail | 59 | 67% | 1.71x | 1.63x | 1.79x | 100% | 78.3% |
| Pokemon Center exclusive | 29 | 33% | 1.35x | 1.28x | 1.44x | 97% | 21.7% |

**By age at the start of the window**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| <1yr | 12 | 14% | 1.53x | 1.37x | 1.70x | 100% | 12.6% |
| 1-2yr | 16 | 18% | 1.44x | 1.29x | 1.59x | 94% | 14.3% |
| 2-3yr | 13 | 15% | 1.61x | 1.46x | 1.77x | 100% | 15.3% |
| 3-5yr | 23 | 26% | 1.54x | 1.46x | 1.63x | 100% | 24.7% |
| 5-8yr | 17 | 19% | 1.66x | 1.48x | 1.87x | 100% | 21.4% |
| 8yr+ | 7 | 8% | 1.98x | 1.64x | 2.39x | 100% | 11.8% |

**By price tier (quartile of the price at 2025-09)**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| Q1 | 22 | 25% | 1.70x | 1.63x | 1.77x | 100% | 28.9% |
| Q2 | 22 | 25% | 1.46x | 1.36x | 1.57x | 100% | 20.6% |
| Q3 | 22 | 25% | 1.47x | 1.35x | 1.60x | 95% | 21.0% |
| Q4 | 22 | 25% | 1.72x | 1.53x | 1.93x | 100% | 29.5% |

**Reading.** The rise is **not** evenly spread. The top 10% of movers account for 1.89x their even share, and these groups sit more than 10pp from their own weight: Mass-retail (+11.2pp), Pokemon Center exclusive (-11.2pp). Every group had a majority of its products rise.

**The channel split.** Mass-retail boxes rose 26.3% more than Pokemon Center exclusive boxes (1.26x on the ratio of geometric means, t = 6.06, n = 59 vs 29), and that **is** significant at |t| >= 2 -- but read that t with care, because it is the weakest inferential claim in this study. Differencing the two groups does cancel the market-wide factor that makes each group's OWN interval far too narrow, which is why the comparison is worth making at all. It does not cancel a factor specific to one channel, and a Pokemon Center release calendar or a single restock decision is exactly such a factor. Products inside a channel are therefore still positively correlated, the standard error is still too small, and this t is an upper bound on the evidence rather than a measurement of it.

**Age: rate is not level.** Across age bands the geometric mean ranges from 1.44x to 1.98x -- a mild, non-monotonic gradient in which older boxes rose faster (1.98x for 8yr+ against 1.53x for <1yr). That is worth keeping separate from the CROSS-SECTIONAL fact that older ETBs sell for more today. That fact is real, and it is NOT an ageing curve, for two reasons that cannot be dropped when it is quoted. First, age = calendar_month - release_month, so within one calendar month age and release cohort are the SAME variable (R^2 = 1.0): this gradient is a vintage ranking as much as an ageing curve, and the cross-section cannot separate them. Second, a cross-sectional median at one calendar month is taken over the boxes still LISTED rather than over the boxes made, so the oldest band's level is a survivor median. The gradient in LEVELS is measured with both of those bounds, product by product, in `etb_agevalue_bands.csv` / `etb_agevalue_survivorship.csv` and section 4.6 of `etb_summary.md`; nothing in THIS section measures it. What this section measures is the RATE, and over the last 12 months every band appreciated at a broadly similar one, and the intervals on the youngest and oldest bands overlap.


## 5. What this cannot tell you

1. **One regime, 31 monthly observations** (2024-03 to
   2026-09), and the trailing window is 12 returns of
   30. Every interval here is SAMPLING uncertainty inside a
   single regime. It says nothing about a regime change, and the regime is the
   dominant risk.
2. **The recent window is short by construction.** A 12-month sub-window cannot
   resolve a mild slowdown; section 2 says so explicitly rather than reporting
   its point estimate as though it settled the question.
3. **No down market has ever been observed here.** The worst drawdown in the
   archive is -1.8%. Nothing in this data
   estimates how far ETBs fall when they fall.
4. **Cross-sectional intervals are dispersion, not confidence.** Products in a
   month share one market factor, so any interval built by treating them as
   independent draws is too narrow for the LEVEL. They are used inferentially
   in exactly one place, the between-group difference in section 4, and even
   there differencing only removes the MARKET-wide factor -- a channel-specific
   shock survives it, so that comparison's t is an upper bound on the evidence.
5. **Balanced endpoints discard products.** The trailing-12m
   cross-section is 88 of
   109 panel products -- the rest were not priced at both
   ends of the window. Inventing a return for them would date different
   products' returns to different spans.
6. **This is measurement, not advice.** It describes what these prices did. It
   does not tell anyone to buy, hold or sell anything, and a rise this broad and
   this fast is exactly the shape that mean-reverts in other collectibles
   markets.

