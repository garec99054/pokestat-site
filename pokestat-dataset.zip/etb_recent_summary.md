# Are ETB prices still going up, and is it broad?

_Window: 2024-03 to 2026-10 (32 monthly observations, one regime). Index construction: chained / geometric / survivorship "all". This is MEASUREMENT, not investment advice._

**Short answer.** Over the trailing 12 months 86.8% of the ETBs priced at both ends of the window rose and the index compounded at 36.4%/yr, but the rise is concentrated rather than broad-based. There is **no detectable stall** -- the last 12 months ran -3.02pp/month against the earlier window (t = -1.31), and the deepest fall inside the window was -2.7% across 5 negative month(s). That rules out a collapse, not a mild slowdown. **But the same rise shows up in booster boxes, booster bundles and singles, and on every window long enough to judge, ETBs cannot be distinguished from them.** The category is going up because the market is going up.

## 1. Breadth -- how many boxes actually went up

Over the trailing 12 months (2025-10 to 2026-10),
**79 of 91 ETBs priced at both ends of the window rose** (86.8%). The
median box multiplied by 1.38x and the geometric mean by
1.37x; the 10th percentile managed 0.99x and
the worst was 0.76x.

Most products rose, but the bottom decile did not (0.99x at the 10th percentile), so the tail of this distribution is doing something different from its middle.

| Window | From | To | n | Share up | Geo-mean | Median | p10 | p90 | Min | Max |
|---|---|---|---|---|---|---|---|---|---|---|
| trailing 3m | 2026-07 | 2026-10 | 101 | 39.6% | 0.97x | 0.97x | 0.85x | 1.14x | 0.62x | 1.51x |
| trailing 6m | 2026-04 | 2026-10 | 98 | 81.6% | 1.15x | 1.17x | 0.93x | 1.43x | 0.52x | 1.61x |
| trailing 9m | 2026-01 | 2026-10 | 94 | 93.6% | 1.39x | 1.42x | 1.07x | 1.71x | 0.81x | 1.96x |
| trailing 12m | 2025-10 | 2026-10 | 91 | 86.8% | 1.37x | 1.38x | 0.99x | 1.79x | 0.76x | 2.91x |
| full window (31m) | 2024-03 | 2026-10 | 64 | 100.0% | 4.55x | 4.23x | 3.07x | 7.95x | 2.00x | 13.36x |

Each row above uses its own balanced set -- a product only enters a window if it
was priced at BOTH ends of it -- so `n` grows as the window shortens and part of
any difference down the table is composition, not behaviour. Holding membership
exactly fixed instead:

| Window | From | To | n | Share up | Geo-mean | p10 | Min |
|---|---|---|---|---|---|---|---|
| first 12m | 2024-03 | 2025-03 | 62 | 100.0% | 1.81x | 1.19x | 1.04x |
| last 12m | 2025-10 | 2026-10 | 62 | 95.2% | 1.42x | 1.10x | 0.86x |

On the same 62 products, the share rising narrowed from 100.0% to 95.2% -- a change of -4.8pp, which on 62 products is about 3 product(s). Breadth **narrowed** on a fixed cohort -- read it with the product count, since a few boxes move a share on a cohort this size.

**Is the rise concentrated?** Under a perfectly even rise, the top 10% of
products by size of move would account for 10% of the summed log rise.

| Top share of products | n | Share of the summed log rise | Evenness (1.00 = perfectly even) |
|---|---|---|---|
| 10% | 9 | 22.2% | 2.22 |
| 25% | 23 | 48.7% | 1.95 |
| 50% | 46 | 81.3% | 1.63 |

The 12 that did not rise:

| Product | Channel | Start | End | Multiple |
|---|---|---|---|---|
| Mega Evolution Pokemon Center Elite Trainer Box (Exclusive) [Mega Lucario] | Pokemon Center exclusive | $260.29 | $198.33 | 0.76x |
| Temporal Forces Pokemon Center Elite Trainer Box (Exclusive) [Walking Wake] | Pokemon Center exclusive | $247.11 | $201.81 | 0.82x |
| Mega Evolution Pokemon Center Elite Trainer Box (Exclusive) [Mega Gardevoir] | Pokemon Center exclusive | $229.88 | $192.35 | 0.84x |
| Scarlet & Violet Pokemon Center Elite Trainer Box (Exclusive) [Koraidon] | Pokemon Center exclusive | $335.08 | $287.06 | 0.86x |
| Obsidian Flames Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $691.71 | $631.59 | 0.91x |
| Surging Sparks Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $295.65 | $270.25 | 0.91x |
| Stellar Crown Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $180.18 | $169.32 | 0.94x |
| Twilight Masquerade Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $191.64 | $187.35 | 0.98x |
| Temporal Forces Pokemon Center Elite Trainer Box (Exclusive) [Iron Leaves] | Pokemon Center exclusive | $200.81 | $196.56 | 0.98x |
| Journey Together Pokemon Center Elite Trainer Box (Exclusive) | Pokemon Center exclusive | $197.50 | $194.57 | 0.99x |
| Scarlet & Violet Pokemon Center Elite Trainer Box (Exclusive) [Miraidon] | Pokemon Center exclusive | $320.87 | $317.06 | 0.99x |
| Destined Rivals Elite Trainer Box | Mass-retail | $117.47 | $116.12 | 0.99x |


## 2. Recency -- is it still going, or has it stalled?

This is the section that matters most to someone buying today, because a
whole-window growth rate is mostly made of yesterdays and would hide a recent
stall.

| Window | From | To | Returns | Total | Annualised | 95% lo | 95% hi | t | Interval usable? |
|---|---|---|---|---|---|---|---|---|---|
| trailing 3m | 2026-07 | 2026-10 | 3 | -2.7% | -10.5% | -17.0% | -3.5% | -2.89 | NO -- too few returns |
| trailing 6m | 2026-04 | 2026-10 | 6 | 14.0% | 30.0% | -19.5% | 109.9% | 1.07 | NO -- too few returns |
| trailing 9m | 2026-01 | 2026-10 | 9 | 36.4% | 51.2% | -3.2% | 136.3% | 1.82 | NO -- too few returns |
| trailing 12m | 2025-10 | 2026-10 | 12 | 36.4% | 36.4% | -5.9% | 97.9% | 1.64 | yes |
| full window | 2024-03 | 2026-10 | 31 | 295.9% | 70.3% | 28.8% | 125.2% | 3.74 | yes |

The 3 shortest window(s) above carry a HAC interval computed from fewer than 12 returns. Those intervals are printed because hiding them would be its own distortion, but they are **not usable**: a Newey-West covariance fitted to 3 or 6 observations produces t-statistics that look decisive and are not. Read the trailing-12m and full-window rows; treat the rest as texture.

Formally: regressing the monthly log return on a dummy for the last 12 months, with a Newey-West covariance at 3 lags, the recent months ran 2.62%/month against 5.77%/month before -- a difference of -3.02pp/month with a standard error of 2.31pp (t = -1.31, p = 0.19). That is **no detectable change**. On 12 recent and 19 prior returns this test could only have found a large change, so it is much better evidence against a collapse than against a mild slowdown.

Month by month over the last 12 months (the same matched-model
links the index multiplies up, opened out; "disp." is the spread ACROSS
PRODUCTS within the month, not a confidence interval for the market -- ETBs move
together, so it is far too narrow for that):

| Month | n | Move | disp. lo | disp. hi | Share up |
|---|---|---|---|---|---|
| 2025-11 | 94 | 1.93% | 0.30% | 3.58% | 64% |
| 2025-12 | 94 | -0.74% | -2.96% | 1.54% | 50% |
| 2026-01 | 97 | -1.12% | -2.42% | 0.21% | 43% |
| 2026-02 | 96 | 2.79% | 1.60% | 3.99% | 68% |
| 2026-03 | 98 | 4.38% | 2.54% | 6.25% | 80% |
| 2026-04 | 100 | 11.49% | 9.39% | 13.63% | 88% |
| 2026-05 | 102 | 6.19% | 4.80% | 7.60% | 82% |
| 2026-06 | 102 | 7.92% | 6.19% | 9.68% | 85% |
| 2026-07 | 103 | 2.29% | 0.95% | 3.65% | 64% |
| 2026-08 | 102 | -0.38% | -1.67% | 0.93% | 48% |
| 2026-09 | 104 | -0.91% | -2.36% | 0.56% | 39% |
| 2026-10 | 103 | -1.48% | -2.37% | -0.58% | 31% |

Months the cross-section fell:

| Month | n | Move | Share up |
|---|---|---|---|
| 2024-05 | 72 | -0.14% | 58% |
| 2025-12 | 94 | -0.74% | 50% |
| 2026-01 | 97 | -1.12% | 43% |
| 2026-08 | 102 | -0.38% | 48% |
| 2026-09 | 104 | -0.91% | 39% |
| 2026-10 | 103 | -1.48% | 31% |

**Drawdowns.** Over the whole window the worst peak-to-trough fall was
-2.7% (peak 2026-07, trough
2026-10), with 6 negative months out of
31. Inside the trailing 12 months the worst fall was
-2.7% across 5 negative months of
12. The worst single month in the archive was
2026-10 at -1.48%.

A maximum drawdown this shallow after a rise this large is itself a warning: the archive contains no example of this category falling meaningfully, so nothing here estimates how far it can fall.


## 3. Is it ETB-specific, or market-wide?

Same window, same construction (chained / geometric /
survivorship "all"), applied to booster boxes, booster
bundles and singles. The statistic is the PAIRED monthly log-return difference,
so the common market tide cancels before the standard error is formed.

| Window | Benchmark | n | ETB | Benchmark | ETB minus benchmark | t | Reading |
|---|---|---|---|---|---|---|---|
| trailing 3m | Booster boxes | 54 | -10.5% | -14.1% | +4.1pp | 0.40 | window too short to judge |
| trailing 3m | Booster bundles | 27 | -10.5% | -0.7% | -9.9pp | -1.56 | window too short to judge |
| trailing 3m | Singles | 9317 | -10.5% | 45.2% | -38.4pp | -10.70 | window too short to judge |
| trailing 6m | Booster boxes | 54 | 30.0% | 6.1% | +22.5pp | 1.63 | window too short to judge |
| trailing 6m | Booster bundles | 27 | 30.0% | 56.6% | -17.0pp | -3.43 | window too short to judge |
| trailing 6m | Singles | 9317 | 30.0% | 88.1% | -30.9pp | -4.56 | window too short to judge |
| trailing 9m | Booster boxes | 54 | 51.2% | 18.1% | +28.1pp | 1.62 | window too short to judge |
| trailing 9m | Booster bundles | 27 | 51.2% | 77.0% | -14.6pp | -4.60 | window too short to judge |
| trailing 9m | Singles | 9317 | 51.2% | 85.8% | -18.6pp | -1.42 | window too short to judge |
| trailing 12m | Booster boxes | 54 | 36.4% | 16.6% | +17.0pp | 1.02 | no detectable difference |
| trailing 12m | Booster bundles | 27 | 36.4% | 50.4% | -9.3pp | -1.82 | no detectable difference |
| trailing 12m | Singles | 9317 | 36.4% | 67.6% | -18.6pp | -1.90 | no detectable difference |
| full window (31m) | Booster boxes | 54 | 70.3% | 59.2% | +7.0pp | 0.80 | no detectable difference |
| full window (31m) | Booster bundles | 27 | 70.3% | 62.5% | +4.8pp | 0.55 | no detectable difference |
| full window (31m) | Singles | 9317 | 70.3% | 40.7% | +21.1pp | 1.50 | no detectable difference |

**On every window long enough to judge (full window (31m), trailing 12m), no benchmark differs from ETBs at |t| >= 2.** The prior study's finding -- that ETBs did not significantly beat booster boxes over the full window -- survives into the recent sub-window unchanged. ETB prices went up; so did everything else, by an amount this data cannot distinguish.

This is the honest counterweight to section 1. "ETB prices are going up" is true and broad, and it is not an ETB fact -- it is a Pokemon-sealed-and-singles fact that ETBs participate in.


## 4. What is driving it

Every attribute below is measured **as of the start of the window** -- the age
is the age at 2025-10 and the tier is the quartile of the price at
2025-10. Sorting products by where they ENDED would manufacture a
gradient out of the sorting.

`Share of the rise` is exact under the equal-weighted geometric index: the
index's total log rise is the mean log relative, so each group contributes its
share of products times its own mean log move, and the shares sum to 100%. Read
it against `Share of products` -- a group at its own weight is riding the move,
a group well above it is driving.

**By channel**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| Mass-retail | 60 | 66% | 1.54x | 1.47x | 1.62x | 98% | 91.3% |
| Pokemon Center exclusive | 31 | 34% | 1.08x | 1.02x | 1.15x | 65% | 8.7% |

**By age at the start of the window**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| <1yr | 16 | 18% | 1.18x | 1.03x | 1.35x | 69% | 9.4% |
| 1-2yr | 16 | 18% | 1.27x | 1.12x | 1.43x | 75% | 13.3% |
| 2-3yr | 13 | 14% | 1.34x | 1.16x | 1.55x | 77% | 13.3% |
| 3-5yr | 23 | 25% | 1.38x | 1.31x | 1.46x | 100% | 26.1% |
| 5-8yr | 16 | 18% | 1.51x | 1.37x | 1.66x | 100% | 23.0% |
| 8yr+ | 7 | 8% | 1.83x | 1.55x | 2.17x | 100% | 14.9% |

**By price tier (quartile of the price at 2025-10)**

| Group | n | Share of products | Geo-mean | lo | hi | Share up | Share of the rise |
|---|---|---|---|---|---|---|---|
| Q1 | 23 | 25% | 1.60x | 1.54x | 1.67x | 100% | 38.0% |
| Q2 | 23 | 25% | 1.22x | 1.12x | 1.32x | 78% | 15.8% |
| Q3 | 22 | 24% | 1.20x | 1.09x | 1.32x | 73% | 13.8% |
| Q4 | 23 | 25% | 1.50x | 1.33x | 1.68x | 96% | 32.5% |

**Reading.** The rise is **not** evenly spread. The top 10% of movers account for 2.22x their even share, and these groups sit more than 10pp from their own weight: Mass-retail (+25.4pp), Pokemon Center exclusive (-25.4pp), Q1 (+12.7pp), Q3 (-10.4pp). Every group had a majority of its products rise.

**The channel split.** Mass-retail boxes rose 42.4% more than Pokemon Center exclusive boxes (1.42x on the ratio of geometric means, t = 9.05, n = 60 vs 31), and that **is** significant at |t| >= 2 -- but read that t with care, because it is the weakest inferential claim in this study. Differencing the two groups does cancel the market-wide factor that makes each group's OWN interval far too narrow, which is why the comparison is worth making at all. It does not cancel a factor specific to one channel, and a Pokemon Center release calendar or a single restock decision is exactly such a factor. Products inside a channel are therefore still positively correlated, the standard error is still too small, and this t is an upper bound on the evidence rather than a measurement of it.

**Age: rate is not level.** Across age bands the geometric mean ranges from 1.18x to 1.83x -- a large, monotonic gradient in which older boxes rose faster (1.83x for 8yr+ against 1.18x for <1yr). That is worth keeping separate from the CROSS-SECTIONAL fact that older ETBs sell for more today. That fact is real, and it is NOT an ageing curve, for two reasons that cannot be dropped when it is quoted. First, age = calendar_month - release_month, so within one calendar month age and release cohort are the SAME variable (R^2 = 1.0): this gradient is a vintage ranking as much as an ageing curve, and the cross-section cannot separate them. Second, a cross-sectional median at one calendar month is taken over the boxes still LISTED rather than over the boxes made, so the oldest band's level is a survivor median. The gradient in LEVELS is measured with both of those bounds, product by product, in `etb_agevalue_bands.csv` / `etb_agevalue_survivorship.csv` and section 4.6 of `etb_summary.md`; nothing in THIS section measures it. What this section measures is the RATE, and over the last 12 months the bands appreciated at markedly different ones, though the intervals on the youngest and oldest bands do NOT overlap, so the two ends of the age range did move differently.


## 5. What this cannot tell you

1. **One regime, 32 monthly observations** (2024-03 to
   2026-10), and the trailing window is 12 returns of
   31. Every interval here is SAMPLING uncertainty inside a
   single regime. It says nothing about a regime change, and the regime is the
   dominant risk.
2. **The recent window is short by construction.** A 12-month sub-window cannot
   resolve a mild slowdown; section 2 says so explicitly rather than reporting
   its point estimate as though it settled the question.
3. **No down market has ever been observed here.** The worst drawdown in the
   archive is -2.7%. Nothing in this data
   estimates how far ETBs fall when they fall.
4. **Cross-sectional intervals are dispersion, not confidence.** Products in a
   month share one market factor, so any interval built by treating them as
   independent draws is too narrow for the LEVEL. They are used inferentially
   in exactly one place, the between-group difference in section 4, and even
   there differencing only removes the MARKET-wide factor -- a channel-specific
   shock survives it, so that comparison's t is an upper bound on the evidence.
5. **Balanced endpoints discard products.** The trailing-12m
   cross-section is 91 of
   111 panel products -- the rest were not priced at both
   ends of the window. Inventing a return for them would date different
   products' returns to different spans.
6. **This is measurement, not advice.** It describes what these prices did. It
   does not tell anyone to buy, hold or sell anything, and a rise this broad and
   this fast is exactly the shape that mean-reverts in other collectibles
   markets.

