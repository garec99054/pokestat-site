# Chase-card pricing model

Prices as of 2026-07-21. Sample: n = 135 chase cards across 15 sets.

## Fit

- log(price) = -2.60 + 0.45 log(pull cost) + 0.586 desirability
- In-sample R2 = 0.75; LOOCV R2 = 0.74 (HC3 robust SEs)
- Doubling a card's pull cost is associated with a 36% higher price
  (SE 0.10); one desirability point is associated with a
  80% higher price (SE 0.033).

## Overvalued (market above model, top by |studentized residual|)

| Card | Market $ | Predicted $ | Gap % |
| --- | ---: | ---: | ---: |
| Mew ex | 1065.77 | 114.75 | +829% |
| Dachsbun ex | 73.83 | 9.94 | +643% |
| Mega Gardevoir ex | 217.48 | 45.69 | +376% |
| Umbreon ex | 1504.70 | 445.40 | +238% |
| Mega Lucario ex | 277.49 | 89.88 | +209% |
| Mega Charizard X ex | 826.36 | 301.72 | +174% |

## Undervalued (market below model)

| Card | Market $ | Predicted $ | Gap % |
| --- | ---: | ---: | ---: |
| Roaring Moon ex | 7.49 | 38.33 | -80% |
| Hearthflame Mask Ogerpon ex | 12.92 | 56.66 | -77% |
| Iron Crown ex | 8.43 | 33.25 | -75% |
| Pecharunt ex | 30.39 | 112.04 | -73% |
| Cornerstone Mask Ogerpon ex | 15.52 | 52.35 | -70% |
| Cynthia's Garchomp ex | 31.38 | 103.16 | -70% |
| Pecharunt ex | 21.88 | 63.12 | -65% |
| Garchomp ex | 16.90 | 44.95 | -62% |
| N's Zoroark ex | 15.80 | 41.80 | -62% |

Full per-card results: model_results.csv (same directory). Flags use externally
studentized residuals (threshold 1.5); high-leverage cards are marked in the CSV.
